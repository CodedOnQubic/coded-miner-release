#!/usr/bin/env bash
set -euo pipefail

cd /hive/miners/custom/coded-miner
exec ./h-stats.sh
