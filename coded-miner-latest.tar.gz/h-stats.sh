#!/usr/bin/env bash
cd /hive/miners/custom/coded-miner || exit 1
exec ./h-stats.sh