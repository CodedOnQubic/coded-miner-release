#!/usr/bin/env bash

CUSTOM_URL="${CUSTOM_URL:-pool.codedonqubic.com:7777}"
CUSTOM_TEMPLATE="${CUSTOM_TEMPLATE:-TEST_WALLET}"
WORKER_NAME="${WORKER_NAME:-coded_worker}"

get_extra_config_blob() {
  for var in CUSTOM_USER_CONFIG CUSTOM_EXTRA_CONFIG CUSTOM_CONFIG CUSTOM_ARGS; do
    val="$(eval "printf '%s' \"\${$var}\"" 2>/dev/null)"
    if [ -n "$val" ]; then
      printf '%s' "$val"
      return 0
    fi
  done
  return 0
}

extract_jsonish_value() {
  local key="$1"
  local blob="$2"

  printf '%s\n' "$blob" | tr -d '\r' | sed -nE \
    "s/.*[\"']?$key[\"']?[[:space:]]*:[[:space:]]*[\"']?([^,\"'} ]+)[\"']?.*/\1/p" | head -n1
}

resolve_threads() {
  local blob raw total

  blob="$(get_extra_config_blob)"
  raw="$(extract_jsonish_value "amountOfThreads" "$blob")"

  if ! printf '%s' "$raw" | grep -Eq '^[0-9]+$'; then
    raw="1"
  fi

  if [ "$raw" = "0" ]; then
    total="$(nproc --all 2>/dev/null || grep -c '^processor' /proc/cpuinfo 2>/dev/null || echo 2)"
    if ! printf '%s' "$total" | grep -Eq '^[0-9]+$'; then
      total="2"
    fi

    if [ "$total" -le 1 ]; then
      echo "1"
    else
      echo $((total - 1))
    fi
    return 0
  fi

  if [ "$raw" -lt 1 ]; then
    echo "1"
  else
    echo "$raw"
  fi
}

miner_config_gen() {
  local threads extra_blob wallet_only
  threads="$(resolve_threads)"
  extra_blob="$(get_extra_config_blob)"
  wallet_only="$(printf '%s' "${CUSTOM_TEMPLATE}" | sed "s/-${WORKER_NAME}$//")"

  mkdir -p /hive/miners/custom/coded-miner

  cat > /hive/miners/custom/coded-miner/config.json <<EOC
{
  "pool": "${CUSTOM_URL}",
  "walletTemplate": "${wallet_only}",
  "workerName": "${WORKER_NAME}",
  "threads": ${threads}
}
EOC


  echo "[CODED] CUSTOM_URL=${CUSTOM_URL}"
  echo "[CODED] CUSTOM_TEMPLATE=${CUSTOM_TEMPLATE}"
  echo "[CODED] WORKER_NAME=${WORKER_NAME}"
  echo "[CODED] EXTRA_CONFIG=${extra_blob}"
  echo "[CODED] RESOLVED_THREADS=${threads}"
}