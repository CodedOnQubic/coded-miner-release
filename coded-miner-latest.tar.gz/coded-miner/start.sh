#!/usr/bin/env bash
set -euo pipefail

echo "[CODED] start.sh starting..."

CONFIG_PATH="/hive/miners/custom/coded-miner/config.json"
MINER_BIN="/hive/miners/custom/coded-miner/coded-miner"

if [ ! -f "$CONFIG_PATH" ]; then
  echo "[CODED] ERROR: missing config.json at $CONFIG_PATH"
  exit 1
fi

if [ ! -x "$MINER_BIN" ]; then
  echo "[CODED] ERROR: miner binary not executable at $MINER_BIN"
  ls -la /hive/miners/custom/coded-miner || true
  exit 1
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "[CODED] jq not found, installing..."
  apt-get update
  apt-get install -y jq
fi

POOL="$(jq -r '.pool' "$CONFIG_PATH")"
WALLET="$(jq -r '.walletTemplate' "$CONFIG_PATH")"
WORKER="$(jq -r '.workerName' "$CONFIG_PATH")"
THREADS="$(jq -r '.threads' "$CONFIG_PATH")"

if [ -z "$POOL" ] || [ "$POOL" = "null" ]; then
  echo "[CODED] ERROR: invalid pool in config.json"
  exit 1
fi

if [ -z "$WALLET" ] || [ "$WALLET" = "null" ]; then
  echo "[CODED] ERROR: invalid walletTemplate in config.json"
  exit 1
fi

if [ -z "$WORKER" ] || [ "$WORKER" = "null" ]; then
  echo "[CODED] ERROR: invalid workerName in config.json"
  exit 1
fi

if [ -z "$THREADS" ] || [ "$THREADS" = "null" ]; then
  THREADS="1"
fi

echo "[CODED] POOL=$POOL"
echo "[CODED] WALLET=$WALLET"
echo "[CODED] WORKER=$WORKER"
echo "[CODED] THREADS=$THREADS"

exec "$MINER_BIN" \
  --pool "$POOL" \
  --wallet "$WALLET" \
  --worker "$WORKER" \
  --threads "$THREADS"