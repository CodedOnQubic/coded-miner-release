#!/usr/bin/env bash
API="${CODED_API:-${API:-http://pool.codedonqubic.com:4000/analytics}}"
API_ROOT="${API%/}"
API_ROOT="${API_ROOT%/analytics}"
CODED_API_ROOT="$API_ROOT"

set -euo pipefail

echo "[CODED] start.sh starting..."

CONFIG_PATH="/hive/miners/custom/coded-miner/config.json"
MINER_BIN="/hive/miners/custom/coded-miner/coded-miner"

if [ ! -f "$CONFIG_PATH" ]; then
  if [ "${CODED_FLEET:-}" = "1" ] || [ "${CODED_ANALYTICS:-}" = "YES" ]; then
    echo "[M10.99J_CONFIG_RECOVERY] missing config.json at $CONFIG_PATH; reconstructing fleet config from env/defaults"
    mkdir -p "$(dirname "$CONFIG_PATH")"
    cat > "$CONFIG_PATH" <<EOF
{
  "pool": "${CODED_POOL:-pool.codedonqubic.com:7777}",
  "walletTemplate": "${CODED_WALLET:-EUELEOZEENRCEDYVEAZEBYVHQFABSUFFWTUWTFNSFALSTCNJLCDSEROGOSYI}",
  "workerName": "${CODED_DEFAULT_WORKER:-${CODED_RIG_ID:-$(hostname)}}",
  "amountOfThreads": ${CODED_THREADS:-31},
  "threads": ${CODED_THREADS:-31},
  "env": "CODED_ANALYTICS=YES"
}
EOF
  else
    echo "[CODED] ERROR: missing config.json at $CONFIG_PATH"
    exit 1
  fi
fi

if [ ! -x "$MINER_BIN" ]; then
  echo "[CODED] ERROR: miner binary not executable at $MINER_BIN"
  ls -la /hive/miners/custom/coded-miner || true
  exit 1
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "[CODED] jq not found, installing..."
  apt-get update
  apt-get install -y jq
fi

POOL="$(jq -r '.pool' "$CONFIG_PATH")"
WALLET="$(jq -r '.walletTemplate' "$CONFIG_PATH")"
WORKER="$(jq -r '.workerName' "$CONFIG_PATH")"
THREADS="$(jq -r '.threads' "$CONFIG_PATH")"
EXTRA_CONFIG="$(jq -r '.extraConfig // .pass // .user_config // ""' "$CONFIG_PATH")"

if [ -z "$POOL" ] || [ "$POOL" = "null" ]; then
  echo "[CODED] ERROR: invalid pool in config.json"
  exit 1
fi

if [ -z "$WALLET" ] || [ "$WALLET" = "null" ]; then
  echo "[CODED] ERROR: invalid walletTemplate in config.json"
  exit 1
fi

if [ -z "$WORKER" ] || [ "$WORKER" = "null" ]; then
  echo "[CODED] ERROR: invalid workerName in config.json"
  exit 1
fi

THREADS="$(jq -r '.amountOfThreads // .threads // 0' "$CONFIG_PATH")"
if [ "$THREADS" = "1" ] || [ "$THREADS" = "0" ]; then
  TOTAL_THREADS="$(nproc 2>/dev/null || echo 2)"
  if [ "$TOTAL_THREADS" -gt 1 ]; then
    THREADS="$((TOTAL_THREADS - 1))"
  else
    THREADS="1"
  fi
fi
EXTRA_CONFIG="$(jq -r '.env // .extraConfig // .pass // .user_config // ""' "$CONFIG_PATH")"

if [ -z "$THREADS" ] || [ "$THREADS" = "null" ]; then
  THREADS="0"
fi

if ! printf '%s' "$THREADS" | grep -Eq '^[0-9]+$'; then
  THREADS="0"
fi

echo "[CODED] POOL=$POOL"
echo "[CODED] WALLET=$WALLET"
echo "[CODED] WORKER=$WORKER"
echo "[CODED] THREADS=$THREADS"

if [ -n "$EXTRA_CONFIG" ] && [ "$EXTRA_CONFIG" != "null" ]; then
  echo "[CODED] applying HiveOS extra config"
  while IFS= read -r line; do
    line="$(echo "$line" | sed 's/^ *//;s/ *$//')"
    [ -z "$line" ] && continue
    echo "$line" | grep -q '^#' && continue

    case "$line" in
      CODED_*=*)
        export "$line"
        ;;
      *)
        echo "[CODED] ignoring unsupported extra config line: $line"
        ;;
    esac
  done <<EOF
$EXTRA_CONFIG
EOF
fi

export CODED_HYPER_HIT_MODE="${CODED_HYPER_HIT_MODE:-crypto}"
export CODED_LOG_MODE="${CODED_LOG_MODE:-public}"

# M10.25a production preset: validated Shadow500 path.
# Can be overridden from HiveOS extra config.
export CODED_RANDOM2_HUGEPAGE="${CODED_RANDOM2_HUGEPAGE:-1}"
export CODED_BATCH_SIZE="${CODED_BATCH_SIZE:-64}"
export CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx512}"
export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
export CODED_SCORE_SAMPLE_BATCH_RATE="${CODED_SCORE_SAMPLE_BATCH_RATE:-0}"
export CODED_SCORE_DEBUG="${CODED_SCORE_DEBUG:-0}"
# ============================================================
# M10.96H Analytics Auto Defaults
# HiveOS must stay simple:
#   CODED_ANALYTICS=YES
#
# When analytics is enabled, the miner automatically enters the
# safest research profile:
# - Fast shadow gate enabled
# - Per-rig threshold cohort assignment
# - Dual-gate observe mode T509 -> T511
# - No hard dual-gate rejection
# - Fullscore remains authoritative
# ============================================================

coded_bool_yes_early() {
  case "${1:-}" in
    1|yes|YES|true|TRUE|on|ON) return 0 ;;
    *) return 1 ;;
  esac
}

coded_infer_analytics_threshold_early() {
  case "${CODED_RIG_ID:-$(hostname)}" in
    Rig1X3D) echo "509" ;;
    Rig2X3D) echo "510" ;;
    Rig3X) echo "509" ;;
    Rig4X) echo "510" ;;
    Rig5X3D) echo "510" ;;
    Rig6X3D) echo "511" ;;
    *) echo "510" ;;
  esac
}

export CODED_FAST_SHADOW_GATE="${CODED_FAST_SHADOW_GATE:-1}"

if coded_bool_yes_early "${CODED_ANALYTICS:-}"; then
  export CODED_FAST_SHADOW_THRESHOLD="${CODED_FAST_SHADOW_THRESHOLD:-$(coded_infer_analytics_threshold_early)}"
  export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-500}"
  export CODED_MULTI_GATE_MODE="${CODED_MULTI_GATE_MODE:-observe}"
  export CODED_MULTI_GATE_STAGE1="${CODED_MULTI_GATE_STAGE1:-509}"
  export CODED_MULTI_GATE_STAGE2="${CODED_MULTI_GATE_STAGE2:-511}"
  export CODED_MULTI_GATE_HARD_REJECT="${CODED_MULTI_GATE_HARD_REJECT:-0}"
  export CODED_PRIORITY_ROUTER="${CODED_PRIORITY_ROUTER:-observe}"
  export CODED_PRIORITY_BUDGET_ROUTER="${CODED_PRIORITY_BUDGET_ROUTER:-M1098C}"
else
  export CODED_FAST_SHADOW_THRESHOLD="${CODED_FAST_SHADOW_THRESHOLD:-507}"
  export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-0}"
fi

export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"

echo "[CODED] BACKEND=$CODED_KERNEL_BACKEND"
echo "[CODED] ACTIVATION=$CODED_KERNEL_ACTIVATION"
echo "[CODED] RANDOM2_HUGEPAGE=$CODED_RANDOM2_HUGEPAGE"
echo "[CODED] BATCH_SIZE=$CODED_BATCH_SIZE"
echo "[CODED] PREFILTER=$CODED_PREFILTER_DIFFICULTY"
echo "[CODED] SCORE_ALGO_MODE=$CODED_SCORE_ALGO_MODE"
echo "[CODED] SCORE_SAMPLE_BATCH_RATE=$CODED_SCORE_SAMPLE_BATCH_RATE"
echo "[CODED] FAST_SHADOW_GATE=$CODED_FAST_SHADOW_GATE"
echo "[CODED] FAST_SHADOW_THRESHOLD=$CODED_FAST_SHADOW_THRESHOLD"
echo "[CODED] FAST_SHADOW_AUDIT_RATE=$CODED_FAST_SHADOW_AUDIT_RATE"
echo "[CODED] FAST_SHADOW_SUMMARY_SEC=$CODED_FAST_SHADOW_SUMMARY_SEC"
echo "[CODED] MULTI_GATE_MODE=${CODED_MULTI_GATE_MODE:-off}"
echo "[CODED] MULTI_GATE_STAGE1=${CODED_MULTI_GATE_STAGE1:-}"
echo "[CODED] MULTI_GATE_STAGE2=${CODED_MULTI_GATE_STAGE2:-}"
echo "[CODED] MULTI_GATE_HARD_REJECT=${CODED_MULTI_GATE_HARD_REJECT:-0}"
echo "[CODED] PRIORITY_ROUTER=${CODED_PRIORITY_ROUTER:-off}"
echo "[CODED] PRIORITY_BUDGET_ROUTER=${CODED_PRIORITY_BUDGET_ROUTER:-off}"



# ============================================================
# M10.84A Fleet Analytics Runtime
# ============================================================

ANALYTICS_ENABLED="${CODED_ANALYTICS:-0}"

if [ "$ANALYTICS_ENABLED" = "1" ]; then

  echo "[CODED_ANALYTICS] enabled"

  ANALYTICS_API="${CODED_ANALYTICS_API:-https://api.codedonqubic.com/analytics}"
  ANALYTICS_TOKEN="${CODED_ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}"

  RIG_ID="${CODED_RIG_ID:-$(hostname)}"

  RUN_ID="M1084_${RIG_ID}_$(date +%Y%m%d_%H%M%S)"

  CPU_MODEL="$(lscpu | grep "Model name" | sed "s/.*: *//" | head -1)"
  CPU_THREADS="$(nproc)"
  RAM_MB="$(free -m | awk "/Mem:/ {print $2}")"

  AVX2_SUPPORTED=false
  AVX512_SUPPORTED=false

  grep -m1 flags /proc/cpuinfo | grep -qw avx2 && AVX2_SUPPORTED=true
  grep -m1 flags /proc/cpuinfo | grep -qw avx512f && AVX512_SUPPORTED=true

  HUGEPAGES_TOTAL="$(grep HugePages_Total /proc/meminfo | awk "{print \$2}")"
  HUGEPAGES_FREE="$(grep HugePages_Free /proc/meminfo | awk "{print \$2}")"

  export RUN_ID

  curl -s -X POST "${ANALYTICS_API}/runs/start" \
    -H "Authorization: Bearer ${ANALYTICS_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{
      \"run_id\":\"${RUN_ID}\",
      \"rig_id\":\"${RIG_ID}\",
      \"worker_name\":\"${WORKER}\",
      \"miner_version\":\"m10.84a\",
      \"backend\":\"${CODED_KERNEL_BACKEND}\",
      \"threshold\":${CODED_FAST_SHADOW_THRESHOLD},
      \"threads\":${THREADS},
      \"batch_size\":${CODED_BATCH_SIZE},
      \"audit_rate\":${CODED_FAST_SHADOW_AUDIT_RATE},
      \"gate_mode\":\"single\",
      \"hostname\":\"$(hostname)\",
      \"cpu_model\":\"${CPU_MODEL}\",
      \"cpu_threads\":${CPU_THREADS},
      \"ram_mb\":${RAM_MB},
      \"avx2_supported\":${AVX2_SUPPORTED},
      \"avx512_supported\":${AVX512_SUPPORTED},
      \"hugepages_total\":${HUGEPAGES_TOTAL:-0},
      \"hugepages_free\":${HUGEPAGES_FREE:-0},
      \"hardware\":{
        \"cpu_model\":\"${CPU_MODEL}\",
        \"cpu_threads\":${CPU_THREADS},
        \"ram_mb\":${RAM_MB},
        \"avx2\":${AVX2_SUPPORTED},
        \"avx512\":${AVX512_SUPPORTED}
      }
    }" >/dev/null || true

  echo "[CODED_ANALYTICS] RUN_ID=${RUN_ID}"

  # M10.86 Statistical Fleet Analysis bridge
  # Flightsheet stays simple: CODED_ANALYTICS=YES
  # This enables score-distribution upload without adding extra HiveOS fields.
  ANALYTICS_BASE="${API%/analytics}"

  export CODED_SCORE_DIST_UPLOAD=1
  export CODED_ANALYTICS_URL="${CODED_ANALYTICS_URL:-${ANALYTICS_BASE}}"
  export CODED_ANALYTICS_INGEST_TOKEN="${CODED_ANALYTICS_INGEST_TOKEN:-${TOKEN}}"
  export CODED_RUN_ID="${CODED_RUN_ID:-${RUN_ID}}"
  export CODED_RIG_ID="${CODED_RIG_ID:-${RIG_ID:-$(hostname)}}"
  export CODED_WORKER_NAME="${CODED_WORKER_NAME:-${WORKER_NAME:-$(hostname)}}"

  echo "[CODED_ANALYTICS] M10.86 score distribution upload enabled"
  echo "[CODED_ANALYTICS] SCORE_DIST_URL=${CODED_ANALYTICS_URL}/analytics/score-distribution"

fi


LOG_DIR="/var/log/miner/coded-miner"
LOG_FILE="$LOG_DIR/coded-miner.log"

mkdir -p "$LOG_DIR"
touch "$LOG_FILE"

if [ "${CODED_ANALYTICS:-}" = "YES" ] || [ "${CODED_ANALYTICS:-}" = "1" ]; then
  
# ============================================================


# M10.91A Always-On Runtime Supervisor
# Goal:
# - Never leave rigs idle.
# - If no experiment command is active, run a deterministic fallback profile.
# - Analytics rigs use analytics_baseline as fallback.
# - Production rigs use production fallback.
# - Experiment commands may interrupt fallback, then agent resumes fallback.

coded_bool_yes() {
  case "${1:-}" in
    1|yes|YES|true|TRUE|on|ON) return 0 ;;
    *) return 1 ;;
  esac
}

coded_infer_default_threshold() {
  case "${RIG_ID:-}" in
    Rig1X3D) echo "509" ;;
    Rig3X) echo "509" ;;
    Rig5X3D) echo "511" ;;
    Rig6X3D) echo "511" ;;
    *) echo "${CODED_DEFAULT_THRESHOLD:-510}" ;;
  esac
}

coded_default_mode() {
  if coded_bool_yes "${CODED_ANALYTICS:-}"; then
    echo "analytics_baseline"
  else
    echo "production"
  fi
}

coded_default_worker() {
  local T
  T="$(coded_infer_default_threshold)"
  if coded_bool_yes "${CODED_ANALYTICS:-}"; then
    echo "${RIG_ID}_BASELINE_ANALYTICS_T${T}"
  else
    echo "${RIG_ID}_PROD_T${T}"
  fi
}

coded_default_profile_json() {
  local T MODE WORKER HOURS THREADS BATCH AUDIT
  T="$(coded_infer_default_threshold)"
  MODE="$(coded_default_mode)"
  WORKER="$(coded_default_worker)"
  HOURS="${CODED_FALLBACK_HOURS:-8760}"
  THREADS="${THREADS:-${CODED_THREADS:-31}}"
  BATCH="${CODED_BATCH_SIZE:-4000}"
  AUDIT="${CODED_AUDIT_RATE:-500}"

  jq -nc \
    --arg mode "$MODE" \
    --arg worker_name "$WORKER" \
    --argjson threshold "$T" \
    --argjson hours "$HOURS" \
    --argjson threads "$THREADS" \
    --argjson batch_size "$BATCH" \
    --argjson audit_rate "$AUDIT" \
    '{mode:$mode,worker_name:$worker_name,threshold:$threshold,hours:$hours,threads:$threads,batch_size:$batch_size,audit_rate:$audit_rate,resume_after:true,fallback:true}'
}


# M10.91B Fleet Idle Fallback
# In fleet mode, if there is no pending command and no miner process,
# create a fallback start_run command so the existing command runner starts
# the deterministic baseline/production worker instead of idling.
coded_has_miner_process() {
  pgrep -f "$MINER_BIN" >/dev/null 2>&1 && return 0

# ============================================================
# M10.96G8O start_run command params override
# ============================================================
# Backend G8N converts git_experiment_run into a direct start_run.
# For these experiment start_runs, command params are runtime truth.
# They must override default analytics profile/fallback values.
coded_apply_start_run_params_override() {
  local raw="${CMD:-${COMMAND_JSON:-}}"

  if [ -z "$raw" ]; then
    return 0
  fi

  local ctype
  ctype="$(echo "$raw" | jq -r '.command.command_type // .command_type // empty' 2>/dev/null || true)"
  if [ "$ctype" != "start_run" ]; then
    return 0
  fi

  local handoff profile_source priority source_type
  handoff="$(echo "$raw" | jq -r '.command.params.backend_handoff // .params.backend_handoff // empty' 2>/dev/null || true)"
  profile_source="$(echo "$raw" | jq -r '.command.params.profile_source // .params.profile_source // empty' 2>/dev/null || true)"
  priority="$(echo "$raw" | jq -r '.command.params.priority // .params.priority // empty' 2>/dev/null || true)"
  source_type="$(echo "$raw" | jq -r '.command.params.source_command_type // .params.source_command_type // empty' 2>/dev/null || true)"

  if [ "$handoff" != "M10.96G8N" ] && [ "$profile_source" != "git_experiment_run_backend_handoff" ] && [ "$priority" != "experiment" ] && [ "$source_type" != "git_experiment_run" ]; then
    return 0
  fi

  local exp_worker exp_threads exp_threshold exp_batch exp_audit exp_backend exp_hours exp_id
  exp_worker="$(echo "$raw" | jq -r '.command.params.worker_name // .params.worker_name // empty' 2>/dev/null || true)"
  exp_threads="$(echo "$raw" | jq -r '.command.params.threads // .params.threads // empty' 2>/dev/null || true)"
  exp_threshold="$(echo "$raw" | jq -r '.command.params.threshold // .params.threshold // empty' 2>/dev/null || true)"
  exp_batch="$(echo "$raw" | jq -r '.command.params.batch_size // .params.batch_size // empty' 2>/dev/null || true)"
  exp_audit="$(echo "$raw" | jq -r '.command.params.audit_rate // .params.audit_rate // empty' 2>/dev/null || true)"
  exp_backend="$(echo "$raw" | jq -r '.command.params.backend // .params.backend // "avx512"' 2>/dev/null || true)"
  exp_hours="$(echo "$raw" | jq -r '.command.params.hours // .params.hours // empty' 2>/dev/null || true)"
  exp_id="$(echo "$raw" | jq -r '.command.params.experiment_id // .params.experiment_id // empty' 2>/dev/null || true)"

  if [ -n "$exp_worker" ] && [ "$exp_worker" != "null" ]; then RUN_WORKER="$exp_worker"; fi
  if [ -n "$exp_threads" ] && [ "$exp_threads" != "null" ]; then THREADS="$exp_threads"; fi
  if [ -n "$exp_threshold" ] && [ "$exp_threshold" != "null" ]; then THRESHOLD="$exp_threshold"; fi
  if [ -n "$exp_batch" ] && [ "$exp_batch" != "null" ]; then BATCH_SIZE="$exp_batch"; fi
  if [ -n "$exp_audit" ] && [ "$exp_audit" != "null" ]; then AUDIT_RATE="$exp_audit"; fi
  if [ -n "$exp_backend" ] && [ "$exp_backend" != "null" ]; then BACKEND="$exp_backend"; fi
  if [ -n "$exp_hours" ] && [ "$exp_hours" != "null" ]; then HOURS="$exp_hours"; fi

  export CODED_KERNEL_BACKEND="$BACKEND"
  export CODED_FAST_SHADOW_THRESHOLD="$THRESHOLD"
  export CODED_BATCH_SIZE="$BATCH_SIZE"
  export CODED_FAST_SHADOW_AUDIT_RATE="$AUDIT_RATE"

  echo "$RUN_WORKER" > "/tmp/coded_expected_worker_${RIG_ID:-unknown}.txt" 2>/dev/null || true

  echo "[M10.96G8O_START_RUN_PARAMS_OVERRIDE] command_id=${COMMAND_ID:-unknown} worker=$RUN_WORKER threads=$THREADS threshold=$THRESHOLD batch=$BATCH_SIZE audit=$AUDIT_RATE backend=$BACKEND hours=${HOURS:-} experiment_id=$exp_id handoff=$handoff source=$profile_source priority=$priority" | tee -a "${RUN_LOG:-/tmp/coded_m1096g8o.log}"
}

coded_enforce_expected_worker_before_launch() {
  local expected_file="/tmp/coded_expected_worker_${RIG_ID:-unknown}.txt"
  if [ -f "$expected_file" ]; then
    local expected
    expected="$(cat "$expected_file" 2>/dev/null || true)"
    if [ -n "$expected" ] && [ "$RUN_WORKER" != "$expected" ]; then
      echo "[M10.96G8O_START_RUN_PARAMS_OVERRIDE] correcting RUN_WORKER before launch old=$RUN_WORKER expected=$expected" | tee -a "${RUN_LOG:-/tmp/coded_m1096g8o.log}"
      RUN_WORKER="$expected"
    fi
  fi
}

  pgrep -f "coded-miner.*--worker" >/dev/null 2>&1 && return 0
  return 1
}

coded_ensure_fleet_idle_fallback() {
  if coded_has_miner_process; then
    return 0
  fi

  local NOW LAST
  NOW="$(date +%s)"
  LAST="${CODED_LAST_FALLBACK_ENQUEUE_TS:-0}"

  if [ $((NOW - LAST)) -lt "${CODED_FALLBACK_ENQUEUE_COOLDOWN:-60}" ]; then
    return 0
  fi

  CODED_LAST_FALLBACK_ENQUEUE_TS="$NOW"
  export CODED_LAST_FALLBACK_ENQUEUE_TS

  local PARAMS MODE WORKER
  PARAMS="$(coded_default_profile_json)"
  MODE="$(echo "$PARAMS" | jq -r '.mode // "production"')"
  WORKER="$(echo "$PARAMS" | jq -r '.worker_name // empty')"

  echo "[M10.91B_FLEET_IDLE] no miner process detected; enqueue fallback mode=$MODE worker=$WORKER"

  curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":$PARAMS}" >/dev/null || true
}


coded_mark_command_running() {
  local command_id="$1"
  curl -s -X POST "$CODED_API_ROOT/commands/$command_id/running" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{}" >/dev/null || true
}

coded_command_heartbeat_bg() {
  local command_id="$1"
  local build_log="$2"
  (
    while true; do
      curl -s -X POST "$CODED_API_ROOT/commands/$command_id/heartbeat" \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "{}" >/dev/null || true
      echo "[M10.97B4_HEARTBEAT] command=$command_id ts=$(date -u +%FT%TZ)" >> "$build_log"
      sleep 30
    done
  ) &
  echo $!
}

coded_resume_default_after_gitexp() {
  local reason="${1:-git_experiment_resume_default}"
  local params
  params="$(coded_default_profile_json)"
  curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":$params}" >/dev/null || true
  echo "[M10.96G2_RESUME_DEFAULT] reason=$reason params=$params"
}


coded_run_profile() {
  local PARAMS RUN_MODE RUN_WORKER RUN_THRESHOLD RUN_HOURS RUN_THREADS RUN_BATCH RUN_AUDIT RUN_ID RUN_LOG
  PARAMS="$1"

  RUN_MODE="$(echo "$PARAMS" | jq -r '.mode // "experiment"')"
  RUN_WORKER="$(echo "$PARAMS" | jq -r '.worker_name // empty')"
  RUN_THRESHOLD="$(echo "$PARAMS" | jq -r '.threshold // empty')"
  RUN_HOURS="$(echo "$PARAMS" | jq -r '.hours // 24')"
  RUN_THREADS="$(echo "$PARAMS" | jq -r '.threads // empty')"
  RUN_BATCH="$(echo "$PARAMS" | jq -r '.batch_size // 4000')"
  RUN_AUDIT="$(echo "$PARAMS" | jq -r '.audit_rate // 500')"

  [ -z "$RUN_WORKER" ] && RUN_WORKER="$(coded_default_worker)"
  [ -z "$RUN_THRESHOLD" ] && RUN_THRESHOLD="$(coded_infer_default_threshold)"
  [ -z "$RUN_THREADS" ] && RUN_THREADS="${THREADS:-${CODED_THREADS:-31}}"

  RUN_ID="M1091_${RIG_ID}_T${RUN_THRESHOLD}_$(date -u +%Y%m%d_%H%M%S)"
  RUN_LOG="$LOG_DIR/${RUN_ID}.log"  # M10.95A unified fleet run log path

  echo "[M10.91A_SUPERVISOR] start_profile mode=$RUN_MODE rig=$RIG_ID worker=$RUN_WORKER threshold=$RUN_THRESHOLD threads=$RUN_THREADS hours=$RUN_HOURS batch=$RUN_BATCH audit=$RUN_AUDIT run_id=$RUN_ID"

  curl -s -X POST "$API/runs/start" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"threshold\":$RUN_THRESHOLD,\"threads\":$RUN_THREADS,\"batch_size\":$RUN_BATCH,\"audit_rate\":$RUN_AUDIT,\"milestone\":\"M10.91A\",\"params\":$PARAMS}" >/dev/null || true

  CODED_RUNTIME_MODE="$RUN_MODE" \
  CODED_RUN_ID="$RUN_ID" \
  CODED_RUN_WORKER="$RUN_WORKER" \
  CODED_THRESHOLD="$RUN_THRESHOLD" \
  CODED_BATCH_SIZE="$RUN_BATCH" \
  CODED_AUDIT_RATE="$RUN_AUDIT" \
      coded_apply_start_run_params_override || true
      coded_enforce_expected_worker_before_launch || true
  "$MINER_BIN" \
    --pool "$POOL" \
    --wallet "$WALLET" \
    --worker "$RUN_WORKER" \
    --threads "$RUN_THREADS" > "$RUN_LOG" 2>&1 &

  MINER_PID=$!

  echo "[M10.91A_SUPERVISOR] miner_pid=$MINER_PID worker=$RUN_WORKER log=$RUN_LOG"

  # Start analytics uploader if existing function/path exists later in file.
  # The existing M10.89/M10.90 uploader loop reads RUN_LOG variables in command mode.
  # For now, keep process supervision here and let normal log ingestion continue where supported.

  local END_TS
  # ============================================================
  # M10.96G8AG float-safe RUN_HOURS duration
  # ============================================================
  RUN_DURATION_SEC="$(awk -v h="${RUN_HOURS:-24}" 'BEGIN { if (h <= 0) h = 24; printf "%d", h * 3600 }' 2>/dev/null || echo 86400)"
  [ -z "$RUN_DURATION_SEC" ] && RUN_DURATION_SEC=86400
  [ "$RUN_DURATION_SEC" -lt 60 ] 2>/dev/null && RUN_DURATION_SEC=60
  END_TS=$(( $(date +%s) + RUN_DURATION_SEC ))
  echo "[M10.96G8AG_RUN_HOURS_DURATION] run_hours=${RUN_HOURS:-} duration_sec=$RUN_DURATION_SEC"
  if [ -n "${PARAMS:-}" ]; then coded_m1099k_apply_duration_override "$PARAMS" || true; fi
  if [ -n "${PARAMS:-}" ]; then coded_m1099m_export_params_env "$PARAMS" "${RUN_LOG:-/tmp/coded_m1099m_env_forwarding.log}" || true; fi
  while kill -0 "$MINER_PID" 2>/dev/null; do
    # Fallback/default runs can be interrupted by high priority commands.
    # Experiment runs can also be interrupted by stop/build commands.
    if coded_check_interrupt_command; then
      echo "[M10.91A_SUPERVISOR] interrupt type=$INTERRUPT_TYPE pid=$MINER_PID worker=$RUN_WORKER"
      kill "$MINER_PID" 2>/dev/null || true
      sleep 2
      kill -9 "$MINER_PID" 2>/dev/null || true
      wait "$MINER_PID" 2>/dev/null || true
      return 90
    fi

    if [ "$(date +%s)" -ge "$END_TS" ]; then
      echo "[M10.91A_SUPERVISOR] profile duration completed mode=$RUN_MODE worker=$RUN_WORKER"
      kill "$MINER_PID" 2>/dev/null || true
      wait "$MINER_PID" 2>/dev/null || true
      curl -s -X POST "$API/runs/end" \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"run_id\":\"$RUN_ID\",\"status\":\"completed\",\"end_reason\":\"profile_duration_completed\"}" >/dev/null || true
      return 0
    fi

    sleep 10
  done

  echo "[M10.91A_SUPERVISOR] miner process exited mode=$RUN_MODE worker=$RUN_WORKER pid=$MINER_PID"
  curl -s -X POST "$API/runs/end" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"run_id\":\"$RUN_ID\",\"status\":\"completed\",\"end_reason\":\"miner_process_exited\"}" >/dev/null || true

  return 0
}

# M10.90A Interruptible Fleet Agent
# ============================================================
# During long start_run mining loops, periodically check whether
# a high-priority control command is pending. This prevents
# release builds from requiring manual SSH restarts.
#
# Supported interrupt command types:
# - stop_run
# - build_hive_release
# - build_release  (alias, generic future-proof name)

coded_check_interrupt_command() {
  local RESP
  local TYPE

  # M10.96G7:
  # During an active miner run, only poll the interrupt-only endpoint.
  # Never call generic /commands/next here, because that destructively
  # picks git_experiment_run and prevents the top-level build handler
  # from processing it.
  RESP="$(curl -s "$API/commands/next-interrupt/$RIG_ID" \
    -H "Authorization: Bearer $TOKEN" || true)"

  TYPE="$(echo "$RESP" | jq -r ".command.command_type // empty" 2>/dev/null || true)"

  if [ -z "$TYPE" ] || [ "$TYPE" = "null" ]; then
    return 1
  fi

  case "$TYPE" in
    stop_run|build_hive_release|build_release)
      INTERRUPT_CMD="$RESP"
      INTERRUPT_TYPE="$TYPE"

        # ============================================================
        # M10.99J_BUILDER_LIFECYCLE_FIX
        # ------------------------------------------------------------
        # build_hive_release/build_release must be handled by the top-level
        # release builder. If next-interrupt consumes it during a running miner,
        # the command remains picked_up and no /tmp/coded_hive_release_*.log is
        # created. Requeue a fresh pending release command, mark the consumed
        # one safely requeued/failed, then stop the miner so the top-level loop
        # can pick the fresh release command.
        # ============================================================
        if [ "$TYPE" = "build_hive_release" ] || [ "$TYPE" = "build_release" ]; then
          BUILD_PARAMS_M1099J="$(echo "$RESP" | jq -c ".command.params // .params // {}" 2>/dev/null || echo '{}')"
          BUILD_DB_ID_M1099J="$(echo "$RESP" | jq -r ".command.id // .id // empty" 2>/dev/null || true)"
          BUILD_COMMAND_ID_M1099J="$(echo "$RESP" | jq -r ".command.command_id // .command_id // empty" 2>/dev/null || true)"
          BUILD_LIFECYCLE_ID_M1099J="${BUILD_DB_ID_M1099J:-$BUILD_COMMAND_ID_M1099J}"

          echo "[M10.99J_BUILDER_LIFECYCLE_FIX] requeue top-level release from interrupt old_db_id=$BUILD_DB_ID_M1099J old_command_id=$BUILD_COMMAND_ID_M1099J type=$TYPE params=$BUILD_PARAMS_M1099J" | tee -a "${RUN_LOG:-/tmp/coded_m1099j_builder_lifecycle.log}"

          CREATE_RELEASE_RESP_M1099J="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
            -H "Authorization: Bearer $TOKEN" \
            -H "Content-Type: application/json" \
            -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"$TYPE\",\"params\":$BUILD_PARAMS_M1099J}" || true)"

          echo "[M10.99J_BUILDER_LIFECYCLE_FIX] create_release_resp=$CREATE_RELEASE_RESP_M1099J" | tee -a "${RUN_LOG:-/tmp/coded_m1099j_builder_lifecycle.log}"

          if [ -n "$BUILD_LIFECYCLE_ID_M1099J" ]; then
            coded_fail_command "$BUILD_LIFECYCLE_ID_M1099J" "build_hive_release requeued from interrupt for top-level builder" "{\"status\":\"requeued\",\"reason\":\"m1099j_interrupt_requeued_for_top_level_release_builder\",\"old_command_id\":\"$BUILD_COMMAND_ID_M1099J\",\"orchestration\":\"M10.99J\"}" || true
          fi

          INTERRUPT_TYPE="stop_run"
          TYPE="stop_run"
        fi
      echo "[M10.90A_INTERRUPT] picked interrupt command type=$TYPE"

      # ============================================================
      # M10.96G8H pick-time git_experiment_run handoff
      # ============================================================
      # Fleet-scale invariant:
      # - git_experiment_run is not picked by the running miner loop.
      # - running miner loop only picks stop_run/build interrupts.
      # - if stop_run carries next_git_experiment_params, create the
      #   git_experiment_run immediately at pick-time, before miner-stop
      #   code can hang/return/skip later handoff branches.
      if [ "$TYPE" = "stop_run" ]; then
        NEXT_TYPE_G8H="$(echo "$RESP" | jq -r ".command.params.next_command_type // empty" 2>/dev/null || true)"
        echo "[M10.96G8H_PICKTIME_HANDOFF] picked stop_run next_type=$NEXT_TYPE_G8H" | tee -a "${RUN_LOG:-/tmp/coded_m1096g8h_picktime.log}"

        if [ "$NEXT_TYPE_G8H" = "git_experiment_run" ]; then
          NEXT_PARAMS_G8H="$(echo "$RESP" | jq -c ".command.params.next_git_experiment_params // empty" 2>/dev/null || true)"
          STOP_DB_ID_G8H="$(echo "$RESP" | jq -r ".command.id // .id // empty" 2>/dev/null || true)"
          STOP_COMMAND_ID_G8H="$(echo "$RESP" | jq -r ".command.command_id // empty" 2>/dev/null || true)"
          STOP_LIFECYCLE_ID_G8H="${STOP_DB_ID_G8H:-$STOP_COMMAND_ID_G8H}"

          echo "[M10.96G8H_PICKTIME_HANDOFF] stop_db_id=$STOP_DB_ID_G8H stop_command_id=$STOP_COMMAND_ID_G8H lifecycle=$STOP_LIFECYCLE_ID_G8H params=$NEXT_PARAMS_G8H" | tee -a "${RUN_LOG:-/tmp/coded_m1096g8h_picktime.log}"

          if [ -n "$NEXT_PARAMS_G8H" ] && [ "$NEXT_PARAMS_G8H" != "null" ]; then
            CREATE_RESP_G8H="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
              -H "Authorization: Bearer $TOKEN" \
              -H "Content-Type: application/json" \
              -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$NEXT_PARAMS_G8H}" || true)"

            echo "[M10.96G8H_PICKTIME_HANDOFF] create_git_experiment_resp=$CREATE_RESP_G8H" | tee -a "${RUN_LOG:-/tmp/coded_m1096g8h_picktime.log}"

            coded_complete_command_id "$STOP_LIFECYCLE_ID_G8H" "{\"status\":\"completed\",\"stage\":\"picktime_git_experiment_enqueued\",\"orchestration\":\"M10.96G8H\"}" || true

            echo "[M10.96G8H_PICKTIME_HANDOFF] completed stop_run and enqueued git_experiment_run" | tee -a "${RUN_LOG:-/tmp/coded_m1096g8h_picktime.log}"
          else
            echo "[M10.96G8H_PICKTIME_HANDOFF] missing next_git_experiment_params" | tee -a "${RUN_LOG:-/tmp/coded_m1096g8h_picktime.log}"
            coded_fail_command "$STOP_LIFECYCLE_ID_G8H" "stop_run pick-time missing next_git_experiment_params" "{\"status\":\"failed\",\"stage\":\"picktime_missing_params\",\"orchestration\":\"M10.96G8H\"}" || true
          fi
        fi
      fi

      # M10.96G5:
      # If git_experiment_run is picked while a long miner loop is running,
      # the command would otherwise be consumed as an interrupt and never reach
      # the top-level git_experiment_run build handler.
      # Requeue a fresh pending copy immediately, fail the consumed command,
      # then downgrade this interrupt to stop_run so the current miner exits.
      if [ "$TYPE" = "__disabled_git_experiment_run_interrupt__" ]; then
        GITEXP_PARAMS_SAFE="$(echo "$RESP" | jq -c ".command.params // .params // {}")"
        GITEXP_DB_ID="$(echo "$RESP" | jq -r ".command.id // .id // empty")"
        GITEXP_COMMAND_ID="$(echo "$RESP" | jq -r ".command.command_id // .command_id // empty")"

        echo "[M10.96G5_EARLY_REQUEUE] requeue git_experiment_run old_db_id=$GITEXP_DB_ID old_command_id=$GITEXP_COMMAND_ID params=$GITEXP_PARAMS_SAFE"

        curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$GITEXP_PARAMS_SAFE}" >/dev/null || true

        if [ -n "$GITEXP_DB_ID" ]; then
          coded_fail_command "$GITEXP_DB_ID" "git_experiment_run requeued from interrupt picker" "{\"status\":\"requeued\",\"reason\":\"early_interrupt_requeue\",\"old_command_id\":\"$GITEXP_COMMAND_ID\"}" || true
        fi

        INTERRUPT_TYPE="stop_run"
        TYPE="stop_run"
      fi
      return 0
      ;;
    *)
      echo "[M10.90A_INTERRUPT] non-interrupt command picked type=$TYPE; deferring is not supported in current agent"
      return 1
      ;;
  esac
}


# ============================================================

# ============================================================
# M10.99K_EXPERIMENT_DURATION_ENFORCEMENT
# ------------------------------------------------------------
# Experiment start_run params may contain both hours and duration_sec.
# duration_sec / duration_minutes are authoritative and must override hours.
# ============================================================
coded_m1099k_apply_duration_override() {
  local params_json="${1:-}"
  local override_sec=""
  local override_min=""

  if [ -z "$params_json" ]; then
    return 0
  fi

  override_sec="$(echo "$params_json" | jq -r '.duration_sec // empty' 2>/dev/null || true)"
  override_min="$(echo "$params_json" | jq -r '.duration_minutes // empty' 2>/dev/null || true)"

  if [ -z "$override_sec" ] || [ "$override_sec" = "null" ]; then
    if [ -n "$override_min" ] && [ "$override_min" != "null" ]; then
      override_min="${override_min%.*}"
      if [ "$override_min" -gt 0 ] 2>/dev/null; then
        override_sec=$(( override_min * 60 ))
      fi
    fi
  fi

  if [ -n "$override_sec" ] && [ "$override_sec" != "null" ] && [ "$override_sec" -gt 0 ] 2>/dev/null; then
    RUN_DURATION_SEC="$override_sec"
    RUN_HOURS=""
    HOURS=""
    echo "[M10.99K_DURATION_OVERRIDE] duration_sec=$RUN_DURATION_SEC source=params.duration_sec/duration_minutes"
  fi
}



# ============================================================
# M10.99L_DURATION_WATCHDOG
# ------------------------------------------------------------
# M10.99K fixed payload shape: hours=0, duration_sec=300.
# M10.99L actively enforces runtime duration:
# - wait duration_sec
# - kill the exact experiment worker
# - complete current start_run command
# - enqueue default analytics if resume_after=true
# ============================================================
coded_m1099l_start_duration_watchdog() {
  local params_json="${1:-}"
  local lifecycle_id="${2:-}"
  local command_id="${3:-}"
  local worker="${4:-}"
  local run_log="${5:-/tmp/coded_m1099l_duration_watchdog.log}"

  local mode=""
  local duration_sec=""
  local duration_min=""
  local resume_after=""
  local threshold=""
  local threads=""
  local batch_size=""
  local audit_rate=""
  local default_worker=""
  local default_threshold=""
  local default_payload=""

  mode="$(echo "$params_json" | jq -r '.mode // empty' 2>/dev/null || true)"
  duration_sec="$(echo "$params_json" | jq -r '.duration_sec // empty' 2>/dev/null || true)"
  duration_min="$(echo "$params_json" | jq -r '.duration_minutes // empty' 2>/dev/null || true)"
  resume_after="$(echo "$params_json" | jq -r '.resume_after // false' 2>/dev/null || echo false)"
  threshold="$(echo "$params_json" | jq -r '.threshold // empty' 2>/dev/null || true)"
  threads="$(echo "$params_json" | jq -r '.threads // 31' 2>/dev/null || echo 31)"
  batch_size="$(echo "$params_json" | jq -r '.batch_size // 4000' 2>/dev/null || echo 4000)"
  audit_rate="$(echo "$params_json" | jq -r '.audit_rate // 500' 2>/dev/null || echo 500)"

  if [ -z "$duration_sec" ] || [ "$duration_sec" = "null" ]; then
    if [ -n "$duration_min" ] && [ "$duration_min" != "null" ]; then
      duration_min="${duration_min%.*}"
      if [ "$duration_min" -gt 0 ] 2>/dev/null; then
        duration_sec=$(( duration_min * 60 ))
      fi
    fi
  fi

  # Only enforce finite experiment runs.
  if [ "$mode" != "experiment" ]; then
    return 0
  fi
  if [ -z "$duration_sec" ] || [ "$duration_sec" = "null" ] || ! [ "$duration_sec" -gt 0 ] 2>/dev/null; then
    return 0
  fi
  if [ -z "$worker" ]; then
    echo "[M10.99L_DURATION_WATCHDOG] skip: empty worker lifecycle=$lifecycle_id command=$command_id" | tee -a "$run_log"
    return 0
  fi

  echo "[M10.99L_DURATION_WATCHDOG] armed worker=$worker duration_sec=$duration_sec lifecycle=$lifecycle_id command=$command_id resume_after=$resume_after" | tee -a "$run_log"

  (
    sleep "$duration_sec"

    echo "[M10.99L_DURATION_WATCHDOG] elapsed worker=$worker duration_sec=$duration_sec lifecycle=$lifecycle_id command=$command_id" | tee -a "$run_log"

    # Kill only the miner process with the exact worker argument.
    pkill -TERM -f "coded-miner .*--worker ${worker}" 2>/dev/null || true
    sleep 5
    pkill -KILL -f "coded-miner .*--worker ${worker}" 2>/dev/null || true

    # Complete the experiment start_run.
    if [ -n "$lifecycle_id" ]; then
      coded_complete_command_id "$lifecycle_id" "{\"status\":\"completed\",\"stage\":\"m1099l_duration_elapsed\",\"worker_name\":\"$worker\",\"duration_sec\":$duration_sec,\"resume_after\":$resume_after,\"lifecycle\":\"M10.99L\"}" || true
    fi
    if [ -n "$command_id" ] && [ "$command_id" != "$lifecycle_id" ]; then
      coded_complete_command_id "$command_id" "{\"status\":\"completed\",\"stage\":\"m1099l_duration_elapsed_command_id_fallback\",\"worker_name\":\"$worker\",\"duration_sec\":$duration_sec,\"resume_after\":$resume_after,\"lifecycle\":\"M10.99L\"}" || true
    fi

    # Enqueue default analytics resume.
    if [ "$resume_after" = "true" ]; then
      default_threshold="${CODED_DEFAULT_THRESHOLD:-$threshold}"
      if [ -z "$default_threshold" ] || [ "$default_threshold" = "null" ]; then
        default_threshold="510"
      fi

      default_worker="${CODED_DEFAULT_WORKER:-${RIG_ID}_DEFAULT_ANALYTICS_T${default_threshold}}"

      default_payload="$(jq -cn \
        --arg rig "$RIG_ID" \
        --arg worker "$default_worker" \
        --arg source_worker "$worker" \
        --argjson threshold "$default_threshold" \
        --argjson threads "$threads" \
        --argjson batch_size "$batch_size" \
        --argjson audit_rate "$audit_rate" \
        '{
          rig_id:$rig,
          command_type:"start_run",
          params:{
            mode:"analytics_baseline",
            experiment_id:"DEFAULT_ANALYTICS_AFTER_M1099L_DURATION",
            worker_name:$worker,
            threshold:$threshold,
            threads:$threads,
            batch_size:$batch_size,
            audit_rate:$audit_rate,
            hours:8760,
            resume_after:true,
            fallback:true,
            fallback_profile:"analytics_baseline",
            priority:"critical",
            profile_source:"m1099l_duration_watchdog",
            previous_worker_name:$source_worker
          }
        }')"

      resp="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "$default_payload" || true)"

      echo "[M10.99L_DURATION_WATCHDOG] default_resume_resp=$resp" | tee -a "$run_log"
    fi
  ) >> "$run_log" 2>&1 &

  echo "[M10.99L_DURATION_WATCHDOG] pid=$! worker=$worker duration_sec=$duration_sec" | tee -a "$run_log"
}



# ============================================================
# M10.99M_ENV_FORWARDING_HARDENING
# ------------------------------------------------------------
# start_run/git_experiment_run params.env must become real
# coded-miner process environment. Required for routers such as:
# CODED_PRIORITY_BUDGET_ROUTER=M1098D
# ============================================================
coded_m1099m_export_params_env() {
  local params_json="${1:-}"
  local run_log="${2:-/tmp/coded_m1099m_env_forwarding.log}"

  if [ -z "$params_json" ]; then
    echo "[M10.99M_ENV_FORWARDING] no params_json" | tee -a "$run_log"
    return 0
  fi

  local env_json
  env_json="$(echo "$params_json" | jq -c '.env // {}' 2>/dev/null || echo '{}')"

  if [ -z "$env_json" ] || [ "$env_json" = "null" ] || [ "$env_json" = "{}" ]; then
    echo "[M10.99M_ENV_FORWARDING] no params.env found" | tee -a "$run_log"
  else
    echo "[M10.99M_ENV_FORWARDING] applying params.env=$env_json" | tee -a "$run_log"

    while IFS='=' read -r key value; do
      if [ -z "$key" ]; then
        continue
      fi

      case "$key" in
        *[!A-Za-z0-9_]* | [0-9]*)
          echo "[M10.99M_ENV_FORWARDING] skip invalid env key=$key" | tee -a "$run_log"
          continue
          ;;
      esac

      export "$key=$value"
      echo "[M10.99M_ENV_FORWARDING] export $key=$value" | tee -a "$run_log"
    done < <(echo "$env_json" | jq -r 'to_entries[] | "\(.key)=\(.value|tostring)"' 2>/dev/null || true)
  fi

  # Critical router default: only default if still unset after params.env.
  export CODED_PRIORITY_BUDGET_ROUTER="${CODED_PRIORITY_BUDGET_ROUTER:-M1098C}"

  echo "[CODED] PRIORITY_BUDGET_ROUTER=${CODED_PRIORITY_BUDGET_ROUTER}" | tee -a "$run_log"
}



# ============================================================
# M10.99O_CODED_ENV_DEBUG
# ------------------------------------------------------------
# Print final CODED_* environment directly before coded-miner starts.
# This must run in the same shell context as the miner launch.
# ============================================================
coded_m1099o_debug_env_before_launch() {
  local worker="${1:-unknown}"
  local run_log="${2:-/tmp/coded_m1099o_env_debug.log}"

  echo "[M10.99O_CODED_ENV_DEBUG] before_launch worker=$worker" | tee -a "$run_log"
  echo "[CODED_ENV_DEBUG] CODED_PRIORITY_BUDGET_ROUTER=${CODED_PRIORITY_BUDGET_ROUTER:-unset}" | tee -a "$run_log"

  env | grep -E '^CODED_' | sort | sed 's/^/[CODED_ENV_DEBUG] /' | tee -a "$run_log" || true
}



# ============================================================
# M10.99Q_PRIORITY_ROUTER_RESOLVER
# ------------------------------------------------------------
# Final priority budget router resolver.
# M10.99P proved final launch hook is correct, but PARAMS.env can be
# missing by the time start_run is picked. Therefore resolve from:
# - params.env.CODED_PRIORITY_BUDGET_ROUTER
# - params.CODED_PRIORITY_BUDGET_ROUTER / params.priority_budget_router
# - worker_name / experiment_id containing M1098D
# - otherwise existing env/default M1098C
# ============================================================
coded_m1099q_resolve_priority_budget_router() {
  local params_json="${1:-}"
  local worker="${2:-}"
  local run_log="${3:-/tmp/coded_m1099q_priority_router.log}"

  local env_router=""
  local direct_router=""
  local lower_router=""
  local exp_id=""
  local resolved=""

  if [ -n "$params_json" ]; then
    env_router="$(echo "$params_json" | jq -r '.env.CODED_PRIORITY_BUDGET_ROUTER // empty' 2>/dev/null || true)"
    direct_router="$(echo "$params_json" | jq -r '.CODED_PRIORITY_BUDGET_ROUTER // empty' 2>/dev/null || true)"
    lower_router="$(echo "$params_json" | jq -r '.priority_budget_router // .router // empty' 2>/dev/null || true)"
    exp_id="$(echo "$params_json" | jq -r '.experiment_id // empty' 2>/dev/null || true)"
  fi

  if [ -n "$env_router" ] && [ "$env_router" != "null" ]; then
    resolved="$env_router"
  elif [ -n "$direct_router" ] && [ "$direct_router" != "null" ]; then
    resolved="$direct_router"
  elif [ -n "$lower_router" ] && [ "$lower_router" != "null" ]; then
    resolved="$lower_router"
  elif echo "${worker:-} ${exp_id:-}" | grep -q "M1098D"; then
    resolved="M1098D"
  elif echo "${worker:-} ${exp_id:-}" | grep -q "M1098C"; then
    resolved="M1098C"
  else
    resolved="${CODED_PRIORITY_BUDGET_ROUTER:-M1098C}"
  fi

  export CODED_PRIORITY_BUDGET_ROUTER="$resolved"

  echo "[M10.99Q_PRIORITY_ROUTER_RESOLVER] worker=${worker:-unknown} experiment_id=${exp_id:-} env_router=${env_router:-} direct_router=${direct_router:-} lower_router=${lower_router:-} resolved=$CODED_PRIORITY_BUDGET_ROUTER" | tee -a "$run_log"
}


# M10.97B5_2_1_RUNTIME_HELPERS
# ------------------------------------------------------------
# Safety helpers used by newer start_run paths. These must exist
# before any default/experiment launch branch calls them.
# ============================================================
coded_apply_start_run_params_override() {
  return 0
}

coded_enforce_expected_worker_before_launch() {
  local expected_worker="${EXPECTED_WORKER_NAME:-${DESIRED_WORKER_NAME:-}}"
  local actual_worker="${WORKER_NAME:-${WORKER:-}}"

  if [ -n "$expected_worker" ] && [ -n "$actual_worker" ] && [ "$expected_worker" != "$actual_worker" ]; then
    echo "[M10.97B5.2.1_WORKER_GUARD] mismatch expected=$expected_worker actual=$actual_worker"
    return 1
  fi

  return 0
}


coded_complete_command_id() {
  local CID="$1"
  local RESULT="${2:-{}}"
  [ -z "$CID" ] && return 0
  curl -s -X POST "$CODED_API_ROOT/commands/$CID/complete" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"result\":$RESULT}" >/dev/null || true
}



# ============================================================
# M10.90B Robust Release Builder
# ============================================================

coded_fail_command() {
  local CID="$1"
  local ERR="$2"
  local RESULT="${3:-{}}"

  [ -z "$CID" ] && return 0

  curl -s -X POST "$CODED_API_ROOT/commands/$CID/fail" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"error\":\"$ERR\",\"result\":$RESULT}" >/dev/null || true
}

coded_complete_command() {
  local CID="$1"
  local RESULT="${2:-{}}"

  [ -z "$CID" ] && return 0

  curl -s -X POST "$CODED_API_ROOT/commands/$CID/complete" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"result\":$RESULT}" >/dev/null || true
}

# ============================================================
# M10.94A Strict Release Command Completion
# ============================================================
# Release builds are operator-critical. A successful public release must
# always finalize the command as completed/success, otherwise the admin
# dashboard shows a false picked_up/stale release.
coded_complete_release_command_strict() {
  local command_id="$1"
  local version="$2"
  local build_log="$3"
  local command_type="$4"
  local payload resp ok status attempt

  payload="{\"command_id\":\"$command_id\",\"result\":{\"status\":\"success\",\"release\":\"$version\",\"version\":\"$version\",\"log\":\"$build_log\",\"repo\":\"CodedOnQubic/coded-miner-release\",\"github_release\":\"https://github.com/CodedOnQubic/coded-miner-release/releases/tag/$version\",\"artifacts\":[\"coded-miner-latest.tar.gz\",\"coded-miner-docker-linux-amd64.tar.gz\"],\"validation\":\"ok\",\"builder\":\"$RIG_ID\",\"command_type\":\"$command_type\",\"auto_finalized\":\"M10.94A\"}}"

  for attempt in 1 2 3 4 5; do
    resp="$(curl -s -X POST "$CODED_API_ROOT/commands/$command_id/complete" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "$payload" || true)"

    ok="$(echo "$resp" | jq -r '.ok // false' 2>/dev/null || echo false)"
    status="$(echo "$resp" | jq -r '.data.status // .command.status // empty' 2>/dev/null || true)"

    echo "[M10.94A_RELEASE_COMPLETE] attempt=$attempt command=$command_id version=$version ok=$ok status=$status resp=$resp" | tee -a "$build_log"

    if [ "$ok" = "true" ] || [ "$status" = "completed" ]; then
      return 0
    fi

    sleep 2
  done

  return 1
}


coded_release_guard() {
  local VERSION="$1"
  local BUILD_LOG="$2"
  local RELEASE_REPO_DIR="/hive/coded-miner-release"

  echo "[M10.90B_RELEASE] validating release version=$VERSION" >> "$BUILD_LOG"

  if [ ! -f "$RELEASE_REPO_DIR/coded-miner-latest.tar.gz" ]; then
    echo "[M10.90B_RELEASE][ERROR] missing coded-miner-latest.tar.gz" >> "$BUILD_LOG"
    return 11
  fi

  if [ ! -s "$RELEASE_REPO_DIR/coded-miner-latest.tar.gz" ]; then
    echo "[M10.90B_RELEASE][ERROR] empty coded-miner-latest.tar.gz" >> "$BUILD_LOG"
    return 12
  fi

  if [ -f "$RELEASE_REPO_DIR/coded-miner-docker-linux-amd64.tar.gz" ] && [ ! -s "$RELEASE_REPO_DIR/coded-miner-docker-linux-amd64.tar.gz" ]; then
    echo "[M10.90B_RELEASE][ERROR] empty docker tarball" >> "$BUILD_LOG"
    return 13
  fi

  (
    cd "$RELEASE_REPO_DIR" || exit 14
    echo "[M10.90B_RELEASE] git status before final check:" >> "$BUILD_LOG"
    git status --short >> "$BUILD_LOG" 2>&1 || exit 15
    echo "[M10.90B_RELEASE] latest commits:" >> "$BUILD_LOG"
    git log --oneline -5 >> "$BUILD_LOG" 2>&1 || exit 16
  )

  echo "[M10.90B_RELEASE] validation ok version=$VERSION" >> "$BUILD_LOG"
  return 0
}


# ============================================================
# M10.93A Local Runtime State
# ============================================================
# Purpose:
# - make CODED_ANALYTICS=YES rigs self-healing
# - remember default profile / active profile locally
# - allow restart/reboot recovery without entering the rig
# - prepare experiment/build pause/resume semantics

CODED_STATE_FILE="${CODED_STATE_FILE:-/hive/codedonqubic/.coded-fleet-state.json}"

coded_json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

coded_state_write() {
  local state="$1"
  mkdir -p "$(dirname "$CODED_STATE_FILE")" 2>/dev/null || true
  printf '%s\n' "$state" > "$CODED_STATE_FILE" 2>/dev/null || true
}

coded_state_show() {
  if [ -f "$CODED_STATE_FILE" ]; then
    cat "$CODED_STATE_FILE" 2>/dev/null || true
  else
    echo "{}"
  fi
}

coded_state_set_active_profile() {
  local run_id="$1"
  local command_id="$2"
  local worker_name="$3"
  local mode="$4"
  local threshold="$5"
  local hours="$6"
  local threads="$7"
  local batch_size="$8"
  local audit_rate="$9"

  local now
  now="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

  coded_state_write "{\"rig_id\":\"$(coded_json_escape "$RIG_ID")\",\"state\":\"active\",\"active_run_id\":\"$(coded_json_escape "$run_id")\",\"active_command_id\":\"$(coded_json_escape "$command_id")\",\"active_worker\":\"$(coded_json_escape "$worker_name")\",\"active_profile\":{\"mode\":\"$(coded_json_escape "$mode")\",\"threshold\":${threshold:-510},\"hours\":${hours:-8760},\"threads\":${threads:-0},\"batch_size\":${batch_size:-4000},\"audit_rate\":${audit_rate:-500},\"worker_name\":\"$(coded_json_escape "$worker_name")\"},\"updated_at\":\"$now\"}"
}

coded_state_set_idle() {
  local reason="$1"
  local now
  now="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

  coded_state_write "{\"rig_id\":\"$(coded_json_escape "$RIG_ID")\",\"state\":\"idle\",\"reason\":\"$(coded_json_escape "$reason")\",\"updated_at\":\"$now\"}"
}

coded_default_threshold() {
  case "$RIG_ID" in
    Rig1X3D) echo "${CODED_DEFAULT_THRESHOLD:-509}" ;;
    Rig2X3D) echo "${CODED_DEFAULT_THRESHOLD:-510}" ;;
    Rig3X)   echo "${CODED_DEFAULT_THRESHOLD:-509}" ;;
    Rig4X)   echo "${CODED_DEFAULT_THRESHOLD:-510}" ;;
    Rig5X3D) echo "${CODED_DEFAULT_THRESHOLD:-510}" ;;
    Rig6X3D) echo "${CODED_DEFAULT_THRESHOLD:-511}" ;;
    *)       echo "${CODED_DEFAULT_THRESHOLD:-510}" ;;
  esac
}

coded_default_worker_name() {
  local t="$1"
  if [ -n "${CODED_DEFAULT_WORKER:-}" ]; then
    echo "$CODED_DEFAULT_WORKER"
  else
    echo "${RIG_ID}_DEFAULT_ANALYTICS_T${t}"
  fi
}

coded_has_miner_process() {
  pgrep -f "coded-miner.*--worker" >/dev/null 2>&1
}

coded_fetch_backend_default_profile() {
  curl -s "$API/fleet/default-profile/$RIG_ID" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" || true
}

coded_enqueue_default_analytics() {
  local profile_resp ok enabled t worker hours threads batch audit mode priority payload resp source

  # M10.93C Backend Default Profile
  # Backend is the source of truth for default analytics profiles.
  # Local defaults remain as offline safety fallback.
  profile_resp="$(coded_fetch_backend_default_profile)"
  ok="$(echo "$profile_resp" | jq -r ".ok // false" 2>/dev/null || echo false)"
  enabled="$(echo "$profile_resp" | jq -r ".profile.enabled // true" 2>/dev/null || echo true)"

  if [ "$ok" = "true" ] && [ "$enabled" = "true" ]; then
    t="$(echo "$profile_resp" | jq -r ".profile.threshold // 510")"
    worker="$(echo "$profile_resp" | jq -r ".profile.worker_name // empty")"
    hours="$(echo "$profile_resp" | jq -r ".profile.hours // 8760")"
    threads="$(echo "$profile_resp" | jq -r ".profile.threads // empty")"
    batch="$(echo "$profile_resp" | jq -r ".profile.batch_size // 4000")"
    audit="$(echo "$profile_resp" | jq -r ".profile.audit_rate // 500")"
    mode="$(echo "$profile_resp" | jq -r ".profile.mode // \"analytics_baseline\"")"
    priority="$(echo "$profile_resp" | jq -r ".profile.priority // \"normal\"")"
    source="backend"
  else
    t="$(coded_default_threshold)"
    worker="$(coded_default_worker_name "$t")"
    hours="${CODED_DEFAULT_HOURS:-8760}"
    threads="${CODED_DEFAULT_THREADS:-$THREADS}"
    batch="${CODED_DEFAULT_BATCH_SIZE:-4000}"
    audit="${CODED_DEFAULT_AUDIT_RATE:-500}"
    mode="analytics_baseline"
    priority="normal"
    source="local_fallback"
  fi

  [ -z "$worker" ] || [ "$worker" = "null" ] && worker="$(coded_default_worker_name "$t")"
  [ -z "$threads" ] || [ "$threads" = "null" ] && threads="${CODED_DEFAULT_THREADS:-$THREADS}"
  [ -z "$hours" ] || [ "$hours" = "null" ] && hours="${CODED_DEFAULT_HOURS:-8760}"
  [ -z "$batch" ] || [ "$batch" = "null" ] && batch="${CODED_DEFAULT_BATCH_SIZE:-4000}"
  [ -z "$audit" ] || [ "$audit" = "null" ] && audit="${CODED_DEFAULT_AUDIT_RATE:-500}"

  payload="{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":{\"mode\":\"$mode\",\"experiment_id\":\"DEFAULT_ANALYTICS_BASELINE\",\"fallback\":true,\"resume_after\":true,\"priority\":\"$priority\",\"profile_source\":\"$source\",\"threshold\":$t,\"hours\":$hours,\"threads\":$threads,\"batch_size\":$batch,\"audit_rate\":$audit,\"worker_name\":\"$worker\"}}"

  resp="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "$payload" || true)"

  echo "[M10.93C_DEFAULT] enqueued default analytics source=$source rig=$RIG_ID worker=$worker threshold=$t resp=$resp"
}

coded_ensure_default_when_idle() {
  # If a miner process exists, do nothing. Runtime is source of truth.
  if coded_has_miner_process; then
    return 0
  fi

  # If a pending/running command exists, let the backend queue handle it.
  # This function is called only after a no-command poll.
  coded_enqueue_default_analytics
  return 0
}


echo "[CODED_FLEET] agent mode enabled"

  API="${CODED_ANALYTICS_API:-https://api.codedonqubic.com/analytics}"
  TOKEN="${CODED_ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}"
  RIG_ID="${CODED_RIG_ID:-$(hostname)}"

  CPU_MODEL="$(lscpu | grep "Model name" | sed "s/.*: *//" | head -1)"
  CPU_THREADS="$(nproc)"
  RAM_MB="$(free -m | awk '/Mem:/ {print $2}')"
  AVX2=false
  AVX512=false
  grep -m1 flags /proc/cpuinfo | grep -qw avx2 && AVX2=true
  grep -m1 flags /proc/cpuinfo | grep -qw avx512f && AVX512=true
  HPT="$(grep HugePages_Total /proc/meminfo | awk "{print \$2}")"
  HPF="$(grep HugePages_Free /proc/meminfo | awk "{print \$2}")"

  curl -s -X POST "$API/rigs/register" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"rig_id\":\"$RIG_ID\",\"rig_name\":\"$RIG_ID\",\"hostname\":\"$(hostname)\",\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2_supported\":$AVX2,\"avx512_supported\":$AVX512,\"hugepages_total\":${HPT:-0},\"hugepages_free\":${HPF:-0},\"threads\":$THREADS}" || true

  echo "[CODED_FLEET] registered RIG_ID=$RIG_ID"
  echo "[CODED_FLEET] waiting for backend commands"

  while true; do
    CMD="$(curl -s "$API/commands/next/$RIG_ID" -H "Authorization: Bearer $TOKEN" || true)"
    COMMAND_ID="$(echo "$CMD" | jq -r ".command.command_id // empty")"

    if [ -z "$COMMAND_ID" ]; then
      # M10.93A: If fleet mode is idle and no backend command exists,
      # ensure this rig always returns to a default analytics run.
      coded_ensure_default_when_idle
      sleep 30
      continue
    fi

    COMMAND_TYPE="$(echo "$CMD" | jq -r ".command.command_type // empty")"

    # M10.91B Fleet Idle Fallback Hook
    # If backend has no command and no miner is running, enqueue fallback.
    if [ -z "$COMMAND_TYPE" ] || [ "$COMMAND_TYPE" = "null" ]; then
      coded_ensure_fleet_idle_fallback
      sleep 5
      continue
    fi

    if [ "$COMMAND_TYPE" = "git_experiment_run" ]; then
      COMMAND_DB_ID="$(echo "$CMD" | jq -r ".command.id // .id // empty")"
      COMMAND_LIFECYCLE_ID="${COMMAND_DB_ID:-$COMMAND_ID}"
      echo "[M10.96G8C_GITEXP_DB_ID] command_id=$COMMAND_ID db_id=$COMMAND_DB_ID lifecycle_id=$COMMAND_LIFECYCLE_ID"


      # ============================================================
      # M10.97B5_TOP_LEVEL_DIRECT_ENQUEUE
      # ------------------------------------------------------------
      # git_experiment_run is a launcher/control command only.
      # For normal experiment runs (build_before_run != true), enqueue
      # a start_run immediately here, before legacy build/heartbeat flow.
      # ============================================================

      B5_BUILD_BEFORE_RUN="$(echo "$CMD" | jq -r '.command.params.build_before_run // .params.build_before_run // "false"' 2>/dev/null || echo "false")"

      if [ "$B5_BUILD_BEFORE_RUN" != "true" ]; then
        B5_WORKER_NAME="$(echo "$CMD" | jq -r '.command.params.worker_name // .params.worker_name // empty' 2>/dev/null || true)"
        B5_EXPERIMENT_ID="$(echo "$CMD" | jq -r '.command.params.experiment_id // .params.experiment_id // "M1097B5_EXPERIMENT"' 2>/dev/null || echo "M1097B5_EXPERIMENT")"
        B5_BACKEND="$(echo "$CMD" | jq -r '.command.params.backend // .params.backend // "avx512"' 2>/dev/null || echo "avx512")"
        B5_THRESHOLD="$(echo "$CMD" | jq -r '.command.params.threshold // .params.threshold // 510' 2>/dev/null || echo "510")"
        B5_THREADS="$(echo "$CMD" | jq -r '.command.params.threads // .params.threads // 31' 2>/dev/null || echo "31")"
        B5_BATCH_SIZE="$(echo "$CMD" | jq -r '.command.params.batch_size // .params.batch_size // 4000' 2>/dev/null || echo "4000")"
        B5_AUDIT_RATE="$(echo "$CMD" | jq -r '.command.params.audit_rate // .params.audit_rate // 500' 2>/dev/null || echo "500")"
        B5_DURATION_MINUTES_RAW="$(echo "$CMD" | jq -r '.command.params.duration_minutes // .params.duration_minutes // 10' 2>/dev/null || echo "10")"

        [ -z "$B5_WORKER_NAME" ] && B5_WORKER_NAME="${RIG_ID}_M1097B5_DIRECT_T${B5_THRESHOLD}"

        B5_DURATION_MINUTES_INT="${B5_DURATION_MINUTES_RAW%.*}"
        case "$B5_DURATION_MINUTES_INT" in ''|*[!0-9]*) B5_DURATION_MINUTES_INT=10 ;; esac
        case "$B5_THRESHOLD" in ''|*[!0-9]*) B5_THRESHOLD=510 ;; esac
        case "$B5_THREADS" in ''|*[!0-9]*) B5_THREADS=31 ;; esac
        case "$B5_BATCH_SIZE" in ''|*[!0-9]*) B5_BATCH_SIZE=4000 ;; esac
        case "$B5_AUDIT_RATE" in ''|*[!0-9]*) B5_AUDIT_RATE=500 ;; esac

        # M10.97B5_2_EXPERIMENT_LIFECYCLE:
        # duration_minutes/duration_sec are authoritative for experiment lifecycle.
        # hours remains only a coarse fallback for older launch paths.
        B5_HOURS=$(( (B5_DURATION_MINUTES_INT + 59) / 60 ))
        [ "$B5_HOURS" -lt 1 ] && B5_HOURS=1
        B5_DURATION_SEC=$(( B5_DURATION_MINUTES_INT * 60 ))
        [ "$B5_DURATION_SEC" -lt 60 ] && B5_DURATION_SEC=60

        echo "[M10.97B5.2_GIT_EXPERIMENT] top_level_direct_enqueue begin command_id=$COMMAND_ID lifecycle_id=$COMMAND_LIFECYCLE_ID worker=$B5_WORKER_NAME threshold=$B5_THRESHOLD duration_minutes=$B5_DURATION_MINUTES_INT duration_sec=$B5_DURATION_SEC"

        # M10.97B5_ENV_FORWARD: preserve research env/expected_logs into generated start_run.
        B5_ENV_JSON="$(echo "$CMD" | jq -c '.command.params.env // .params.env // {}' 2>/dev/null || echo '{}')"
        B5_EXPECTED_LOGS_JSON="$(echo "$CMD" | jq -c '.command.params.expected_logs // .params.expected_logs // []' 2>/dev/null || echo '[]')"
        B5_RESEARCH_GOAL="$(echo "$CMD" | jq -r '.command.params.research_goal // .params.research_goal // empty' 2>/dev/null || true)"

        B5_START_PARAMS="$(jq -n \
          --arg mode "experiment" \
          --arg experiment_id "$B5_EXPERIMENT_ID" \
          --arg worker_name "$B5_WORKER_NAME" \
          --arg backend "$B5_BACKEND" \
          --arg profile_source "git_experiment_run_top_level_direct_enqueue_M10.97B5" \
          --arg source_command_type "git_experiment_run" \
          --arg launcher "M10.97B5" \
          --arg research_goal "$B5_RESEARCH_GOAL" \
          --argjson threshold "$B5_THRESHOLD" \
          --argjson hours "$B5_HOURS" \
          --argjson duration_minutes "$B5_DURATION_MINUTES_INT" \
          --argjson duration_sec "$B5_DURATION_SEC" \
          --argjson threads "$B5_THREADS" \
          --argjson batch_size "$B5_BATCH_SIZE" \
          --argjson audit_rate "$B5_AUDIT_RATE" \
          --argjson env "$B5_ENV_JSON" \
          --argjson expected_logs "$B5_EXPECTED_LOGS_JSON" \
          '{mode:$mode, experiment_id:$experiment_id, worker_name:$worker_name, backend:$backend, threshold:$threshold, hours:0, duration_minutes:$duration_minutes, duration_sec:$duration_sec, threads:$threads, batch_size:$batch_size, audit_rate:$audit_rate, env:$env, expected_logs:$expected_logs, research_goal:$research_goal, resume_after:true, fallback:true, fallback_profile:"analytics_baseline", priority:"experiment", profile_source:$profile_source, source_command_type:$source_command_type, launcher:$launcher, lifecycle:"M10.97B5.2"}')"

        B5_CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":$B5_START_PARAMS}" || true)"

        echo "[M10.97B5_GIT_EXPERIMENT] start_run_create_resp=$B5_CREATE_RESP"
        echo "[M10.99M_ENV_FORWARDING] b5_start_run_env=$B5_ENV_JSON worker=$B5_WORKER_NAME experiment=$B5_EXPERIMENT_ID" | tee -a "${BUILD_LOG:-/tmp/coded_m1099m_env_forwarding.log}"

        echo "[M10.97B5.2_GIT_EXPERIMENT] start_run_create_resp=$B5_CREATE_RESP"

        B5_START_RUN_COMMAND_ID="$(echo "$B5_CREATE_RESP" | jq -r '.data.command_id // .command.command_id // empty' 2>/dev/null || true)"
        B5_START_RUN_DB_ID="$(echo "$B5_CREATE_RESP" | jq -r '.data.id // .command.id // empty' 2>/dev/null || true)"
        B5_CREATE_RESP_SAFE="$(printf '%s' "$B5_CREATE_RESP" | jq -Rs . 2>/dev/null || echo "\"unparseable_create_response\"")"

        if [ -z "$B5_START_RUN_COMMAND_ID" ]; then
          coded_fail_command "$COMMAND_LIFECYCLE_ID" "M10.97B5 failed to enqueue experiment start_run" "{\"status\":\"failed\",\"stage\":\"m1097b5_top_level_direct_enqueue\",\"worker_name\":\"$B5_WORKER_NAME\",\"experiment_id\":\"$B5_EXPERIMENT_ID\",\"create_response\":$B5_CREATE_RESP_SAFE}" || true
          coded_resume_default_after_gitexp "m1097b5_top_level_direct_enqueue_failed" || true
          sleep 5
          continue
        fi

        coded_complete_command_id "$COMMAND_LIFECYCLE_ID" "{\"status\":\"start_run_enqueued\",\"stage\":\"m1097b5_2_top_level_direct_experiment_start_run_enqueued\",\"start_run_command_id\":\"$B5_START_RUN_COMMAND_ID\",\"start_run_db_id\":\"$B5_START_RUN_DB_ID\",\"worker_name\":\"$B5_WORKER_NAME\",\"experiment_id\":\"$B5_EXPERIMENT_ID\",\"backend\":\"$B5_BACKEND\",\"threshold\":$B5_THRESHOLD,\"duration_minutes\":$B5_DURATION_MINUTES_INT,\"duration_sec\":$B5_DURATION_SEC,\"resume_after\":true,\"build_before_run\":false,\"lifecycle\":\"M10.97B5.2\"}" || true

        echo "[M10.97B5_GIT_EXPERIMENT] completed command_id=$COMMAND_ID start_run_command_id=$B5_START_RUN_COMMAND_ID worker=$B5_WORKER_NAME"
        # M10.99K: ensure git_experiment_run launcher does not remain running.
        coded_complete_command_id "$COMMAND_LIFECYCLE_ID" "{\"status\":\"start_run_enqueued\",\"stage\":\"m1099k_git_experiment_launcher_completed\",\"start_run_command_id\":\"$B5_START_RUN_COMMAND_ID\",\"worker_name\":\"$B5_WORKER_NAME\",\"experiment_id\":\"$B5_EXPERIMENT_ID\",\"duration_sec\":$B5_DURATION_SEC,\"lifecycle\":\"M10.99K\"}" || true

        if [ -n "${COMMAND_ID:-}" ] && [ "${COMMAND_ID:-}" != "${COMMAND_LIFECYCLE_ID:-}" ]; then
          coded_complete_command_id "$COMMAND_ID" "{\"status\":\"start_run_enqueued\",\"stage\":\"m1099k_git_experiment_launcher_completed_command_id_fallback\",\"start_run_command_id\":\"$B5_START_RUN_COMMAND_ID\",\"worker_name\":\"$B5_WORKER_NAME\",\"experiment_id\":\"$B5_EXPERIMENT_ID\",\"duration_sec\":$B5_DURATION_SEC,\"lifecycle\":\"M10.99K\"}" || true
        fi


        echo "[M10.99L_LAUNCHER_CLEANUP] git_experiment_run should be completed command_id=$COMMAND_ID lifecycle_id=$COMMAND_LIFECYCLE_ID start_run=$B5_START_RUN_COMMAND_ID worker=$B5_WORKER_NAME duration_sec=$B5_DURATION_SEC" | tee -a "${BUILD_LOG:-/tmp/coded_m1099l_launcher_cleanup.log}"

        echo "[M10.97B5.2_GIT_EXPERIMENT] completed command_id=$COMMAND_ID stage=m1097b5_2_top_level_direct_experiment_start_run_enqueued start_run_command_id=$B5_START_RUN_COMMAND_ID duration_sec=$B5_DURATION_SEC worker=$B5_WORKER_NAME"
        sleep 5
        continue
      fi

      echo "[M10.97B5_GIT_EXPERIMENT] build_before_run=true; allowing legacy build path command_id=$COMMAND_ID"

      echo "[M10.96G6_GIT_EXPERIMENT_TOP_LEVEL] picked command_id=$COMMAND_ID"
      echo "[M10.96G_GIT_EXPERIMENT] picked command_id=$COMMAND_ID"

      PARAMS="$(echo "$CMD" | jq -c ".command.params // {}")"
      BRANCH="$(echo "$PARAMS" | jq -r ".branch // \"dev\"")"
      WORKER_NAME="$(echo "$PARAMS" | jq -r ".worker_name // (env.RIG_ID + \"_GIT_EXPERIMENT\")")"
      EXPERIMENT_ID="$(echo "$PARAMS" | jq -r ".experiment_id // \"GIT_EXPERIMENT\"")"
      BACKEND="$(echo "$PARAMS" | jq -r ".backend // \"avx512\"")"
      THRESHOLD="$(echo "$PARAMS" | jq -r ".threshold // 510")"
      THREADS="$(echo "$PARAMS" | jq -r ".threads // 31")"
      BATCH_SIZE="$(echo "$PARAMS" | jq -r ".batch_size // 4000")"
      AUDIT_RATE="$(echo "$PARAMS" | jq -r ".audit_rate // 500")"
      DURATION_MINUTES="$(echo "$PARAMS" | jq -r ".duration_minutes // 120")"
      CMAKE_FLAGS="$(echo "$PARAMS" | jq -r ".cmake_flags // \"-DCMAKE_BUILD_TYPE=Release -DCODED_ENABLE_AVX2=ON -DCODED_ENABLE_AVX512=ON\"")"

      BUILD_LOG="/tmp/coded_git_experiment_${RIG_ID}_${EXPERIMENT_ID}_$(date -u +%Y%m%d_%H%M%S).log"
      MINER_DIR="/hive/codedonqubic"
      [ -d "$MINER_DIR/.git" ] || MINER_DIR="/hive/miners/custom/coded-miner"

      coded_mark_command_running "$COMMAND_LIFECYCLE_ID" || true
      HEARTBEAT_PID="$(coded_command_heartbeat_bg "$COMMAND_LIFECYCLE_ID" "$BUILD_LOG")"

      echo "[M10.97B4_GIT_EXPERIMENT] running command_id=$COMMAND_ID lifecycle_id=$COMMAND_LIFECYCLE_ID heartbeat_pid=$HEARTBEAT_PID" | tee -a "$BUILD_LOG"

      # ============================================================
      # M10.97B4: Direct fast enqueue for git_experiment_run
      # ------------------------------------------------------------
      # Critical rule:
      # git_experiment_run is a launcher/control command only.
      # Runtime begins only after a real start_run is created.
      #
      # Normal experiment path:
      #   1) extract params directly from CMD JSON
      #   2) POST start_run
      #   3) complete git_experiment_run with start_run_command_id
      #   4) continue fleet loop
      #
      # Legacy build path is only allowed when build_before_run=true.
      # ============================================================

      B4_BUILD_BEFORE_RUN="$(echo "$CMD" | jq -r '.command.params.build_before_run // .params.build_before_run // "false"' 2>/dev/null || echo "false")"

      if [ "$B4_BUILD_BEFORE_RUN" != "true" ]; then
        B4_WORKER_NAME="$(echo "$CMD" | jq -r '.command.params.worker_name // .params.worker_name // empty' 2>/dev/null || true)"
        B4_EXPERIMENT_ID="$(echo "$CMD" | jq -r '.command.params.experiment_id // .params.experiment_id // "M1097B4_EXPERIMENT"' 2>/dev/null || echo "M1097B4_EXPERIMENT")"
        B4_BACKEND="$(echo "$CMD" | jq -r '.command.params.backend // .params.backend // "avx512"' 2>/dev/null || echo "avx512")"
        B4_THRESHOLD="$(echo "$CMD" | jq -r '.command.params.threshold // .params.threshold // 510' 2>/dev/null || echo "510")"
        B4_THREADS="$(echo "$CMD" | jq -r '.command.params.threads // .params.threads // 31' 2>/dev/null || echo "31")"
        B4_BATCH_SIZE="$(echo "$CMD" | jq -r '.command.params.batch_size // .params.batch_size // 4000' 2>/dev/null || echo "4000")"
        B4_AUDIT_RATE="$(echo "$CMD" | jq -r '.command.params.audit_rate // .params.audit_rate // 500' 2>/dev/null || echo "500")"
        B4_DURATION_MINUTES_RAW="$(echo "$CMD" | jq -r '.command.params.duration_minutes // .params.duration_minutes // 10' 2>/dev/null || echo "10")"

        [ -z "$B4_WORKER_NAME" ] && B4_WORKER_NAME="${RIG_ID}_M1097B4_FAST_T${B4_THRESHOLD}"

        B4_DURATION_MINUTES_INT="${B4_DURATION_MINUTES_RAW%.*}"
        case "$B4_DURATION_MINUTES_INT" in ''|*[!0-9]*) B4_DURATION_MINUTES_INT=10 ;; esac
        case "$B4_THRESHOLD" in ''|*[!0-9]*) B4_THRESHOLD=510 ;; esac
        case "$B4_THREADS" in ''|*[!0-9]*) B4_THREADS=31 ;; esac
        case "$B4_BATCH_SIZE" in ''|*[!0-9]*) B4_BATCH_SIZE=4000 ;; esac
        case "$B4_AUDIT_RATE" in ''|*[!0-9]*) B4_AUDIT_RATE=500 ;; esac

        B4_HOURS=$(( (B4_DURATION_MINUTES_INT + 59) / 60 ))
        [ "$B4_HOURS" -lt 1 ] && B4_HOURS=1

        echo "[M10.97B4_GIT_EXPERIMENT] direct_enqueue begin command_id=$COMMAND_ID worker=$B4_WORKER_NAME threshold=$B4_THRESHOLD duration_minutes=$B4_DURATION_MINUTES_INT" | tee -a "$BUILD_LOG"

        B4_START_PARAMS="$(jq -n \
          --arg mode "experiment" \
          --arg experiment_id "$B4_EXPERIMENT_ID" \
          --arg worker_name "$B4_WORKER_NAME" \
          --arg backend "$B4_BACKEND" \
          --arg profile_source "git_experiment_run_direct_enqueue_M10.97B4" \
          --arg source_command_type "git_experiment_run" \
          --arg launcher "M10.97B4" \
          --argjson threshold "$B4_THRESHOLD" \
          --argjson hours "$B4_HOURS" \
          --argjson threads "$B4_THREADS" \
          --argjson batch_size "$B4_BATCH_SIZE" \
          --argjson audit_rate "$B4_AUDIT_RATE" \
          '{mode:$mode, experiment_id:$experiment_id, worker_name:$worker_name, backend:$backend, threshold:$threshold, hours:$hours, threads:$threads, batch_size:$batch_size, audit_rate:$audit_rate, resume_after:true, fallback:true, fallback_profile:"analytics_baseline", priority:"experiment", profile_source:$profile_source, source_command_type:$source_command_type, launcher:$launcher}')"

        B4_CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":$B4_START_PARAMS}" || true)"

        echo "[M10.97B4_GIT_EXPERIMENT] start_run_create_resp=$B4_CREATE_RESP" | tee -a "$BUILD_LOG"

        B4_START_RUN_COMMAND_ID="$(echo "$B4_CREATE_RESP" | jq -r '.data.command_id // .command.command_id // empty' 2>/dev/null || true)"
        B4_START_RUN_DB_ID="$(echo "$B4_CREATE_RESP" | jq -r '.data.id // .command.id // empty' 2>/dev/null || true)"
        B4_CREATE_RESP_SAFE="$(printf '%s' "$B4_CREATE_RESP" | jq -Rs . 2>/dev/null || echo "\"unparseable_create_response\"")"

        [ -n "${HEARTBEAT_PID:-}" ] && kill "$HEARTBEAT_PID" >/dev/null 2>&1 || true

        if [ -z "$B4_START_RUN_COMMAND_ID" ]; then
          coded_fail_command "$COMMAND_LIFECYCLE_ID" "M10.97B4 failed to enqueue experiment start_run" "{\"status\":\"failed\",\"stage\":\"m1097b4_direct_enqueue_start_run\",\"worker_name\":\"$B4_WORKER_NAME\",\"experiment_id\":\"$B4_EXPERIMENT_ID\",\"create_response\":$B4_CREATE_RESP_SAFE}" || true
          coded_resume_default_after_gitexp "m1097b4_direct_enqueue_failed" || true
          sleep 5
          continue
        fi

        coded_complete_command_id "$COMMAND_LIFECYCLE_ID" "{\"status\":\"start_run_enqueued\",\"stage\":\"m1097b4_direct_experiment_start_run_enqueued\",\"start_run_command_id\":\"$B4_START_RUN_COMMAND_ID\",\"start_run_db_id\":\"$B4_START_RUN_DB_ID\",\"worker_name\":\"$B4_WORKER_NAME\",\"experiment_id\":\"$B4_EXPERIMENT_ID\",\"backend\":\"$B4_BACKEND\",\"threshold\":$B4_THRESHOLD,\"log\":\"$BUILD_LOG\",\"resume_after\":true,\"build_before_run\":false}" || true

        echo "[M10.97B4_GIT_EXPERIMENT] completed command_id=$COMMAND_ID start_run_command_id=$B4_START_RUN_COMMAND_ID worker=$B4_WORKER_NAME" | tee -a "$BUILD_LOG"
        sleep 5
        continue
      fi

      echo "[M10.97B4_GIT_EXPERIMENT] build_before_run=true; entering legacy build path" | tee -a "$BUILD_LOG"


      echo "[M10.96G_GIT_EXPERIMENT] dir=$MINER_DIR branch=$BRANCH worker=$WORKER_NAME backend=$BACKEND threshold=$THRESHOLD" | tee -a "$BUILD_LOG"

      BACKUP="/hive/miners/custom/coded-miner/coded-miner.backup.$(date -u +%Y%m%d_%H%M%S)"
      if [ -x "/hive/miners/custom/coded-miner/coded-miner" ]; then
        cp "/hive/miners/custom/coded-miner/coded-miner" "$BACKUP" || true
      fi

      (
        set -e
        cd "$MINER_DIR"
        git fetch origin
        git checkout "$BRANCH"
        git pull --ff-only origin "$BRANCH"
        rm -rf build
        cmake -S . -B build $CMAKE_FLAGS
        cmake --build build -j
        cp build/coded-miner /hive/miners/custom/coded-miner/coded-miner
        chmod +x /hive/miners/custom/coded-miner/coded-miner
      ) >>"$BUILD_LOG" 2>&1
      EC=$?

      if [ "$EC" != "0" ]; then
        echo "[M10.96G_GIT_EXPERIMENT] build failed ec=$EC backup=$BACKUP log=$BUILD_LOG" | tee -a "$BUILD_LOG"
        [ -f "$BACKUP" ] && cp "$BACKUP" /hive/miners/custom/coded-miner/coded-miner || true
        coded_fail_command "$COMMAND_LIFECYCLE_ID" "git_experiment_run build failed" "{\"status\":\"failed\",\"stage\":\"build\",\"exit_code\":$EC,\"log\":\"$BUILD_LOG\",\"backup\":\"$BACKUP\"}" || true
        coded_resume_default_after_gitexp "git_experiment_build_failed"
        sleep 5
        continue
      fi

      START_PARAMS="$(jq -n \
        --arg mode "experiment" \
        --arg experiment_id "$EXPERIMENT_ID" \
        --arg worker_name "$WORKER_NAME" \
        --arg backend "$BACKEND" \
        --argjson threshold "$THRESHOLD" \
        --argjson hours "$(python3 - <<PY2
import math, os
print(max(1, math.ceil(float(os.environ.get("DURATION_MINUTES","120"))/60)))
PY2
)" \
        --argjson threads "$THREADS" \
        --argjson batch_size "$BATCH_SIZE" \
        --argjson audit_rate "$AUDIT_RATE" \
        '{mode:$mode, experiment_id:$experiment_id, worker_name:$worker_name, backend:$backend, threshold:$threshold, hours:$hours, threads:$threads, batch_size:$batch_size, audit_rate:$audit_rate, resume_after:true, fallback_profile:"analytics_baseline", profile_source:"git_experiment_run"}')"

      CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":$START_PARAMS}" || true)"

      echo "[M10.97B4_GIT_EXPERIMENT] start_run_create_resp=$CREATE_RESP" | tee -a "$BUILD_LOG"

      START_RUN_COMMAND_ID="$(echo "$CREATE_RESP" | jq -r '.data.command_id // .command.command_id // empty' 2>/dev/null || true)"
      START_RUN_DB_ID="$(echo "$CREATE_RESP" | jq -r '.data.id // .command.id // empty' 2>/dev/null || true)"

      [ -n "${HEARTBEAT_PID:-}" ] && kill "$HEARTBEAT_PID" >/dev/null 2>&1 || true

      if [ -z "$START_RUN_COMMAND_ID" ]; then
        coded_fail_command "$COMMAND_LIFECYCLE_ID" "git_experiment_run failed to enqueue start_run" "{\"status\":\"failed\",\"stage\":\"enqueue_start_run\",\"worker_name\":\"$WORKER_NAME\",\"experiment_id\":\"$EXPERIMENT_ID\",\"create_response\":$CREATE_RESP}" || true
        coded_resume_default_after_gitexp "git_experiment_start_run_enqueue_failed" || true
        sleep 5
        continue
      fi

      coded_complete_command_id "$COMMAND_LIFECYCLE_ID" "{\"status\":\"start_run_enqueued\",\"stage\":\"git_build_completed_start_run_enqueued\",\"start_run_command_id\":\"$START_RUN_COMMAND_ID\",\"start_run_db_id\":\"$START_RUN_DB_ID\",\"worker_name\":\"$WORKER_NAME\",\"experiment_id\":\"$EXPERIMENT_ID\",\"backend\":\"$BACKEND\",\"threshold\":$THRESHOLD,\"log\":\"$BUILD_LOG\",\"backup\":\"$BACKUP\",\"resume_after\":true}" || true

      echo "[M10.97B4_GIT_EXPERIMENT] completed command_id=$COMMAND_ID enqueued start_run worker=$WORKER_NAME resume_after=true" | tee -a "$BUILD_LOG"
      sleep 5
      continue
    fi

    if [ "$COMMAND_TYPE" = "build_hive_release" ] || [ "$COMMAND_TYPE" = "build_release" ]; then
      VERSION="$(echo "$CMD" | jq -r ".command.params.version // empty")"
      [ -z "$VERSION" ] && VERSION="v0.0.0-dev"

      BUILD_LOG="/tmp/coded_hive_release_${VERSION}.log"
      echo "[CODED_RELEASE] building Hive release VERSION=$VERSION" | tee "$BUILD_LOG"

      (
        set -e
        cd /hive/codedonqubic
        git fetch origin main
        git reset --hard origin/main
        chmod +x ./scripts/release_hiveos.sh
        export GH_CONFIG_DIR="/root/.config/gh"
        export HOME="/root"

        ./scripts/release.sh "$VERSION" linux/amd64

        ASSETS="$(find /hive/coded-miner-release -maxdepth 1 -type f \( -name "coded-miner-latest.tar.gz" -o -name "coded-miner-docker-linux-amd64.tar.gz" \) | sort -u | tr "\n" " ")"
        if [ -z "$ASSETS" ]; then
          echo "[CODED_RELEASE] no release assets found in /hive/coded-miner-release"
          find /hive/coded-miner-release -maxdepth 2 -type f
          exit 2
        fi

        echo "[CODED_RELEASE] assets: $ASSETS"

        if gh release view "$VERSION" --repo CodedOnQubic/coded-miner-release >/dev/null 2>&1; then
          gh release upload "$VERSION" $ASSETS --repo CodedOnQubic/coded-miner-release --clobber
          gh release edit "$VERSION" --repo CodedOnQubic/coded-miner-release --draft=false
        else
          gh release create "$VERSION" $ASSETS \
            --repo CodedOnQubic/coded-miner-release \
            --title "$VERSION" \
            --notes "HiveOS fleet analytics release $VERSION" \
            --target main
        fi
      ) >> "$BUILD_LOG" 2>&1

      EC=$?

      if [ "$EC" = "0" ]; then
        coded_release_guard "$VERSION" "$BUILD_LOG"
        GUARD_EC=$?
        if [ "$GUARD_EC" != "0" ]; then
          EC="$GUARD_EC"
          echo "[M10.90B_RELEASE] guard failed VERSION=$VERSION guard_exit=$GUARD_EC" >> "$BUILD_LOG"
        fi
      fi

      if [ "$EC" = "0" ]; then
        if coded_complete_release_command_strict "$COMMAND_ID" "$VERSION" "$BUILD_LOG" "$COMMAND_TYPE"; then
          echo "[M10.94A_RELEASE_COMPLETE] finalized command=$COMMAND_ID version=$VERSION" | tee -a "$BUILD_LOG"
        else
          coded_fail_command "$COMMAND_ID" "release succeeded but command completion failed" "{\"status\":\"release_success_command_completion_failed\",\"release\":\"$VERSION\",\"log\":\"$BUILD_LOG\",\"repo\":\"CodedOnQubic/coded-miner-release\",\"builder\":\"$RIG_ID\",\"command_type\":\"$COMMAND_TYPE\"}"
        fi
        echo "[CODED_RELEASE] completed VERSION=$VERSION"
      else
        coded_fail_command "$COMMAND_ID" "release build failed or validation failed" "{\"version\":\"$VERSION\",\"log\":\"$BUILD_LOG\",\"exit_code\":$EC,\"builder\":\"$RIG_ID\",\"command_type\":\"$COMMAND_TYPE\"}"
        echo "[CODED_RELEASE] failed VERSION=$VERSION exit=$EC"
      fi

      continue
    fi

    THRESHOLD="$(echo "$CMD" | jq -r ".command.params.threshold // 510")"
    HOURS="$(echo "$CMD" | jq -r ".command.params.hours // 8")"
JOB_THREADS="$(echo "$CMD" | jq -r ".command.params.threads // empty")"
if [ -n "$JOB_THREADS" ] && echo "$JOB_THREADS" | grep -Eq "^[0-9]+$"; then
  THREADS="$JOB_THREADS"
fi
    BATCH="$(echo "$CMD" | jq -r ".command.params.batch_size // 4000")"
    AUDIT="$(echo "$CMD" | jq -r ".command.params.audit_rate // 500")"
    RUN_WORKER="$(echo "$CMD" | jq -r ".command.params.worker_name // empty")"
    [ -z "$RUN_WORKER" ] && RUN_WORKER="${WORKER}_T${THRESHOLD}"
    RUN_MODE="$(echo "$CMD" | jq -r ".command.params.mode // \"experiment\"")"

    RUN_ID="M1084_${RIG_ID}_T${THRESHOLD}_$(date +%Y%m%d_%H%M%S)"
    RUN_LOG="$LOG_DIR/${RUN_ID}.log"
    # ============================================================
    # M10.96G8AB float-safe HOURS duration
    # ============================================================
    # Experiment runs may use fractional hours, e.g. 0.3333333333.
    # Bash arithmetic is integer-only, so convert via awk before END.
    RUN_DURATION_SEC="$(awk -v h="${HOURS:-24}" 'BEGIN { if (h <= 0) h = 24; printf "%d", h * 3600 }' 2>/dev/null || echo 86400)"
    [ -z "$RUN_DURATION_SEC" ] && RUN_DURATION_SEC=86400
    [ "$RUN_DURATION_SEC" -lt 60 ] 2>/dev/null && RUN_DURATION_SEC=60
    END=$((SECONDS + RUN_DURATION_SEC))
    echo "[M10.96G8AB_DURATION] command=$COMMAND_ID hours=${HOURS:-} duration_sec=$RUN_DURATION_SEC" | tee -a "$RUN_LOG"
  if [ -n "${PARAMS:-}" ]; then coded_m1099k_apply_duration_override "$PARAMS" || true; fi
  if [ -n "${PARAMS:-}" ]; then coded_m1099m_export_params_env "$PARAMS" "${RUN_LOG:-/tmp/coded_m1099m_env_forwarding.log}" || true; fi
  if [ -n "${PARAMS:-}" ]; then coded_m1099l_start_duration_watchdog "$PARAMS" "${COMMAND_LIFECYCLE_ID:-$COMMAND_ID}" "${COMMAND_ID:-}" "${WORKER_NAME:-$WORKER}" "${RUN_LOG:-/tmp/coded_m1099l_duration_watchdog.log}" || true; fi

    # ============================================================
    # M10.96G8Y command-branch worker override
    # ============================================================
    # This is the active /commands/next start_run branch.
    # Apply command params after RUN_WORKER/THRESHOLD/BACKEND parsing
    # and before the M10.91C launch loop.
    coded_apply_start_run_params_override || true
    coded_enforce_expected_worker_before_launch || true
    echo "[M10.96G8Y_COMMAND_BRANCH_OVERRIDE] command=$COMMAND_ID worker=$RUN_WORKER threads=$THREADS threshold=$THRESHOLD backend=${BACKEND:-}" | tee -a "$RUN_LOG"

    export CODED_FAST_SHADOW_THRESHOLD="$THRESHOLD"
    export CODED_FAST_SHADOW_AUDIT_RATE="$AUDIT"
    export CODED_BATCH_SIZE="$BATCH"
    export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"
    export CODED_RANDOM2_HUGEPAGE="${CODED_RANDOM2_HUGEPAGE:-1}"
    export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
    export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
    export CODED_SCORE_SAMPLE_BATCH_RATE="${CODED_SCORE_SAMPLE_BATCH_RATE:-0}"
    export CODED_SHADOW_AVX512_LIVE="${CODED_SHADOW_AVX512_LIVE:-1}"
    export CODED_LOG_MODE="${CODED_LOG_MODE:-dev}"

    curl -s -X POST "$API/runs/start" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"miner_version\":\"m10.84b-fleet-agent\",\"backend\":\"$CODED_KERNEL_BACKEND\",\"threshold\":$THRESHOLD,\"threads\":$THREADS,\"batch_size\":$BATCH,\"audit_rate\":$AUDIT,\"gate_mode\":\"single\",\"hostname\":\"$(hostname)\",\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2_supported\":$AVX2,\"avx512_supported\":$AVX512,\"hugepages_total\":${HPT:-0},\"hugepages_free\":${HPF:-0},\"hardware\":{\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2\":$AVX2,\"avx512\":$AVX512}}" >/dev/null || true

    coded_state_set_active_profile "$RUN_ID" "$COMMAND_ID" "$RUN_WORKER" "$RUN_MODE" "$THRESHOLD" "$HOURS" "$THREADS" "$BATCH" "$AUDIT"

    echo "[CODED_FLEET] starting command=$COMMAND_ID run=$RUN_ID mode=$RUN_MODE threshold=$THRESHOLD hours=$HOURS"

    (
      set +e

      while true; do

        [ ! -f "$RUN_LOG" ] && sleep 5 && continue
        sleep 60

        # Uploader is intentionally independent from miner PID.
        # The miner may restart inside the command window.
        SUMMARY="$(grep "FAST_SHADOW_SUMMARY" "$RUN_LOG" | tail -n 1 || true)"
        MULTI="$(grep "FAST_SHADOW_MULTILEVEL" "$RUN_LOG" | tail -n 1 || true)"
        HIST="$(grep "FAST_SHADOW_HISTOGRAM" "$RUN_LOG" | tail -n 1 || true)"
        POLICY="$(grep "FAST_SHADOW_POLICY" "$RUN_LOG" | tail -n 1 || true)"
        BUDGET="$(grep "PRIORITY_BUDGET_ROUTER" "$RUN_LOG" | tail -n 1 || true)"
        SOLS="$(grep "SOLS:" "$RUN_LOG" | tail -n 1 || true)"
        HI="$(grep "HI_TIMING_SUMMARY" "$RUN_LOG" | tail -n 1 || true)"
        [ -z "$SUMMARY" ] && continue

        extract(){ echo "$SUMMARY" | grep -oP "$1=\K[0-9.]+" | tail -n 1 || true; }

        TOTAL_SEEN="$(extract total_seen)"
        TOTAL_PASS="$(extract total_pass)"
        TOTAL_SKIP="$(extract total_skip)"
        TOTAL_AUDITED="$(extract total_audited)"
        FALSE_NEG="$(extract false_negative)"
        MAX_PASS="$(extract max_real_score_passed)"
        MAX_SKIP="$(extract max_real_score_audited_skip)"
        PASSRATE="$(extract pass_rate)"
        SKIPRATE="$(extract skip_rate)"
        AUDITRATE_OBS="$(extract audit_rate)"
        S280="$(extract pass_280_289)"
        S290="$(extract pass_290_299)"
        S300="$(extract pass_300_309)"
        S310="$(extract pass_310_320)"
        S321="$(extract pass_321_plus)"

        AVG_ITS="$(echo "$SOLS" | grep -oP "\| [0-9]+ avg it/s" | grep -oP "[0-9]+" | tail -n 1 || true)"
        LAST_ITS="$(echo "$SOLS" | grep -oP "\] [0-9]+ it/s" | grep -oP "[0-9]+" | tail -n 1 || true)"
        ALGO0_AVG="$(echo "$HI" | grep -oP "algo0_avg_ms=\K[0-9.]+" | tail -n 1 || true)"

        curl -s -X POST "$API/runs/heartbeat" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"status\":\"running\",\"avg_its\":${AVG_ITS:-0},\"last_its\":${LAST_ITS:-0},\"active_backend\":\"$CODED_KERNEL_BACKEND\"}" >/dev/null || true

        curl -s -X POST "$API/runs/summary" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"run_id\":\"$RUN_ID\",\"total_seen\":${TOTAL_SEEN:-0},\"total_pass\":${TOTAL_PASS:-0},\"total_skip\":${TOTAL_SKIP:-0},\"total_audited\":${TOTAL_AUDITED:-0},\"false_negative\":${FALSE_NEG:-0},\"max_real_score_passed\":${MAX_PASS:-0},\"max_real_score_audited_skip\":${MAX_SKIP:-0},\"pass_rate\":${PASSRATE:-0},\"skip_rate\":${SKIPRATE:-0},\"audit_rate\":${AUDITRATE_OBS:-0},\"avg_its\":${AVG_ITS:-0},\"last_its\":${LAST_ITS:-0},\"algo0_avg_ms\":${ALGO0_AVG:-0}}" >/dev/null || true

        # M10.86 Statistical Fleet Analysis Engine
        # Same analytics pipeline as runs/summary: miner stdout -> wrapper parser -> pool-api -> Supabase.
        MAX_SCORE="$MAX_PASS"
        if [ "${MAX_SKIP:-0}" -gt "${MAX_SCORE:-0}" ] 2>/dev/null; then
          MAX_SCORE="$MAX_SKIP"
        fi

        SCORE_DIST_PAYLOAD="{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"epoch\":${EPOCH:-0},\"backend\":\"$CODED_KERNEL_BACKEND\",\"cpu_model\":\"$CPU_MODEL\",\"threshold\":${THRESHOLD:-0},\"threads\":${THREADS:-0},\"batch_size\":${BATCH:-0},\"audit_rate\":${AUDIT:-0},\"total_seen\":${TOTAL_SEEN:-0},\"total_pass\":${TOTAL_PASS:-0},\"total_skip\":${TOTAL_SKIP:-0},\"total_audited\":${TOTAL_AUDITED:-0},\"false_negative\":${FALSE_NEG:-0},\"max_score\":${MAX_SCORE:-0},\"max_pass_score\":${MAX_PASS:-0},\"max_audited_skip_score\":${MAX_SKIP:-0},\"score_260_269\":0,\"score_270_279\":0,\"score_280_289\":${S280:-0},\"score_290_299\":${S290:-0},\"score_300_309\":${S300:-0},\"score_310_320\":${S310:-0},\"score_321_plus\":${S321:-0},\"raw\":{\"source\":\"fleet_uploader\"}}"
        SCORE_DIST_RESP="$(curl -s -X POST "$API/score-distribution" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "$SCORE_DIST_PAYLOAD" || true)"
        echo "[M10.86_SCORE_DIST] run=$RUN_ID resp=$SCORE_DIST_RESP"

        # M10.89B Shadow Policy uploader
        # Miner stdout -> fleet wrapper -> pool-api -> Supabase.
        if [ -n "$POLICY" ]; then
          for PNAME in baseline elite509 hard511 dual510511; do
            P_PASS="$(echo "$POLICY" | grep -oP "${PNAME}_pass=\\K[0-9]+" | tail -n 1 || true)"

            # M10.92A extended shadow policy uploader metrics
            P_280="$(echo "$POLICY" | grep -oP "${PNAME}_real280=\\K[0-9]+" | tail -n 1 || true)"
            P_290="$(echo "$POLICY" | grep -oP "${PNAME}_real290=\\K[0-9]+" | tail -n 1 || true)"
            P_300="$(echo "$POLICY" | grep -oP "${PNAME}_real300=\\K[0-9]+" | tail -n 1 || true)"
            P_310="$(echo "$POLICY" | grep -oP "${PNAME}_real310=\\K[0-9]+" | tail -n 1 || true)"
            P_321="$(echo "$POLICY" | grep -oP "${PNAME}_real321=\\K[0-9]+" | tail -n 1 || true)"

            P_PASS_PER_SEEN="null"
            P_300_PER_PASS="null"
            P_310_PER_PASS="null"
            if [ "${TOTAL_SEEN:-0}" -gt 0 ] 2>/dev/null; then
              P_PASS_PER_SEEN="$(awk -v p="${P_PASS:-0}" -v s="${TOTAL_SEEN:-0}" 'BEGIN{ if(s>0) printf "%.12f", p/s; else print "null" }')"
            fi
            if [ "${P_PASS:-0}" -gt 0 ] 2>/dev/null; then
              P_300_PER_PASS="$(awk -v r="${P_300:-0}" -v p="${P_PASS:-0}" 'BEGIN{ if(p>0) printf "%.12f", r/p; else print "null" }')"
              P_310_PER_PASS="$(awk -v r="${P_310:-0}" -v p="${P_PASS:-0}" 'BEGIN{ if(p>0) printf "%.12f", r/p; else print "null" }')"
            fi

            POLICY_RESP="$(curl -s -X POST "$API/shadow-policy" \
              -H "Authorization: Bearer $TOKEN" \
              -H "Content-Type: application/json" \
              -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"threshold\":${THRESHOLD:-0},\"policy_name\":\"$PNAME\",\"pass\":${P_PASS:-0},\"real280\":${P_280:-0},\"real290\":${P_290:-0},\"real300\":${P_300:-0},\"real310\":${P_310:-0},\"real321\":${P_321:-0},\"pass_per_seen\":${P_PASS_PER_SEEN:-null},\"real300_per_pass\":${P_300_PER_PASS:-null},\"real310_per_pass\":${P_310_PER_PASS:-null},\"raw\":{\"source\":\"fleet_uploader\",\"line\":\"FAST_SHADOW_POLICY\",\"m10_92a\":true}}" || true)"

            echo "[M10.89_POLICY] run=$RUN_ID policy=$PNAME resp=$POLICY_RESP"
          done
        fi

        # M10.88B Shadow Histogram uploader
        # Same pipeline as runs/summary, score-distribution and multilevel-shadow.
        if [ -n "$HIST" ]; then
          for SS in $(seq 480 520); do
            H_TOTAL="$(echo "$HIST" | grep -oP "s${SS}=\\K[0-9]+" | tail -n 1 || true)"
            H_300="$(echo "$HIST" | grep -oP "s300_${SS}=\\K[0-9]+" | tail -n 1 || true)"
            H_310="$(echo "$HIST" | grep -oP "s310_${SS}=\\K[0-9]+" | tail -n 1 || true)"
            H_321="$(echo "$HIST" | grep -oP "s321_${SS}=\\K[0-9]+" | tail -n 1 || true)"

            HIST_RESP="$(curl -s -X POST "$API/shadow-histogram" \
              -H "Authorization: Bearer $TOKEN" \
              -H "Content-Type: application/json" \
              -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"threshold\":${THRESHOLD:-0},\"shadow_score\":${SS},\"total\":${H_TOTAL:-0},\"real300\":${H_300:-0},\"real310\":${H_310:-0},\"real321\":${H_321:-0},\"raw\":{\"source\":\"fleet_uploader\",\"line\":\"FAST_SHADOW_HISTOGRAM\"}}" || true)"

            echo "[M10.88_HISTOGRAM] run=$RUN_ID shadow=$SS resp=$HIST_RESP"
          done
        fi

        # M10.88A Priority Budget Router uploader
        # Miner stdout -> fleet wrapper -> pool-api -> Supabase.
        # Captures full [PRIORITY_BUDGET_ROUTER] lines once per uploader loop.
        if [ -n "$BUDGET" ]; then
          bval(){
            local v
            v="$(echo "$BUDGET" | grep -oP "$1=\K[0-9.]+" | tail -n 1 || true)"
            [ -n "$v" ] && echo "$v" || echo 0
          }

          bstr(){
            local v
            v="$(echo "$BUDGET" | grep -oP "$1=\K[^[:space:]]+" | tail -n 1 || true)"
            [ -n "$v" ] && echo "$v" || echo unknown
          }

          json_escape(){
            python3 -c 'import json,sys; print(json.dumps(sys.stdin.read())[1:-1])'
          }

          PB_VERSION="$(bstr version)"
          PB_MATRIX="$(bstr matrix)"
          PB_RAW_ESCAPED="$(printf '%s' "$BUDGET" | json_escape)"

          PB_PAYLOAD="{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"threshold\":${THRESHOLD:-0},\"version\":\"${PB_VERSION:-unknown}\",\"matrix\":\"${PB_MATRIX:-unknown}\""

          for PC in 0 1 2 3; do
            PB_PAYLOAD="$PB_PAYLOAD,\"p${PC}_seen\":$(bval p${PC}_seen),\"p${PC}_scored\":$(bval p${PC}_scored),\"p${PC}_skipped\":$(bval p${PC}_skipped),\"p${PC}_score_rate\":$(bval p${PC}_score_rate),\"p${PC}_real280\":$(bval p${PC}_real280),\"p${PC}_real290\":$(bval p${PC}_real290),\"p${PC}_real300\":$(bval p${PC}_real300),\"p${PC}_real310\":$(bval p${PC}_real310),\"p${PC}_real321\":$(bval p${PC}_real321),\"p${PC}_d300\":$(bval p${PC}_d300),\"p${PC}_d321\":$(bval p${PC}_d321)"
          done

          PB_PAYLOAD="$PB_PAYLOAD,\"audited_skip\":$(bval audited_skip),\"false_negative\":$(bval false_negative),\"raw\":{\"source\":\"fleet_uploader\",\"line\":\"$PB_RAW_ESCAPED\",\"m10_88a\":true}}"

          PB_RESP="$(curl -sS --connect-timeout 3 --max-time 8 -X POST "$API/priority-budget" \
            -H "Authorization: Bearer $TOKEN" \
            -H "Content-Type: application/json" \
            -d "$PB_PAYLOAD" || true)"

          echo "[M10.88A_PRIORITY_BUDGET] run=$RUN_ID version=${PB_VERSION:-unknown} matrix=${PB_MATRIX:-unknown} resp=$PB_RESP"
        fi

        # M10.87E Multi-Level Shadow uploader
        # Same pipeline as runs/summary and score-distribution.
        if [ -n "$MULTI" ]; then
          for VT in 505 507 509 510 511 513 515 518 520; do
            ML_TOTAL="$(echo "$MULTI" | grep -oP "survive_${VT}=\\K[0-9]+" | tail -n 1 || true)"
            ML_300="$(echo "$MULTI" | grep -oP "survive_300_plus_${VT}=\\K[0-9]+" | tail -n 1 || true)"
            ML_310="$(echo "$MULTI" | grep -oP "survive_310_plus_${VT}=\\K[0-9]+" | tail -n 1 || true)"
            ML_321="$(echo "$MULTI" | grep -oP "survive_321_plus_${VT}=\\K[0-9]+" | tail -n 1 || true)"

            ML_RESP="$(curl -s -X POST "$API/multilevel-shadow" \
              -H "Authorization: Bearer $TOKEN" \
              -H "Content-Type: application/json" \
              -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"threshold\":${THRESHOLD:-0},\"virtual_threshold\":${VT},\"survive_total\":${ML_TOTAL:-0},\"survive_300_plus\":${ML_300:-0},\"survive_310_plus\":${ML_310:-0},\"survive_321_plus\":${ML_321:-0},\"raw\":{\"source\":\"fleet_uploader\",\"line\":\"FAST_SHADOW_MULTILEVEL\"}}" || true)"

            echo "[M10.87_MULTILEVEL] run=$RUN_ID vt=$VT resp=$ML_RESP"
          done
        fi
      done
    ) >/tmp/coded_fleet_uploader_${RUN_ID}.log 2>&1 &
    UPLOADER_PID=$!

    echo "[CODED_FLEET] uploader pid=$UPLOADER_PID log=/tmp/coded_fleet_uploader_${RUN_ID}.log"

    # ============================================================
    # M10.90A Interruptible Fleet Agent
    # ============================================================
    # Run miner in restartable slices so high-priority commands
    # such as stop_run/build_release can interrupt a long run.
    INTERRUPT_CMD=""
    INTERRUPT_TYPE=""

    # M10.91C Launcher Command Completion
    # start_run is a launcher command, not the runtime source of truth.
    # Runtime truth is miner_run_dashboard / runs heartbeat.
    START_RUN_LAUNCH_COMPLETED=0

    while [ "$SECONDS" -lt "$END" ]; do
      coded_apply_start_run_params_override || true
      coded_enforce_expected_worker_before_launch || true
      # ============================================================
      # M10.96G8U launch-loop worker override
      # ============================================================
      # This is the actual runtime launch path. Apply command params
      # immediately before miner execution so experiment start_run cannot
      # be overwritten by default analytics profile values.
      coded_apply_start_run_params_override || true
      coded_enforce_expected_worker_before_launch || true
      echo "[M10.96G8U_LAUNCH_LOOP_OVERRIDE] command=$COMMAND_ID run=$RUN_ID worker=$RUN_WORKER threads=$THREADS threshold=$THRESHOLD backend=${BACKEND:-}" | tee -a "$RUN_LOG"

      # ============================================================
      # M10.99P_FINAL_MINER_LAUNCH_ENV
      # ------------------------------------------------------------
      # Last possible point before the actual coded-miner process.
      # params.env must be authoritative here.
      # ============================================================
      if [ -n "${PARAMS:-}" ]; then
        coded_m1099m_export_params_env "$PARAMS" "$RUN_LOG" || true
      fi

      coded_m1099n_assert_launch_env "${PARAMS:-}" "$RUN_WORKER" "$RUN_LOG" || true
      coded_m1099o_debug_env_before_launch "$RUN_WORKER" "$RUN_LOG" || true

      coded_m1099q_resolve_priority_budget_router "${PARAMS:-}" "$RUN_WORKER" "$RUN_LOG" || true

      echo "[M10.99P_FINAL_MINER_LAUNCH_ENV] worker=$RUN_WORKER CODED_PRIORITY_BUDGET_ROUTER=${CODED_PRIORITY_BUDGET_ROUTER:-unset} CODED_ANALYTICS=${CODED_ANALYTICS:-unset}" | tee -a "$RUN_LOG"

      "$MINER_BIN" --pool "$POOL" --wallet "$WALLET" --worker "$RUN_WORKER" --threads "$THREADS" 2>&1 | tee -a "$RUN_LOG" &
      MINER_PID=$!

      # M10.91C Launcher Command Completion
      # Complete start_run once the miner process is confirmed alive.
      # Do not keep the command running for the full mining duration.
      if [ "$START_RUN_LAUNCH_COMPLETED" != "1" ]; then
        sleep 3
        if kill -0 "$MINER_PID" 2>/dev/null; then
          coded_complete_command "$COMMAND_ID" "{\"status\":\"launched\",\"run_id\":\"$RUN_ID\",\"worker_name\":\"$RUN_WORKER\",\"threshold\":$THRESHOLD,\"runtime_tracking\":\"miner_run_dashboard\",\"launcher\":\"M10.91C\"}"
          START_RUN_LAUNCH_COMPLETED=1
          echo "[M10.91C_LAUNCHER] command completed as launched command=$COMMAND_ID run=$RUN_ID worker=$RUN_WORKER" | tee -a "$RUN_LOG"
        else
          echo "[M10.91C_LAUNCHER] miner did not stay alive after launch command=$COMMAND_ID run=$RUN_ID" | tee -a "$RUN_LOG"
        fi
      fi

      while kill -0 "$MINER_PID" 2>/dev/null; do
        sleep 30

        if coded_check_interrupt_command; then
          echo "[M10.90A_INTERRUPT] stopping miner pid=$MINER_PID for type=$INTERRUPT_TYPE" | tee -a "$RUN_LOG"
        # ============================================================
        # M10.96G8G all-stop-markers git_experiment_run handoff
        # ============================================================
        # Fleet-scale invariant:
        # - default analytics must always be resumable
        # - git_experiment_run must be insertable while default is mining
        # - stop_run with next_git_experiment_params must enqueue experiment
        #   from the same stop branch that actually runs on the rig
        if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
          NEXT_TYPE="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.next_command_type // empty" 2>/dev/null || true)"
          if [ "$NEXT_TYPE" = "git_experiment_run" ]; then
            NEXT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params.next_git_experiment_params // empty" 2>/dev/null || true)"
            STOP_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // .id // empty" 2>/dev/null || true)"
            STOP_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty" 2>/dev/null || true)"
            STOP_LIFECYCLE_ID="${STOP_DB_ID:-$STOP_COMMAND_ID}"

            echo "[M10.96G8G_ALL_STOP_MARKERS_HANDOFF] reached stop branch stop_db_id=$STOP_DB_ID stop_command_id=$STOP_COMMAND_ID lifecycle=$STOP_LIFECYCLE_ID next_type=$NEXT_TYPE params=$NEXT_PARAMS" | tee -a "$RUN_LOG"

            if [ -n "$NEXT_PARAMS" ] && [ "$NEXT_PARAMS" != "null" ]; then
              CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$NEXT_PARAMS}" || true)"

              echo "[M10.96G8G_ALL_STOP_MARKERS_HANDOFF] create_git_experiment_resp=$CREATE_RESP" | tee -a "$RUN_LOG"

              coded_complete_command_id "$STOP_LIFECYCLE_ID" "{\"status\":\"completed\",\"stage\":\"all_stop_markers_git_experiment_enqueued\",\"orchestration\":\"M10.96G8G\"}" || true

              echo "[M10.96G8G_ALL_STOP_MARKERS_HANDOFF] completed stop_run and enqueued git_experiment_run" | tee -a "$RUN_LOG"
            else
              echo "[M10.96G8G_ALL_STOP_MARKERS_HANDOFF] missing next_git_experiment_params" | tee -a "$RUN_LOG"
              coded_fail_command "$STOP_LIFECYCLE_ID" "stop_run missing next_git_experiment_params" "{\"status\":\"failed\",\"stage\":\"all_stop_markers_missing_params\",\"orchestration\":\"M10.96G8G\"}" || true
            fi
          fi
        fi


        # ============================================================
        # M10.96G8E pre-stop git_experiment_run handoff
        # ============================================================
        # Previous G8D ran after "interrupted current run", but some rigs
        # hang while stopping/waiting for coded-miner. Therefore the handoff
        # must happen before the stop wait path.
        if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
          NEXT_TYPE="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.next_command_type // empty" 2>/dev/null || true)"
          if [ "$NEXT_TYPE" = "git_experiment_run" ]; then
            NEXT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params.next_git_experiment_params // empty" 2>/dev/null || true)"
            STOP_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // .id // empty" 2>/dev/null || true)"
            STOP_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty" 2>/dev/null || true)"
            LIFECYCLE_STOP_ID="${STOP_DB_ID:-$STOP_COMMAND_ID}"

            echo "[M10.96G8E_PRESTOP_HANDOFF] stop_db_id=$STOP_DB_ID stop_command_id=$STOP_COMMAND_ID lifecycle_stop_id=$LIFECYCLE_STOP_ID next_type=$NEXT_TYPE params=$NEXT_PARAMS" | tee -a "$RUN_LOG"

            if [ -n "$NEXT_PARAMS" ] && [ "$NEXT_PARAMS" != "null" ]; then
              CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$NEXT_PARAMS}" || true)"

              echo "[M10.96G8E_PRESTOP_HANDOFF] create_git_experiment_resp=$CREATE_RESP" | tee -a "$RUN_LOG"

              coded_complete_command_id "$LIFECYCLE_STOP_ID" "{\"status\":\"completed\",\"stage\":\"prestop_git_experiment_enqueued\",\"orchestration\":\"M10.96G8E\"}" || true

              echo "[M10.96G8E_PRESTOP_HANDOFF] completed stop_run and enqueued git_experiment_run before miner stop wait" | tee -a "$RUN_LOG"
            else
              echo "[M10.96G8E_PRESTOP_HANDOFF] missing next_git_experiment_params" | tee -a "$RUN_LOG"
              coded_fail_command "$LIFECYCLE_STOP_ID" "stop_run prestop handoff missing next_git_experiment_params" "{\"status\":\"failed\",\"stage\":\"prestop_handoff_missing_params\",\"orchestration\":\"M10.96G8E\"}" || true
            fi
          fi
        fi
          kill "$MINER_PID" 2>/dev/null || true
          sleep 3
          kill -9 "$MINER_PID" 2>/dev/null || true
          break
        fi

        if [ "$SECONDS" -ge "$END" ]; then
          echo "[CODED_FLEET] run duration reached; stopping miner pid=$MINER_PID" | tee -a "$RUN_LOG"
          kill "$MINER_PID" 2>/dev/null || true
          break
        fi
      done

      wait "$MINER_PID" 2>/dev/null || true
      EC=$?

      if [ -n "$INTERRUPT_TYPE" ]; then
        
        # ============================================================
        # M10.96G8F true stop-branch git_experiment_run handoff
        # ============================================================
        # This is inserted between the two stable M10.90A stop markers.
        # The logs prove this exact code path is reached on Rig2.
        if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
          NEXT_TYPE="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.next_command_type // empty" 2>/dev/null || true)"
          if [ "$NEXT_TYPE" = "git_experiment_run" ]; then
            NEXT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params.next_git_experiment_params // empty" 2>/dev/null || true)"
            STOP_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // .id // empty" 2>/dev/null || true)"
            STOP_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty" 2>/dev/null || true)"
            STOP_LIFECYCLE_ID="${STOP_DB_ID:-$STOP_COMMAND_ID}"

            echo "[M10.96G8F_TRUE_STOP_BRANCH_HANDOFF] reached stop handoff stop_db_id=$STOP_DB_ID stop_command_id=$STOP_COMMAND_ID lifecycle=$STOP_LIFECYCLE_ID next_type=$NEXT_TYPE params=$NEXT_PARAMS" | tee -a "$RUN_LOG"

            if [ -n "$NEXT_PARAMS" ] && [ "$NEXT_PARAMS" != "null" ]; then
              CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$NEXT_PARAMS}" || true)"

              echo "[M10.96G8F_TRUE_STOP_BRANCH_HANDOFF] create_git_experiment_resp=$CREATE_RESP" | tee -a "$RUN_LOG"

              # Complete stop_run with DB UUID when available.
              coded_complete_command_id "$STOP_LIFECYCLE_ID" "{\"status\":\"completed\",\"stage\":\"true_stop_branch_git_experiment_enqueued\",\"orchestration\":\"M10.96G8F\"}" || true

              echo "[M10.96G8F_TRUE_STOP_BRANCH_HANDOFF] completed stop_run and enqueued git_experiment_run" | tee -a "$RUN_LOG"
            else
              echo "[M10.96G8F_TRUE_STOP_BRANCH_HANDOFF] missing next_git_experiment_params" | tee -a "$RUN_LOG"
              coded_fail_command "$STOP_LIFECYCLE_ID" "stop_run missing next_git_experiment_params" "{\"status\":\"failed\",\"stage\":\"true_stop_branch_missing_params\",\"orchestration\":\"M10.96G8F\"}" || true
            fi
          fi
        fi

echo "[M10.90A_INTERRUPT] interrupted current run type=$INTERRUPT_TYPE" | tee -a "$RUN_LOG"

        # ============================================================
        # M10.96G8D direct stop -> git_experiment_run handoff
        # ============================================================
        # This block must run immediately after a stop_run interrupt
        # was processed. It is intentionally placed next to the stable
        # M10.90A interrupt marker, because previous G8B placement was
        # not reached reliably.
        if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
          NEXT_TYPE="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.next_command_type // empty" 2>/dev/null || true)"
          if [ "$NEXT_TYPE" = "git_experiment_run" ]; then
            NEXT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params.next_git_experiment_params // empty" 2>/dev/null || true)"
            STOP_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // .id // empty" 2>/dev/null || true)"
            STOP_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty" 2>/dev/null || true)"
            LIFECYCLE_STOP_ID="${STOP_DB_ID:-$STOP_COMMAND_ID}"

            echo "[M10.96G8D_DIRECT_STOP_HANDOFF] stop_db_id=$STOP_DB_ID stop_command_id=$STOP_COMMAND_ID lifecycle_stop_id=$LIFECYCLE_STOP_ID next_type=$NEXT_TYPE params=$NEXT_PARAMS" | tee -a "$RUN_LOG"

            if [ -n "$NEXT_PARAMS" ] && [ "$NEXT_PARAMS" != "null" ]; then
              CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$NEXT_PARAMS}" || true)"

              echo "[M10.96G8D_DIRECT_STOP_HANDOFF] create_git_experiment_resp=$CREATE_RESP" | tee -a "$RUN_LOG"

              if command -v coded_complete_command_id >/dev/null 2>&1; then
                coded_complete_command_id "$LIFECYCLE_STOP_ID" "{\"status\":\"completed\",\"stage\":\"stop_completed_git_experiment_enqueued\",\"orchestration\":\"M10.96G8D\",\"create_response\":$CREATE_RESP}" || true
              else
                coded_complete_command "$LIFECYCLE_STOP_ID" "{\"status\":\"completed\",\"stage\":\"stop_completed_git_experiment_enqueued\",\"orchestration\":\"M10.96G8D\"}" || true
              fi

              echo "[M10.96G8D_DIRECT_STOP_HANDOFF] completed stop_run and enqueued git_experiment_run" | tee -a "$RUN_LOG"
            else
              echo "[M10.96G8D_DIRECT_STOP_HANDOFF] missing next_git_experiment_params" | tee -a "$RUN_LOG"
              coded_fail_command "$LIFECYCLE_STOP_ID" "stop_run handoff missing next_git_experiment_params" "{\"status\":\"failed\",\"stage\":\"stop_handoff_missing_params\",\"orchestration\":\"M10.96G8D\"}" || true
            fi
          fi
        fi

        # M10.96G8B:
        # stop_run can carry a git_experiment_run handoff payload.
        # This keeps git_experiment_run out of the active miner interrupt picker.
        # After the miner exits, enqueue the real git_experiment_run for the top-level handler.
        if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
          NEXT_TYPE="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.next_command_type // empty" 2>/dev/null || true)"
          if [ "$NEXT_TYPE" = "git_experiment_run" ]; then
            NEXT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params.next_git_experiment_params // empty" 2>/dev/null || true)"
            STOP_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // empty" 2>/dev/null || true)"
            STOP_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty" 2>/dev/null || true)"

            if [ -n "$NEXT_PARAMS" ] && [ "$NEXT_PARAMS" != "null" ]; then
              echo "[M10.96G8B_STOP_HANDOFF] enqueue git_experiment_run after stop stop_db_id=$STOP_DB_ID stop_command_id=$STOP_COMMAND_ID params=$NEXT_PARAMS" | tee -a "$RUN_LOG"

              curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$NEXT_PARAMS}" >/dev/null || true

              coded_complete_command "$STOP_COMMAND_ID" "{\"status\":\"completed\",\"stage\":\"stop_completed_git_experiment_enqueued\",\"orchestration\":\"M10.96G8B\"}" || true
              echo "[M10.96G8B_STOP_HANDOFF] completed stop_run and enqueued git_experiment_run" | tee -a "$RUN_LOG"
            else
              echo "[M10.96G8B_STOP_HANDOFF] missing next_git_experiment_params" | tee -a "$RUN_LOG"
            fi
          fi
        fi

        # M10.96G4:
        # git_experiment_run can be picked as an interrupt while a long default miner is running.
        # That picked command must not be swallowed inside coded_run_profile.
        # Requeue the same payload as a fresh pending command so the top-level handler can execute:
        # picked_up -> running -> heartbeat -> build -> rollback/resume/default.
        if [ "$INTERRUPT_TYPE" = "__disabled_git_experiment_run_interrupt__" ]; then
          INTERRUPT_PARAMS_SAFE="$(echo "$INTERRUPT_CMD" | jq -c ".command.params // .params // {}")"
          INTERRUPT_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // .id // empty")"
          INTERRUPT_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // .command_id // empty")"

          echo "[M10.96G4_INTERRUPT_REQUEUE] requeue git_experiment_run old_db_id=$INTERRUPT_DB_ID old_command_id=$INTERRUPT_COMMAND_ID params=$INTERRUPT_PARAMS_SAFE" | tee -a "$RUN_LOG"

          curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
            -H "Authorization: Bearer $TOKEN" \
            -H "Content-Type: application/json" \
            -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$INTERRUPT_PARAMS_SAFE}" >/dev/null || true

          if [ -n "$INTERRUPT_DB_ID" ]; then
            coded_fail_command "$INTERRUPT_DB_ID" "git_experiment_run interrupt requeued for top-level handler" "{\"status\":\"requeued\",\"reason\":\"interrupt_requeued_for_top_level_handler\",\"old_command_id\":\"$INTERRUPT_COMMAND_ID\"}" || true
          fi

          echo "[M10.96G4_INTERRUPT_REQUEUE] done; top-level loop will pick fresh git_experiment_run" | tee -a "$RUN_LOG"
        fi
        break
      fi

      echo "[CODED_FLEET] miner exited code=$EC; restarting in 10s" | tee -a "$RUN_LOG"
      sleep 10
    done

    kill "$UPLOADER_PID" 2>/dev/null || true

    coded_state_set_idle "run_finished_or_interrupted"

    curl -s -X POST "$API/runs/end" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"run_id\":\"$RUN_ID\",\"status\":\"completed\",\"end_reason\":\"fleet_command_completed\"}" >/dev/null || true

    if [ "$START_RUN_LAUNCH_COMPLETED" != "1" ]; then
      curl -s -X POST "$CODED_API_ROOT/commands/$CID/complete" \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"command_id\":\"$COMMAND_ID\",\"result\":{\"status\":\"completed\",\"run_id\":\"$RUN_ID\",\"interrupted_by\":\"${INTERRUPT_TYPE:-}\"}}" >/dev/null || true

      echo "[CODED_FLEET] command completed command=$COMMAND_ID run=$RUN_ID interrupted_by=${INTERRUPT_TYPE:-none}"
    else
      echo "[CODED_FLEET] launcher command already completed command=$COMMAND_ID run=$RUN_ID runtime_tracking=miner_run_dashboard interrupted_by=${INTERRUPT_TYPE:-none}"
    fi

    # Complete stop_run interrupts immediately. For build_* interrupts,
    # re-create a pending command of same type and params so the normal
    # top-level handler processes it in the next polling cycle. This avoids
    # fragile shell jumps and keeps release build logic single-sourced.
    if [ -n "$INTERRUPT_TYPE" ]; then
      INTERRUPT_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty")"

      if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
        coded_complete_command_id "$INTERRUPT_COMMAND_ID" "{\"status\":\"stopped\",\"interrupted_run_id\":\"$RUN_ID\"}"
      fi

      if [ "$INTERRUPT_TYPE" = "build_hive_release" ] || [ "$INTERRUPT_TYPE" = "build_release" ]; then
        INTERRUPT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params // {}")"

        # Mark picked interrupt complete as rescheduled, then create fresh pending
        # build_hive_release so top-level loop handles it immediately.
        coded_complete_command_id "$INTERRUPT_COMMAND_ID" "{\"status\":\"rescheduled_for_release_build\",\"interrupted_run_id\":\"$RUN_ID\"}"

        curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"$INTERRUPT_TYPE\",\"params\":$INTERRUPT_PARAMS}" >/dev/null || true

        echo "[M10.96G_INTERRUPT] rescheduled interrupt command type=$INTERRUPT_TYPE params=$INTERRUPT_PARAMS"
      fi
    fi
  done
else
  echo "[M10.91A_SUPERVISOR] no fleet command mode detected; entering always-on fallback supervisor"
  while true; do
    DEFAULT_PARAMS="$(coded_default_profile_json)"
    coded_run_profile "$DEFAULT_PARAMS" || true

    # If interrupted by a command, the top-level command loop should handle it on next iteration.
    # If the miner exits unexpectedly, resume fallback after a short cooldown.
    echo "[M10.91A_SUPERVISOR] fallback cycle ended; resuming after cooldown"
    sleep "${CODED_FALLBACK_RESUME_DELAY:-10}"
  done
fi
