#!/usr/bin/env bash
set -euo pipefail

echo "[CODED] start.sh starting..."

CONFIG_PATH="/hive/miners/custom/coded-miner/config.json"
MINER_BIN="/hive/miners/custom/coded-miner/coded-miner"

if [ ! -f "$CONFIG_PATH" ]; then
  echo "[CODED] ERROR: missing config.json at $CONFIG_PATH"
  exit 1
fi

if [ ! -x "$MINER_BIN" ]; then
  echo "[CODED] ERROR: miner binary not executable at $MINER_BIN"
  ls -la /hive/miners/custom/coded-miner || true
  exit 1
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "[CODED] jq not found, installing..."
  apt-get update
  apt-get install -y jq
fi

POOL="$(jq -r '.pool' "$CONFIG_PATH")"
WALLET="$(jq -r '.walletTemplate' "$CONFIG_PATH")"
WORKER="$(jq -r '.workerName' "$CONFIG_PATH")"
THREADS="$(jq -r '.threads' "$CONFIG_PATH")"
EXTRA_CONFIG="$(jq -r '.extraConfig // .pass // .user_config // ""' "$CONFIG_PATH")"

if [ -z "$POOL" ] || [ "$POOL" = "null" ]; then
  echo "[CODED] ERROR: invalid pool in config.json"
  exit 1
fi

if [ -z "$WALLET" ] || [ "$WALLET" = "null" ]; then
  echo "[CODED] ERROR: invalid walletTemplate in config.json"
  exit 1
fi

if [ -z "$WORKER" ] || [ "$WORKER" = "null" ]; then
  echo "[CODED] ERROR: invalid workerName in config.json"
  exit 1
fi

THREADS="$(jq -r '.amountOfThreads // .threads // 0' "$CONFIG_PATH")"
EXTRA_CONFIG="$(jq -r '.env // .extraConfig // .pass // .user_config // ""' "$CONFIG_PATH")"

if [ -z "$THREADS" ] || [ "$THREADS" = "null" ]; then
  THREADS="0"
fi

if ! printf '%s' "$THREADS" | grep -Eq '^[0-9]+$'; then
  THREADS="0"
fi

echo "[CODED] POOL=$POOL"
echo "[CODED] WALLET=$WALLET"
echo "[CODED] WORKER=$WORKER"
echo "[CODED] THREADS=$THREADS"

if [ -n "$EXTRA_CONFIG" ] && [ "$EXTRA_CONFIG" != "null" ]; then
  echo "[CODED] applying HiveOS extra config"
  while IFS= read -r line; do
    line="$(echo "$line" | sed 's/^ *//;s/ *$//')"
    [ -z "$line" ] && continue
    echo "$line" | grep -q '^#' && continue

    case "$line" in
      CODED_*=*)
        export "$line"
        ;;
      *)
        echo "[CODED] ignoring unsupported extra config line: $line"
        ;;
    esac
  done <<EOF
$EXTRA_CONFIG
EOF
fi

export CODED_HYPER_HIT_MODE="${CODED_HYPER_HIT_MODE:-crypto}"
export CODED_LOG_MODE="${CODED_LOG_MODE:-public}"
export CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx2}"
export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-23}"
export CODED_SCORE_SAMPLE_BATCH_RATE="${CODED_SCORE_SAMPLE_BATCH_RATE:-0}"

echo "[CODED] BACKEND=$CODED_KERNEL_BACKEND"
echo "[CODED] ACTIVATION=$CODED_KERNEL_ACTIVATION"
echo "[CODED] PREFILTER=$CODED_PREFILTER_DIFFICULTY"
echo "[CODED] SCORE_SAMPLE_BATCH_RATE=$CODED_SCORE_SAMPLE_BATCH_RATE"

echo "[CODED] BACKEND=$CODED_KERNEL_BACKEND"
echo "[CODED] ACTIVATION=$CODED_KERNEL_ACTIVATION"
echo "[CODED] PREFILTER=$CODED_PREFILTER_DIFFICULTY"
echo "[CODED] SCORE_SAMPLE_BATCH_RATE=$CODED_SCORE_SAMPLE_BATCH_RATE"

LOG_DIR="/var/log/miner/coded-miner"
LOG_FILE="$LOG_DIR/coded-miner.log"

mkdir -p "$LOG_DIR"
touch "$LOG_FILE"

"$MINER_BIN" \
  --pool "$POOL" \
  --wallet "$WALLET" \
  --worker "$WORKER" \
  --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE"