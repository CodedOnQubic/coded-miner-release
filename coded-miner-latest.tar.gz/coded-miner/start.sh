#!/usr/bin/env bash
set -euo pipefail

echo "[CODED] start.sh starting..."

CONFIG_PATH="/hive/miners/custom/coded-miner/config.json"
MINER_BIN="/hive/miners/custom/coded-miner/coded-miner"

if [ ! -f "$CONFIG_PATH" ]; then
  echo "[CODED] ERROR: missing config.json at $CONFIG_PATH"
  exit 1
fi

if [ ! -x "$MINER_BIN" ]; then
  echo "[CODED] ERROR: miner binary not executable at $MINER_BIN"
  ls -la /hive/miners/custom/coded-miner || true
  exit 1
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "[CODED] jq not found, installing..."
  apt-get update
  apt-get install -y jq
fi

POOL="$(jq -r '.pool' "$CONFIG_PATH")"
WALLET="$(jq -r '.walletTemplate' "$CONFIG_PATH")"
WORKER="$(jq -r '.workerName' "$CONFIG_PATH")"
THREADS="$(jq -r '.threads' "$CONFIG_PATH")"
EXTRA_CONFIG="$(jq -r '.extraConfig // .pass // .user_config // ""' "$CONFIG_PATH")"

if [ -z "$POOL" ] || [ "$POOL" = "null" ]; then
  echo "[CODED] ERROR: invalid pool in config.json"
  exit 1
fi

if [ -z "$WALLET" ] || [ "$WALLET" = "null" ]; then
  echo "[CODED] ERROR: invalid walletTemplate in config.json"
  exit 1
fi

if [ -z "$WORKER" ] || [ "$WORKER" = "null" ]; then
  echo "[CODED] ERROR: invalid workerName in config.json"
  exit 1
fi

THREADS="$(jq -r '.amountOfThreads // .threads // 0' "$CONFIG_PATH")"
if [ "$THREADS" = "1" ] || [ "$THREADS" = "0" ]; then
  TOTAL_THREADS="$(nproc 2>/dev/null || echo 2)"
  if [ "$TOTAL_THREADS" -gt 1 ]; then
    THREADS="$((TOTAL_THREADS - 1))"
  else
    THREADS="1"
  fi
fi
EXTRA_CONFIG="$(jq -r '.env // .extraConfig // .pass // .user_config // ""' "$CONFIG_PATH")"

if [ -z "$THREADS" ] || [ "$THREADS" = "null" ]; then
  THREADS="0"
fi

if ! printf '%s' "$THREADS" | grep -Eq '^[0-9]+$'; then
  THREADS="0"
fi

echo "[CODED] POOL=$POOL"
echo "[CODED] WALLET=$WALLET"
echo "[CODED] WORKER=$WORKER"
echo "[CODED] THREADS=$THREADS"

if [ -n "$EXTRA_CONFIG" ] && [ "$EXTRA_CONFIG" != "null" ]; then
  echo "[CODED] applying HiveOS extra config"
  while IFS= read -r line; do
    line="$(echo "$line" | sed 's/^ *//;s/ *$//')"
    [ -z "$line" ] && continue
    echo "$line" | grep -q '^#' && continue

    case "$line" in
      CODED_*=*)
        export "$line"
        ;;
      *)
        echo "[CODED] ignoring unsupported extra config line: $line"
        ;;
    esac
  done <<EOF
$EXTRA_CONFIG
EOF
fi

export CODED_HYPER_HIT_MODE="${CODED_HYPER_HIT_MODE:-crypto}"
export CODED_LOG_MODE="${CODED_LOG_MODE:-public}"

# M10.25a production preset: validated Shadow500 path.
# Can be overridden from HiveOS extra config.
export CODED_RANDOM2_HUGEPAGE="${CODED_RANDOM2_HUGEPAGE:-1}"
export CODED_BATCH_SIZE="${CODED_BATCH_SIZE:-64}"
export CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx512}"
export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
export CODED_SCORE_SAMPLE_BATCH_RATE="${CODED_SCORE_SAMPLE_BATCH_RATE:-0}"
export CODED_SCORE_DEBUG="${CODED_SCORE_DEBUG:-0}"
export CODED_FAST_SHADOW_GATE="${CODED_FAST_SHADOW_GATE:-1}"
export CODED_FAST_SHADOW_THRESHOLD="${CODED_FAST_SHADOW_THRESHOLD:-507}"
export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-0}"
export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"

echo "[CODED] BACKEND=$CODED_KERNEL_BACKEND"
echo "[CODED] ACTIVATION=$CODED_KERNEL_ACTIVATION"
echo "[CODED] RANDOM2_HUGEPAGE=$CODED_RANDOM2_HUGEPAGE"
echo "[CODED] BATCH_SIZE=$CODED_BATCH_SIZE"
echo "[CODED] PREFILTER=$CODED_PREFILTER_DIFFICULTY"
echo "[CODED] SCORE_ALGO_MODE=$CODED_SCORE_ALGO_MODE"
echo "[CODED] SCORE_SAMPLE_BATCH_RATE=$CODED_SCORE_SAMPLE_BATCH_RATE"
echo "[CODED] FAST_SHADOW_GATE=$CODED_FAST_SHADOW_GATE"
echo "[CODED] FAST_SHADOW_THRESHOLD=$CODED_FAST_SHADOW_THRESHOLD"
echo "[CODED] FAST_SHADOW_AUDIT_RATE=$CODED_FAST_SHADOW_AUDIT_RATE"
echo "[CODED] FAST_SHADOW_SUMMARY_SEC=$CODED_FAST_SHADOW_SUMMARY_SEC"



# ============================================================
# M10.84A Fleet Analytics Runtime
# ============================================================

ANALYTICS_ENABLED="${CODED_ANALYTICS:-0}"

if [ "$ANALYTICS_ENABLED" = "1" ]; then

  echo "[CODED_ANALYTICS] enabled"

  ANALYTICS_API="${CODED_ANALYTICS_API:-https://api.codedonqubic.com/analytics}"
  ANALYTICS_TOKEN="${CODED_ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}"

  RIG_ID="${CODED_RIG_ID:-$(hostname)}"

  RUN_ID="M1084_${RIG_ID}_$(date +%Y%m%d_%H%M%S)"

  CPU_MODEL="$(lscpu | grep "Model name" | sed "s/.*: *//" | head -1)"
  CPU_THREADS="$(nproc)"
  RAM_MB="$(free -m | awk "/Mem:/ {print $2}")"

  AVX2_SUPPORTED=false
  AVX512_SUPPORTED=false

  grep -m1 flags /proc/cpuinfo | grep -qw avx2 && AVX2_SUPPORTED=true
  grep -m1 flags /proc/cpuinfo | grep -qw avx512f && AVX512_SUPPORTED=true

  HUGEPAGES_TOTAL="$(grep HugePages_Total /proc/meminfo | awk "{print \$2}")"
  HUGEPAGES_FREE="$(grep HugePages_Free /proc/meminfo | awk "{print \$2}")"

  export RUN_ID

  curl -s -X POST "${ANALYTICS_API}/runs/start" \
    -H "Authorization: Bearer ${ANALYTICS_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{
      \"run_id\":\"${RUN_ID}\",
      \"rig_id\":\"${RIG_ID}\",
      \"worker_name\":\"${WORKER}\",
      \"miner_version\":\"m10.84a\",
      \"backend\":\"${CODED_KERNEL_BACKEND}\",
      \"threshold\":${CODED_FAST_SHADOW_THRESHOLD},
      \"threads\":${THREADS},
      \"batch_size\":${CODED_BATCH_SIZE},
      \"audit_rate\":${CODED_FAST_SHADOW_AUDIT_RATE},
      \"gate_mode\":\"single\",
      \"hostname\":\"$(hostname)\",
      \"cpu_model\":\"${CPU_MODEL}\",
      \"cpu_threads\":${CPU_THREADS},
      \"ram_mb\":${RAM_MB},
      \"avx2_supported\":${AVX2_SUPPORTED},
      \"avx512_supported\":${AVX512_SUPPORTED},
      \"hugepages_total\":${HUGEPAGES_TOTAL:-0},
      \"hugepages_free\":${HUGEPAGES_FREE:-0},
      \"hardware\":{
        \"cpu_model\":\"${CPU_MODEL}\",
        \"cpu_threads\":${CPU_THREADS},
        \"ram_mb\":${RAM_MB},
        \"avx2\":${AVX2_SUPPORTED},
        \"avx512\":${AVX512_SUPPORTED}
      }
    }" >/dev/null || true

  echo "[CODED_ANALYTICS] RUN_ID=${RUN_ID}"

  # M10.86 Statistical Fleet Analysis bridge
  # Flightsheet stays simple: CODED_ANALYTICS=YES
  # This enables score-distribution upload without adding extra HiveOS fields.
  ANALYTICS_BASE="${API%/analytics}"

  export CODED_SCORE_DIST_UPLOAD=1
  export CODED_ANALYTICS_URL="${CODED_ANALYTICS_URL:-${ANALYTICS_BASE}}"
  export CODED_ANALYTICS_INGEST_TOKEN="${CODED_ANALYTICS_INGEST_TOKEN:-${TOKEN}}"
  export CODED_RUN_ID="${CODED_RUN_ID:-${RUN_ID}}"
  export CODED_RIG_ID="${CODED_RIG_ID:-${RIG_ID:-$(hostname)}}"
  export CODED_WORKER_NAME="${CODED_WORKER_NAME:-${WORKER_NAME:-$(hostname)}}"

  echo "[CODED_ANALYTICS] M10.86 score distribution upload enabled"
  echo "[CODED_ANALYTICS] SCORE_DIST_URL=${CODED_ANALYTICS_URL}/analytics/score-distribution"

fi


LOG_DIR="/var/log/miner/coded-miner"
LOG_FILE="$LOG_DIR/coded-miner.log"

mkdir -p "$LOG_DIR"
touch "$LOG_FILE"

if [ "${CODED_ANALYTICS:-}" = "YES" ] || [ "${CODED_ANALYTICS:-}" = "1" ]; then
  echo "[CODED_FLEET] agent mode enabled"

  API="${CODED_ANALYTICS_API:-https://api.codedonqubic.com/analytics}"
  TOKEN="${CODED_ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}"
  RIG_ID="${CODED_RIG_ID:-$(hostname)}"

  CPU_MODEL="$(lscpu | grep "Model name" | sed "s/.*: *//" | head -1)"
  CPU_THREADS="$(nproc)"
  RAM_MB="$(free -m | awk '/Mem:/ {print $2}')"
  AVX2=false
  AVX512=false
  grep -m1 flags /proc/cpuinfo | grep -qw avx2 && AVX2=true
  grep -m1 flags /proc/cpuinfo | grep -qw avx512f && AVX512=true
  HPT="$(grep HugePages_Total /proc/meminfo | awk "{print \$2}")"
  HPF="$(grep HugePages_Free /proc/meminfo | awk "{print \$2}")"

  curl -s -X POST "$API/rigs/register" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"rig_id\":\"$RIG_ID\",\"rig_name\":\"$RIG_ID\",\"hostname\":\"$(hostname)\",\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2_supported\":$AVX2,\"avx512_supported\":$AVX512,\"hugepages_total\":${HPT:-0},\"hugepages_free\":${HPF:-0},\"threads\":$THREADS}" || true

  echo "[CODED_FLEET] registered RIG_ID=$RIG_ID"
  echo "[CODED_FLEET] waiting for backend commands"

  while true; do
    CMD="$(curl -s "$API/commands/next/$RIG_ID" -H "Authorization: Bearer $TOKEN" || true)"
    COMMAND_ID="$(echo "$CMD" | jq -r ".command.command_id // empty")"

    if [ -z "$COMMAND_ID" ]; then
      sleep 30
      continue
    fi

    COMMAND_TYPE="$(echo "$CMD" | jq -r ".command.command_type // empty")"

    if [ "$COMMAND_TYPE" = "build_hive_release" ]; then
      VERSION="$(echo "$CMD" | jq -r ".command.params.version // empty")"
      [ -z "$VERSION" ] && VERSION="v0.0.0-dev"

      BUILD_LOG="/tmp/coded_hive_release_${VERSION}.log"
      echo "[CODED_RELEASE] building Hive release VERSION=$VERSION" | tee "$BUILD_LOG"

      (
        set -e
        cd /hive/codedonqubic
        git fetch origin main
        git reset --hard origin/main
        chmod +x ./scripts/release_hiveos.sh
        export GH_CONFIG_DIR="/root/.config/gh"
        export HOME="/root"

        ./scripts/release.sh "$VERSION" linux/amd64

        ASSETS="$(find /hive/coded-miner-release -maxdepth 1 -type f \( -name "coded-miner-latest.tar.gz" -o -name "coded-miner-docker-linux-amd64.tar.gz" \) | sort -u | tr "\n" " ")"
        if [ -z "$ASSETS" ]; then
          echo "[CODED_RELEASE] no release assets found in /hive/coded-miner-release"
          find /hive/coded-miner-release -maxdepth 2 -type f
          exit 2
        fi

        echo "[CODED_RELEASE] assets: $ASSETS"

        if gh release view "$VERSION" --repo CodedOnQubic/coded-miner-release >/dev/null 2>&1; then
          gh release upload "$VERSION" $ASSETS --repo CodedOnQubic/coded-miner-release --clobber
          gh release edit "$VERSION" --repo CodedOnQubic/coded-miner-release --draft=false
        else
          gh release create "$VERSION" $ASSETS \
            --repo CodedOnQubic/coded-miner-release \
            --title "$VERSION" \
            --notes "HiveOS fleet analytics release $VERSION" \
            --target main
        fi
      ) >> "$BUILD_LOG" 2>&1

      EC=$?
      if [ "$EC" = "0" ]; then
        curl -s -X POST "$API/commands/complete" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"command_id\":\"$COMMAND_ID\",\"result\":{\"status\":\"success\",\"release\":\"$VERSION\",\"log\":\"$BUILD_LOG\",\"repo\":\"CodedOnQubic/coded-miner-release\"}}" >/dev/null || true
        echo "[CODED_RELEASE] completed VERSION=$VERSION"
      else
        curl -s -X POST "$API/commands/fail" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"command_id\":\"$COMMAND_ID\",\"error\":\"release build failed\",\"result\":{\"version\":\"$VERSION\",\"log\":\"$BUILD_LOG\",\"exit_code\":$EC}}" >/dev/null || true
        echo "[CODED_RELEASE] failed VERSION=$VERSION exit=$EC"
      fi

      continue
    fi

    THRESHOLD="$(echo "$CMD" | jq -r ".command.params.threshold // 510")"
    HOURS="$(echo "$CMD" | jq -r ".command.params.hours // 8")"
JOB_THREADS="$(echo "$CMD" | jq -r ".command.params.threads // empty")"
if [ -n "$JOB_THREADS" ] && echo "$JOB_THREADS" | grep -Eq "^[0-9]+$"; then
  THREADS="$JOB_THREADS"
fi
    BATCH="$(echo "$CMD" | jq -r ".command.params.batch_size // 4000")"
    AUDIT="$(echo "$CMD" | jq -r ".command.params.audit_rate // 500")"
    RUN_WORKER="$(echo "$CMD" | jq -r ".command.params.worker_name // empty")"
    [ -z "$RUN_WORKER" ] && RUN_WORKER="${WORKER}_T${THRESHOLD}"

    RUN_ID="M1084_${RIG_ID}_T${THRESHOLD}_$(date +%Y%m%d_%H%M%S)"
    RUN_LOG="$LOG_DIR/${RUN_ID}.log"
    END=$((SECONDS + HOURS * 3600))

    export CODED_FAST_SHADOW_THRESHOLD="$THRESHOLD"
    export CODED_FAST_SHADOW_AUDIT_RATE="$AUDIT"
    export CODED_BATCH_SIZE="$BATCH"
    export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"
    export CODED_RANDOM2_HUGEPAGE="${CODED_RANDOM2_HUGEPAGE:-1}"
    export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
    export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
    export CODED_SCORE_SAMPLE_BATCH_RATE="${CODED_SCORE_SAMPLE_BATCH_RATE:-0}"
    export CODED_SHADOW_AVX512_LIVE="${CODED_SHADOW_AVX512_LIVE:-1}"
    export CODED_LOG_MODE="${CODED_LOG_MODE:-dev}"

    curl -s -X POST "$API/runs/start" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"miner_version\":\"m10.84b-fleet-agent\",\"backend\":\"$CODED_KERNEL_BACKEND\",\"threshold\":$THRESHOLD,\"threads\":$THREADS,\"batch_size\":$BATCH,\"audit_rate\":$AUDIT,\"gate_mode\":\"single\",\"hostname\":\"$(hostname)\",\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2_supported\":$AVX2,\"avx512_supported\":$AVX512,\"hugepages_total\":${HPT:-0},\"hugepages_free\":${HPF:-0},\"hardware\":{\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2\":$AVX2,\"avx512\":$AVX512}}" >/dev/null || true

    echo "[CODED_FLEET] starting command=$COMMAND_ID run=$RUN_ID threshold=$THRESHOLD hours=$HOURS"

    (
      set +e

      while true; do

        [ ! -f "$RUN_LOG" ] && sleep 5 && continue
        sleep 60

        # Uploader is intentionally independent from miner PID.
        # The miner may restart inside the command window.
        SUMMARY="$(grep "FAST_SHADOW_SUMMARY" "$RUN_LOG" | tail -n 1 || true)"
        SOLS="$(grep "SOLS:" "$RUN_LOG" | tail -n 1 || true)"
        HI="$(grep "HI_TIMING_SUMMARY" "$RUN_LOG" | tail -n 1 || true)"
        [ -z "$SUMMARY" ] && continue

        extract(){ echo "$SUMMARY" | grep -oP "$1=\K[0-9.]+" | tail -n 1 || true; }

        TOTAL_SEEN="$(extract total_seen)"
        TOTAL_PASS="$(extract total_pass)"
        TOTAL_SKIP="$(extract total_skip)"
        TOTAL_AUDITED="$(extract total_audited)"
        FALSE_NEG="$(extract false_negative)"
        MAX_PASS="$(extract max_real_score_passed)"
        MAX_SKIP="$(extract max_real_score_audited_skip)"
        PASSRATE="$(extract pass_rate)"
        SKIPRATE="$(extract skip_rate)"
        AUDITRATE_OBS="$(extract audit_rate)"
        S280="$(extract pass_280_289)"
        S290="$(extract pass_290_299)"
        S300="$(extract pass_300_309)"
        S310="$(extract pass_310_320)"
        S321="$(extract pass_321_plus)"

        AVG_ITS="$(echo "$SOLS" | grep -oP "\| [0-9]+ avg it/s" | grep -oP "[0-9]+" | tail -n 1 || true)"
        LAST_ITS="$(echo "$SOLS" | grep -oP "\] [0-9]+ it/s" | grep -oP "[0-9]+" | tail -n 1 || true)"
        ALGO0_AVG="$(echo "$HI" | grep -oP "algo0_avg_ms=\K[0-9.]+" | tail -n 1 || true)"

        curl -s -X POST "$API/runs/heartbeat" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"status\":\"running\",\"avg_its\":${AVG_ITS:-0},\"last_its\":${LAST_ITS:-0},\"active_backend\":\"$CODED_KERNEL_BACKEND\"}" >/dev/null || true

        curl -s -X POST "$API/runs/summary" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"run_id\":\"$RUN_ID\",\"total_seen\":${TOTAL_SEEN:-0},\"total_pass\":${TOTAL_PASS:-0},\"total_skip\":${TOTAL_SKIP:-0},\"total_audited\":${TOTAL_AUDITED:-0},\"false_negative\":${FALSE_NEG:-0},\"max_real_score_passed\":${MAX_PASS:-0},\"max_real_score_audited_skip\":${MAX_SKIP:-0},\"pass_rate\":${PASSRATE:-0},\"skip_rate\":${SKIPRATE:-0},\"audit_rate\":${AUDITRATE_OBS:-0},\"avg_its\":${AVG_ITS:-0},\"last_its\":${LAST_ITS:-0},\"algo0_avg_ms\":${ALGO0_AVG:-0}}" >/dev/null || true

        # M10.86 Statistical Fleet Analysis Engine
        # Same analytics pipeline as runs/summary: miner stdout -> wrapper parser -> pool-api -> Supabase.
        MAX_SCORE="$MAX_PASS"
        if [ "${MAX_SKIP:-0}" -gt "${MAX_SCORE:-0}" ] 2>/dev/null; then
          MAX_SCORE="$MAX_SKIP"
        fi

        curl -s -X POST "$API/score-distribution" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"epoch\":${EPOCH:-0},\"backend\":\"$CODED_KERNEL_BACKEND\",\"cpu_model\":\"$CPU_MODEL\",\"threshold\":${THRESHOLD:-0},\"threads\":${THREADS:-0},\"batch_size\":${BATCH:-0},\"audit_rate\":${AUDIT:-0},\"total_seen\":${TOTAL_SEEN:-0},\"total_pass\":${TOTAL_PASS:-0},\"total_skip\":${TOTAL_SKIP:-0},\"total_audited\":${TOTAL_AUDITED:-0},\"false_negative\":${FALSE_NEG:-0},\"max_score\":${MAX_SCORE:-0},\"max_pass_score\":${MAX_PASS:-0},\"max_audited_skip_score\":${MAX_SKIP:-0},\"score_260_269\":0,\"score_270_279\":0,\"score_280_289\":${S280:-0},\"score_290_299\":${S290:-0},\"score_300_309\":${S300:-0},\"score_310_320\":${S310:-0},\"score_321_plus\":${S321:-0},\"raw\":{\"source\":\"fleet_uploader\",\"summary\":\"$SUMMARY\"}}" >/dev/null || true
      done
    ) >/tmp/coded_fleet_uploader_${RUN_ID}.log 2>&1 &
    UPLOADER_PID=$!

    echo "[CODED_FLEET] uploader pid=$UPLOADER_PID log=/tmp/coded_fleet_uploader_${RUN_ID}.log"

    while [ "$SECONDS" -lt "$END" ]; do
      "$MINER_BIN" --pool "$POOL" --wallet "$WALLET" --worker "$RUN_WORKER" --threads "$THREADS" 2>&1 | tee -a "$RUN_LOG"
      EC=${PIPESTATUS[0]}
      echo "[CODED_FLEET] miner exited code=$EC; restarting in 10s" | tee -a "$RUN_LOG"
      sleep 10
    done

    kill "$UPLOADER_PID" 2>/dev/null || true

    curl -s -X POST "$API/runs/end" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"run_id\":\"$RUN_ID\",\"status\":\"completed\",\"end_reason\":\"fleet_command_completed\"}" >/dev/null || true

    curl -s -X POST "$API/commands/complete" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"command_id\":\"$COMMAND_ID\",\"result\":{\"run_id\":\"$RUN_ID\"}}" >/dev/null || true

    echo "[CODED_FLEET] command completed command=$COMMAND_ID run=$RUN_ID"
  done
else
  "$MINER_BIN" \
    --pool "$POOL" \
    --wallet "$WALLET" \
    --worker "$WORKER" \
    --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE"
fi
