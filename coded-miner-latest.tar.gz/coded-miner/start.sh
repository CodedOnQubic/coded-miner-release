#!/usr/bin/env bash
set -euo pipefail

echo "[CODED] start.sh starting..."

CONFIG_PATH="/hive/miners/custom/coded-miner/config.json"
MINER_BIN="/hive/miners/custom/coded-miner/coded-miner"

if [ ! -f "$CONFIG_PATH" ]; then
  echo "[CODED] ERROR: missing config.json at $CONFIG_PATH"
  exit 1
fi

if [ ! -x "$MINER_BIN" ]; then
  echo "[CODED] ERROR: miner binary not executable at $MINER_BIN"
  ls -la /hive/miners/custom/coded-miner || true
  exit 1
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "[CODED] jq not found, installing..."
  apt-get update
  apt-get install -y jq
fi

POOL="$(jq -r '.pool' "$CONFIG_PATH")"
WALLET="$(jq -r '.walletTemplate' "$CONFIG_PATH")"
WORKER="$(jq -r '.workerName' "$CONFIG_PATH")"
THREADS="$(jq -r '.threads' "$CONFIG_PATH")"
EXTRA_CONFIG="$(jq -r '.extraConfig // .pass // .user_config // ""' "$CONFIG_PATH")"

if [ -z "$POOL" ] || [ "$POOL" = "null" ]; then
  echo "[CODED] ERROR: invalid pool in config.json"
  exit 1
fi

if [ -z "$WALLET" ] || [ "$WALLET" = "null" ]; then
  echo "[CODED] ERROR: invalid walletTemplate in config.json"
  exit 1
fi

if [ -z "$WORKER" ] || [ "$WORKER" = "null" ]; then
  echo "[CODED] ERROR: invalid workerName in config.json"
  exit 1
fi

THREADS="$(jq -r '.amountOfThreads // .threads // 0' "$CONFIG_PATH")"
EXTRA_CONFIG="$(jq -r '.env // .extraConfig // .pass // .user_config // ""' "$CONFIG_PATH")"

if [ -z "$THREADS" ] || [ "$THREADS" = "null" ]; then
  THREADS="0"
fi

if ! printf '%s' "$THREADS" | grep -Eq '^[0-9]+$'; then
  THREADS="0"
fi

echo "[CODED] POOL=$POOL"
echo "[CODED] WALLET=$WALLET"
echo "[CODED] WORKER=$WORKER"
echo "[CODED] THREADS=$THREADS"

if [ -n "$EXTRA_CONFIG" ] && [ "$EXTRA_CONFIG" != "null" ]; then
  echo "[CODED] applying HiveOS extra config"
  while IFS= read -r line; do
    line="$(echo "$line" | sed 's/^ *//;s/ *$//')"
    [ -z "$line" ] && continue
    echo "$line" | grep -q '^#' && continue

    case "$line" in
      CODED_*=*)
        export "$line"
        ;;
      *)
        echo "[CODED] ignoring unsupported extra config line: $line"
        ;;
    esac
  done <<EOF
$EXTRA_CONFIG
EOF
fi

export CODED_HYPER_HIT_MODE="${CODED_HYPER_HIT_MODE:-crypto}"
export CODED_LOG_MODE="${CODED_LOG_MODE:-public}"

# M10.25a production preset: validated Shadow500 path.
# Can be overridden from HiveOS extra config.
export CODED_RANDOM2_HUGEPAGE="${CODED_RANDOM2_HUGEPAGE:-1}"
export CODED_BATCH_SIZE="${CODED_BATCH_SIZE:-64}"
export CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx512}"
export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
export CODED_SCORE_SAMPLE_BATCH_RATE="${CODED_SCORE_SAMPLE_BATCH_RATE:-0}"
export CODED_SCORE_DEBUG="${CODED_SCORE_DEBUG:-0}"
export CODED_FAST_SHADOW_GATE="${CODED_FAST_SHADOW_GATE:-1}"
export CODED_FAST_SHADOW_THRESHOLD="${CODED_FAST_SHADOW_THRESHOLD:-507}"
export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-0}"
export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"

echo "[CODED] BACKEND=$CODED_KERNEL_BACKEND"
echo "[CODED] ACTIVATION=$CODED_KERNEL_ACTIVATION"
echo "[CODED] RANDOM2_HUGEPAGE=$CODED_RANDOM2_HUGEPAGE"
echo "[CODED] BATCH_SIZE=$CODED_BATCH_SIZE"
echo "[CODED] PREFILTER=$CODED_PREFILTER_DIFFICULTY"
echo "[CODED] SCORE_ALGO_MODE=$CODED_SCORE_ALGO_MODE"
echo "[CODED] SCORE_SAMPLE_BATCH_RATE=$CODED_SCORE_SAMPLE_BATCH_RATE"
echo "[CODED] FAST_SHADOW_GATE=$CODED_FAST_SHADOW_GATE"
echo "[CODED] FAST_SHADOW_THRESHOLD=$CODED_FAST_SHADOW_THRESHOLD"
echo "[CODED] FAST_SHADOW_AUDIT_RATE=$CODED_FAST_SHADOW_AUDIT_RATE"
echo "[CODED] FAST_SHADOW_SUMMARY_SEC=$CODED_FAST_SHADOW_SUMMARY_SEC"



# ============================================================
# M10.84A Fleet Analytics Runtime
# ============================================================

ANALYTICS_ENABLED="${CODED_ANALYTICS:-0}"

if [ "$ANALYTICS_ENABLED" = "1" ]; then

  echo "[CODED_ANALYTICS] enabled"

  ANALYTICS_API="${CODED_ANALYTICS_API:-https://api.codedonqubic.com/analytics}"
  ANALYTICS_TOKEN="${CODED_ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}"

  RIG_ID="${CODED_RIG_ID:-$(hostname)}"

  RUN_ID="M1084_${RIG_ID}_$(date +%Y%m%d_%H%M%S)"

  CPU_MODEL="$(lscpu | grep "Model name" | sed "s/.*: *//" | head -1)"
  CPU_THREADS="$(nproc)"
  RAM_MB="$(free -m | awk "/Mem:/ {print $2}")"

  AVX2_SUPPORTED=false
  AVX512_SUPPORTED=false

  grep -m1 flags /proc/cpuinfo | grep -qw avx2 && AVX2_SUPPORTED=true
  grep -m1 flags /proc/cpuinfo | grep -qw avx512f && AVX512_SUPPORTED=true

  HUGEPAGES_TOTAL="$(grep HugePages_Total /proc/meminfo | awk "{print \$2}")"
  HUGEPAGES_FREE="$(grep HugePages_Free /proc/meminfo | awk "{print \$2}")"

  export RUN_ID

  curl -s -X POST "${ANALYTICS_API}/runs/start" \
    -H "Authorization: Bearer ${ANALYTICS_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{
      \"run_id\":\"${RUN_ID}\",
      \"rig_id\":\"${RIG_ID}\",
      \"worker_name\":\"${WORKER}\",
      \"miner_version\":\"m10.84a\",
      \"backend\":\"${CODED_KERNEL_BACKEND}\",
      \"threshold\":${CODED_FAST_SHADOW_THRESHOLD},
      \"threads\":${THREADS},
      \"batch_size\":${CODED_BATCH_SIZE},
      \"audit_rate\":${CODED_FAST_SHADOW_AUDIT_RATE},
      \"gate_mode\":\"single\",
      \"hostname\":\"$(hostname)\",
      \"cpu_model\":\"${CPU_MODEL}\",
      \"cpu_threads\":${CPU_THREADS},
      \"ram_mb\":${RAM_MB},
      \"avx2_supported\":${AVX2_SUPPORTED},
      \"avx512_supported\":${AVX512_SUPPORTED},
      \"hugepages_total\":${HUGEPAGES_TOTAL:-0},
      \"hugepages_free\":${HUGEPAGES_FREE:-0},
      \"hardware\":{
        \"cpu_model\":\"${CPU_MODEL}\",
        \"cpu_threads\":${CPU_THREADS},
        \"ram_mb\":${RAM_MB},
        \"avx2\":${AVX2_SUPPORTED},
        \"avx512\":${AVX512_SUPPORTED}
      }
    }" >/dev/null || true

  echo "[CODED_ANALYTICS] RUN_ID=${RUN_ID}"

fi


LOG_DIR="/var/log/miner/coded-miner"
LOG_FILE="$LOG_DIR/coded-miner.log"

mkdir -p "$LOG_DIR"
touch "$LOG_FILE"

if [ "${CODED_ANALYTICS:-}" = "YES" ] || [ "${CODED_ANALYTICS:-}" = "1" ]; then
  echo "[CODED_FLEET] agent mode enabled"

  API="${CODED_ANALYTICS_API:-https://api.codedonqubic.com/analytics}"
  TOKEN="${CODED_ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}"
  RIG_ID="${CODED_RIG_ID:-$(hostname)}"

  CPU_MODEL="$(lscpu | grep "Model name" | sed "s/.*: *//" | head -1)"
  CPU_THREADS="$(nproc)"
  RAM_MB="$(free -m | awk '/Mem:/ {print $2}')"
  AVX2=false
  AVX512=false
  grep -m1 flags /proc/cpuinfo | grep -qw avx2 && AVX2=true
  grep -m1 flags /proc/cpuinfo | grep -qw avx512f && AVX512=true
  HPT="$(grep HugePages_Total /proc/meminfo | awk "{print \$2}")"
  HPF="$(grep HugePages_Free /proc/meminfo | awk "{print \$2}")"

  curl -s -X POST "$API/rigs/register" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"rig_id\":\"$RIG_ID\",\"rig_name\":\"$RIG_ID\",\"hostname\":\"$(hostname)\",\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2_supported\":$AVX2,\"avx512_supported\":$AVX512,\"hugepages_total\":${HPT:-0},\"hugepages_free\":${HPF:-0},\"threads\":$THREADS}" || true

  echo "[CODED_FLEET] registered RIG_ID=$RIG_ID"
  echo "[CODED_FLEET] waiting for backend commands"

  while true; do
    CMD="$(curl -s "$API/commands/next/$RIG_ID" -H "Authorization: Bearer $TOKEN" || true)"
    COMMAND_ID="$(echo "$CMD" | jq -r ".command.command_id // empty")"

    if [ -z "$COMMAND_ID" ]; then
      sleep 30
      continue
    fi

    THRESHOLD="$(echo "$CMD" | jq -r ".command.params.threshold // 510")"
    HOURS="$(echo "$CMD" | jq -r ".command.params.hours // 8")"
    BATCH="$(echo "$CMD" | jq -r ".command.params.batch_size // 4000")"
    AUDIT="$(echo "$CMD" | jq -r ".command.params.audit_rate // 500")"
    RUN_WORKER="$(echo "$CMD" | jq -r ".command.params.worker_name // empty")"
    [ -z "$RUN_WORKER" ] && RUN_WORKER="${WORKER}_T${THRESHOLD}"

    RUN_ID="M1084_${RIG_ID}_T${THRESHOLD}_$(date +%Y%m%d_%H%M%S)"
    RUN_LOG="$LOG_DIR/${RUN_ID}.log"
    END=$((SECONDS + HOURS * 3600))

    export CODED_FAST_SHADOW_THRESHOLD="$THRESHOLD"
    export CODED_FAST_SHADOW_AUDIT_RATE="$AUDIT"
    export CODED_BATCH_SIZE="$BATCH"
    export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"
    export CODED_RANDOM2_HUGEPAGE="${CODED_RANDOM2_HUGEPAGE:-1}"
    export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
    export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
    export CODED_SCORE_SAMPLE_BATCH_RATE="${CODED_SCORE_SAMPLE_BATCH_RATE:-0}"
    export CODED_SHADOW_AVX512_LIVE="${CODED_SHADOW_AVX512_LIVE:-1}"
    export CODED_LOG_MODE="${CODED_LOG_MODE:-dev}"

    curl -s -X POST "$API/runs/start" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"miner_version\":\"m10.84b-fleet-agent\",\"backend\":\"$CODED_KERNEL_BACKEND\",\"threshold\":$THRESHOLD,\"threads\":$THREADS,\"batch_size\":$BATCH,\"audit_rate\":$AUDIT,\"gate_mode\":\"single\",\"hostname\":\"$(hostname)\",\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2_supported\":$AVX2,\"avx512_supported\":$AVX512,\"hugepages_total\":${HPT:-0},\"hugepages_free\":${HPF:-0},\"hardware\":{\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2\":$AVX2,\"avx512\":$AVX512}}" >/dev/null || true

    echo "[CODED_FLEET] starting command=$COMMAND_ID run=$RUN_ID threshold=$THRESHOLD hours=$HOURS"

    while [ "$SECONDS" -lt "$END" ]; do
      "$MINER_BIN" --pool "$POOL" --wallet "$WALLET" --worker "$RUN_WORKER" --threads "$THREADS" 2>&1 | tee -a "$RUN_LOG"
      EC=${PIPESTATUS[0]}
      echo "[CODED_FLEET] miner exited code=$EC; restarting in 10s" | tee -a "$RUN_LOG"
      sleep 10
    done

    curl -s -X POST "$API/runs/end" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"run_id\":\"$RUN_ID\",\"status\":\"completed\",\"end_reason\":\"fleet_command_completed\"}" >/dev/null || true

    curl -s -X POST "$API/commands/complete" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"command_id\":\"$COMMAND_ID\",\"result\":{\"run_id\":\"$RUN_ID\"}}" >/dev/null || true

    echo "[CODED_FLEET] command completed command=$COMMAND_ID run=$RUN_ID"
  done
else
  "$MINER_BIN" \
    --pool "$POOL" \
    --wallet "$WALLET" \
    --worker "$WORKER" \
    --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE"
fi
