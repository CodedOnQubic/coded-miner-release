#!/usr/bin/env bash



# M10.99Z146_BUILDER_HANDOFF_ONLY_NO_GITHUB_RELEASE_API
# Rig2 builder is handoff-only. Primary owns GitHub Release assets.
# This prevents Rig2-side GitHub API 401 from marking successful builds failed.
export CODED_PRIMARY_OWNS_GITHUB_RELEASE_ASSETS="${CODED_PRIMARY_OWNS_GITHUB_RELEASE_ASSETS:-1}"

# M10.99Z145_PRIMARY_OWNS_GITHUB_RELEASE_ASSETS
# Primary owns GitHub Release asset creation. Rig2 builder only builds
# and publishes handoff artifacts to coded-miner-release main.
# This prevents false failed build_hive_release commands from Rig2-side
# GitHub API 401 errors. Primary auto-publisher finalizes releases.
export CODED_PRIMARY_OWNS_GITHUB_RELEASE_ASSETS="${CODED_PRIMARY_OWNS_GITHUB_RELEASE_ASSETS:-1}"

# --- M10.99Z78_WATERTIGHT_LATEST_RELEASE ---
coded_z78_tar_has_required_files() {
  # M10.99Z218_ROBUST_RELEASE_TAR_VALIDATION
  # Validate latest tarball robustly. Older grep -qx validation was flaky even when
  # tar -tzf clearly listed all required files.
  local art="$1"
  local list_file
  list_file="$(mktemp /tmp/coded_z218_tar_list_XXXXXX.txt)"

  if ! tar -tzf "$art" > "$list_file" 2>/tmp/coded_z218_tar_error.log; then
    echo "[M10.99Z218][FATAL] tar list failed art=$art err=$(cat /tmp/coded_z218_tar_error.log 2>/dev/null || true)"
    rm -f "$list_file"
    return 79
  fi

  sed -i 's/
$//' "$list_file" 2>/dev/null || true

  local missing=0
  for req in \
    "coded-miner/release_manifest.json" \
    "coded-miner/coded-miner" \
    "coded-miner/start.sh" \
    "coded-miner/h-run.sh"
  do
    if ! grep -Fqx "$req" "$list_file"; then
      echo "[M10.99Z218][FATAL] public latest missing required file: $req"
      missing=1
    fi
  done

  if [ "$missing" != "0" ]; then
    echo "[M10.99Z218] public latest tar contents:"
    cat "$list_file"
    rm -f "$list_file"
    return 79
  fi

  echo "[M10.99Z218] public latest tar validation ok"
  rm -f "$list_file"
  return 0
}

coded_z78_fix_tar_hrun() {
  local src="$1"
  local fixed="$2"
  local work
  work="$(mktemp -d /tmp/coded_z78_fix_XXXXXX)"
  tar -xzf "$src" -C "$work"
  if [ ! -f "$work/coded-miner/h-run.sh" ] && [ -f "$work/coded-miner/start.sh" ]; then
    cp "$work/coded-miner/start.sh" "$work/coded-miner/h-run.sh"
    chmod +x "$work/coded-miner/h-run.sh" "$work/coded-miner/start.sh" 2>/dev/null || true
    echo "[M10.99Z78] auto-added coded-miner/h-run.sh from start.sh"
  fi
  chmod +x "$work/coded-miner/"*.sh "$work/coded-miner/coded-miner" 2>/dev/null || true
  tar -C "$work" -czf "$fixed" coded-miner
  rm -rf "$work"
}


# M10.99Z249A_GLOBAL_FAIL_HELPER
z249a_fail_command() {
  local msg="$1"
  local action="${2:-failed}"
  local observed="${3:-unknown}"

  echo "[M10.99Z249A_GLOBAL_FAIL_HELPER] $msg action=$action observed=$observed" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

  if command -v jq >/dev/null 2>&1; then
    local payload
    payload="$(jq -nc \
      --arg error "$msg" \
      --arg marker "M10.99Z249A_GLOBAL_FAIL_HELPER" \
      --arg action "$action" \
      --arg observed_binary_magic "$observed" \
      --arg version "${version:-}" \
      --arg artifact "${artifact:-}" \
      '{error:$error,result:{marker:$marker,action:$action,observed_binary_magic:$observed_binary_magic,version:$version,artifact:$artifact}}')"
    m1099w4_api_post_json "/analytics/commands/${cid:-${command_id:-unknown}}/fail" "$payload" >/dev/null 2>&1 || true
  else
    m1099w4_api_post_json "/analytics/commands/${cid:-${command_id:-unknown}}/fail" "{\"error\":\"$msg\",\"result\":{\"marker\":\"M10.99Z249A_GLOBAL_FAIL_HELPER\",\"action\":\"$action\",\"observed_binary_magic\":\"$observed\",\"version\":\"${version:-}\",\"artifact\":\"${artifact:-}\"}}" >/dev/null 2>&1 || true
  fi
}

coded_z78_prepare_latest_artifact() {
  local art="$1"
  local fixed="${art%.tar.gz}.z78-fixed.tar.gz"

  echo "[M10.99Z78] validating latest artifact before upload: $art"
  tar -tzf "$art" | grep -E "coded-miner/(h-run.sh|start.sh|coded-miner|release_manifest.json)" || true

  if coded_z78_tar_has_required_files "$art"; then
    echo "[M10.99Z78] artifact already valid"
    return 0
  fi

  echo "[M10.99Z78] artifact missing required files; attempting auto-fix"
  coded_z78_fix_tar_hrun "$art" "$fixed"

  echo "[M10.99Z78] validating fixed artifact: $fixed"
  tar -tzf "$fixed" | grep -E "coded-miner/(h-run.sh|start.sh|coded-miner|release_manifest.json)" || true

  if ! coded_z78_tar_has_required_files "$fixed"; then
    echo "[M10.99Z78][FATAL] fixed artifact still invalid; refusing upload"
    return 78
  fi

  mv "$fixed" "$art"
  echo "[M10.99Z78] artifact fixed and replaced: $art"
}

coded_z78_validate_public_latest() {
  local expected_version="$1"
  local tmp
  tmp="$(mktemp -d /tmp/coded_z78_latest_check_XXXXXX)"
  curl -fL -o "$tmp/coded-miner-latest.tar.gz" "https://github.com/CodedOnQubic/coded-miner-release/releases/latest/download/coded-miner-latest.tar.gz?x=$(date +%s)"

# --- M10.99Z78_PRE_UPLOAD_VALIDATE_FALLBACK ---
if [ -n "${latest_artifact:-}" ] && [ -f "${latest_artifact:-}" ]; then
  coded_z78_prepare_latest_artifact "$latest_artifact"
fi
if [ -n "${artifact:-}" ] && [ -f "${artifact:-}" ] && echo "$artifact" | grep -q "coded-miner-latest.tar.gz"; then
  coded_z78_prepare_latest_artifact "$artifact"
fi
# --- /M10.99Z78_PRE_UPLOAD_VALIDATE_FALLBACK ---
  echo "[M10.99Z78] public latest contents:"
  tar -tzf "$tmp/coded-miner-latest.tar.gz" | grep -E "coded-miner/(h-run.sh|start.sh|coded-miner|release_manifest.json)" || true
  if ! coded_z78_tar_has_required_files "$tmp/coded-miner-latest.tar.gz"; then
    echo "[M10.99Z78][FATAL] public latest missing required files after upload"
    rm -rf "$tmp"
    return 79
  fi
  if ! tar -xzf "$tmp/coded-miner-latest.tar.gz" coded-miner/release_manifest.json -O | grep -q "$expected_version"; then
    echo "[M10.99Z78][WARN] public latest manifest does not contain expected version=$expected_version"
  fi
  rm -rf "$tmp"
}
# --- /M10.99Z78_WATERTIGHT_LATEST_RELEASE ---

set -Eeuo pipefail

# M10.99W5H_STRICT_BUILD_AND_RELEASE_PUSH
# Dedicated release builder must fail hard on build, clone, copy or push errors.
# Previous W5G incorrectly completed even when release_repo clone failed.

# M10.99W5D_FORCE_RELEASE_BUILDER_API
# Do not inherit CODED_POOL_API_URL/API from Hive/miner runtime here.
# Those env vars may point to a command/miner-local path and caused:
# curl 400 Bad Request while manual curl to 178.104.150.57:4000 worked.
# Only CODED_RELEASE_BUILDER_API is allowed to override this dedicated builder API.
API="${CODED_RELEASE_BUILDER_API:-http://178.104.150.57:4000}"
TOKEN="${CODED_ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}"
RIG_ID="${RIG_ID:-Rig2X3D}"

echo "[M10.99W5D_FORCE_RELEASE_BUILDER_API] API=${API%/} RIG_ID=$RIG_ID"

m1099w5h_repo_url() {
  # M10.99W5K_RELEASE_WRITE_REMOTE_ALIAS
  # Source repo uses github-private. Release repo uses github-release write alias.
  local repo="$1"
  local role="${2:-source}"

  if echo "$repo" | grep -qE '^(git@|https://|ssh://|github-private:|github-release:)'; then
    echo "$repo"
    return 0
  fi

  if [ "$role" = "release" ]; then
    echo "github-release:${repo}.git"
  else
    echo "github-private:${repo}.git"
  fi
}

m1099w5i_git_clone_retry() {
  # M10.99W5I_RELEASE_REPO_CLONE_RETRY
  # GitHub SSH occasionally disconnects during pack transfer on Hive rigs.
  # Use shallow clone and retry before failing the release command.
  local url="$1"
  local dir="$2"
  local label="${3:-repo}"
  local max_attempts="${4:-3}"
  local attempt=1

  rm -rf "$dir"

  while [ "$attempt" -le "$max_attempts" ]; do
    echo "[M10.99W5I_RELEASE_REPO_CLONE_RETRY] clone label=$label attempt=$attempt/$max_attempts url=$url dir=$dir"

    GIT_SSH_COMMAND="${GIT_SSH_COMMAND:-ssh -o ServerAliveInterval=15 -o ServerAliveCountMax=4 -o TCPKeepAlive=yes}" \
      git ls-remote "$url" HEAD

    if GIT_SSH_COMMAND="${GIT_SSH_COMMAND:-ssh -o ServerAliveInterval=15 -o ServerAliveCountMax=4 -o TCPKeepAlive=yes}" \
      git clone --depth 1 "$url" "$dir"; then
      test -d "$dir/.git"
      echo "[M10.99W5I_RELEASE_REPO_CLONE_RETRY] clone ok label=$label attempt=$attempt"
      return 0
    fi

    echo "[M10.99W5I_RELEASE_REPO_CLONE_RETRY] clone failed label=$label attempt=$attempt"
    rm -rf "$dir"
    sleep $((attempt * 5))
    attempt=$((attempt + 1))
  done

  echo "[M10.99W5I_RELEASE_REPO_CLONE_RETRY] clone exhausted label=$label url=$url"
  return 1
}

post_json() {
  # M10.99W5E_FILE_BACKED_JSON_POST
  # Send JSON through a temp file with --data-binary to avoid malformed body
  # issues from shell quoting / inherited runtime environment.
  local path="$1"
  local json="${2:-{}}"
  local tmp_body tmp_payload tmp_code url

  url="${API%/}$path"
  tmp_body="$(mktemp /tmp/coded_release_builder_http_body_XXXXXX.json)"
  tmp_payload="$(mktemp /tmp/coded_release_builder_http_payload_XXXXXX.json)"

  # M10.99W5G_NORMALIZE_JSON_PAYLOAD
  # Some Hive/bash path produced payloads like {"lease_minutes":90}} even when
  # CLAIM_PAYLOAD looked correct. Normalize/validate before curl so Express
  # json parser never receives malformed JSON.
  json="$(node -e '
    let s = process.argv[1] || "{}";
    function ok(x){ try { JSON.parse(x); return true; } catch(e){ return false; } }
    if (!ok(s)) {
      while (s.endsWith("}") && !ok(s)) s = s.slice(0, -1);
      if (!s.endsWith("}")) s += "}";
    }
    JSON.parse(s);
    process.stdout.write(s);
  ' "$json" 2>/dev/null || printf '%s' '{}')"

  printf '%s' "$json" > "$tmp_payload"

  echo "[M10.99W5G_NORMALIZE_JSON_PAYLOAD] url=$url payload_file=$tmp_payload payload=$(cat "$tmp_payload" 2>/dev/null)" >&2

  tmp_code="$(curl --http1.1 -sS -m 30 -w "%{http_code}" -o "$tmp_body" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -H "Accept: application/json" \
    -X POST "$url" \
    --data-binary "@$tmp_payload" || true)"

  if [ "$tmp_code" -lt 200 ] || [ "$tmp_code" -ge 300 ]; then
    echo "[M10.99W5E_FILE_BACKED_JSON_POST] url=$url http=$tmp_code response=$(cat "$tmp_body" 2>/dev/null)" >&2
    cat "$tmp_body" 2>/dev/null
    rm -f "$tmp_body" "$tmp_payload"
    return 22
  fi

  cat "$tmp_body"
  rm -f "$tmp_body" "$tmp_payload"
}

# M10.99W5F_FIX_CLAIM_JSON_PAYLOAD
CLAIM_PAYLOAD='{"lease_minutes":90}'
claim="$(post_json "/analytics/release-builder/claim/$RIG_ID" "$CLAIM_PAYLOAD" || true)"
echo "$claim"

claimed="$(echo "$claim" | jq -r '.claimed // false' 2>/dev/null || echo false)"
[ "$claimed" != "true" ] && exit 0

cmd="$(echo "$claim" | jq -c '.command')"
command_id="$(echo "$cmd" | jq -r '.command_id')"
params="$(echo "$cmd" | jq -c '.params')"

version="$(echo "$params" | jq -r '.version // empty')"
[ -z "$version" ] && version="v0.7.6-m1099w5-dedicated-release-$(date -u +%Y%m%d%H%M%S)"

branch="$(echo "$params" | jq -r '.branch // "main"')"
repo="$(echo "$params" | jq -r '.repo // "CodedOnQubic/coded-miner"')"
release_repo="$(echo "$params" | jq -r '.release_repo // "CodedOnQubic/coded-miner-release"')"
target="$(echo "$params" | jq -r '.target // "hive-linux-amd64-avx512"')"
artifact="$(echo "$params" | jq -r '.artifact_name // empty')"
[ -z "$artifact" ] && artifact="coded-miner-hive-linux-amd64-avx512-${version}.tar.gz"
latest_alias="$(echo "$params" | jq -r '.latest_alias // "coded-miner-latest.tar.gz"')"
build_log="$(echo "$params" | jq -r '.build_log // empty')"
[ -z "$build_log" ] && build_log="/tmp/coded_hive_release_${version}.log"

: > "$build_log"

heartbeat_loop() {
  while true; do
    post_json "/analytics/release-builder/heartbeat" "{\"command_id\":\"$command_id\",\"lease_minutes\":90}" >/dev/null 2>&1 || true
    sleep 30
  done
}

heartbeat_loop &
hb_pid=$!

cleanup_hb() {
  kill "$hb_pid" >/dev/null 2>&1 || true
}
trap cleanup_hb EXIT

fail() {
  local msg="$1"
  echo "[M10.99W5B_RELEASE_BUILDER_ROUTES] FAILED $msg" | tee -a "$build_log"
  post_json "/analytics/release-builder/fail" "$(jq -nc \
    --arg command_id "$command_id" \
    --arg error "$msg" \
    --arg log "$build_log" \
    '{command_id:$command_id,error:$error,result:{log:$log,marker:"M10.99W5B_RELEASE_BUILDER_ROUTES"}}')" >/dev/null || true
  exit 1
}

m1099w5l_upload_release_asset() {
  # M10.99Z146_BUILDER_HANDOFF_ONLY_NO_GITHUB_RELEASE_API
  # Previous W5L behavior tried to create/upload GitHub Release assets from Rig2.
  # That is now forbidden. Rig2 only builds and pushes handoff artifacts.
  # Primary auto-publisher finalizes GitHub Releases and marks commands completed.
  if [ "${CODED_PRIMARY_OWNS_GITHUB_RELEASE_ASSETS:-1}" = "1" ]; then
    echo "[M10.99Z146_BUILDER_HANDOFF_ONLY_NO_GITHUB_RELEASE_API] skip m1099w5l_upload_release_asset; primary owns GitHub Release assets"
    return 0
  fi

  echo "[M10.99Z146_BUILDER_HANDOFF_ONLY_NO_GITHUB_RELEASE_API] legacy GitHub Release API path disabled by default; set CODED_PRIMARY_OWNS_GITHUB_RELEASE_ASSETS=0 to restore legacy behavior"
  return 0
}

m1099w5l_create_github_release() {
  # M10.99W5L_CREATE_GITHUB_RELEASE_ASSETS
  local repo_slug="$1"
  local tag="$2"
  local version="$3"
  local out_dir="$4"
  local artifact="$5"
  local latest_alias="$6"

  local token_file="${CODED_RELEASE_GITHUB_TOKEN_FILE:-/root/.coded/github_release_token}"
  local token="${CODED_RELEASE_GITHUB_TOKEN:-}"

  if [ -z "$token" ] && [ -f "$token_file" ]; then
    token="$(cat "$token_file")"
  fi

  [ -n "$token" ] || fail "CODED_RELEASE_GITHUB_TOKEN missing; cannot create GitHub Release assets"

  echo "[M10.99W5L_CREATE_GITHUB_RELEASE_ASSETS] create release repo=$repo_slug tag=$tag"

  local release_json="/tmp/coded_github_release_${version}.json"
  local payload="/tmp/coded_github_release_payload_${version}.json"

  jq -nc \
    --arg tag "$tag" \
    --arg name "$version" \
    --arg body "Automated CODED Miner release $version built by Rig2 release builder. Marker: M10.99W5L_CREATE_GITHUB_RELEASE_ASSETS" \
    '{tag_name:$tag,name:$name,body:$body,draft:false,prerelease:false}' > "$payload"

  local http_code
  http_code="$(curl -sS -o "$release_json" -w "%{http_code}" \
    -X POST \
    -H "Authorization: Bearer $token" \
    -H "X-CODED-MARKER: M10.99W5M2_FIX_GITHUB_API_AUTH_HEADER_ROBUST" \
    -H "Accept: application/vnd.github+json" \
    -H "Content-Type: application/json" \
    --data-binary "@$payload" \
    "https://api.github.com/repos/$repo_slug/releases")"

  if [ "$http_code" = "422" ]; then
    echo "[M10.99W5L_CREATE_GITHUB_RELEASE_ASSETS] release exists, fetching existing release by tag=$tag"
    curl -fsS \
      -H "Authorization: Bearer $token" \
      -H "Accept: application/vnd.github+json" \
      "https://api.github.com/repos/$repo_slug/releases/tags/$tag" > "$release_json" \
      || fail "GitHub release exists but fetch by tag failed: $tag"
  elif [ "$http_code" -lt 200 ] || [ "$http_code" -ge 300 ]; then
    cat "$release_json" || true
    echo "[M10.99Z146_BUILDER_HANDOFF_ONLY_NO_GITHUB_RELEASE_API] ignoring legacy GitHub release create failed http=$http_code; primary will publish assets"; return 0
  fi

  local upload_url
  upload_url="$(jq -r '.upload_url // empty' "$release_json")"
  [ -n "$upload_url" ] || fail "GitHub release upload_url missing"

  m1099w5l_upload_release_asset "$upload_url" "$out_dir/$artifact" "$artifact" "$token"
  m1099w5l_upload_release_asset "$upload_url" "$out_dir/$latest_alias" "$latest_alias" "$token"
  m1099w5l_upload_release_asset "$upload_url" "$out_dir/SHA256SUMS" "SHA256SUMS" "$token"
  m1099w5l_upload_release_asset "$upload_url" "$out_dir/release_manifest.json" "release_manifest.json" "$token"

  echo "[M10.99W5L_CREATE_GITHUB_RELEASE_ASSETS] release assets uploaded tag=$tag"
}

{
  echo "[M10.99W5B_RELEASE_BUILDER_ROUTES] begin command=$command_id version=$version target=$target branch=$branch"
  date -u

  work="/tmp/coded_hive_release_work_${version}"
  root="$work/coded-miner"
  build_dir="$root/build-release"
  out_dir="$work/out"
  release_dir="$work/coded-miner-release"

  rm -rf "$work"
  mkdir -p "$work" "$out_dir"

  echo "[M10.99W5B_RELEASE_BUILDER_ROUTES] prepare coded-miner"
  if [ -d "/hive/codedonqubic/.git" ]; then
    git -C /hive/codedonqubic fetch origin "$branch"
    git -C /hive/codedonqubic reset --hard "origin/$branch"
    cp -a /hive/codedonqubic "$root"
  else
    m1099w5i_git_clone_retry "$(m1099w5h_repo_url "$repo" "source")" "$root" "coded-miner" 3
    git -C "$root" checkout "$branch"
    git -C "$root" pull --ff-only origin "$branch"
  fi

  # M10.99Z95_FORCE_BUILDER_VERIFIED_SOURCE_ROOT
  # The dedicated builder checkout is the verified source of truth.
  # Older builder flows could clone/build a stale c024811 tree while the builder repo itself
  # was already on the requested main commit. If expected_commit is set and the transient
  # source root does not match, switch to /hive/coded-builder/coded-miner and hard-fail
  # unless that verified root matches.
  expected_commit="$(echo "$params" | jq -r '.expected_commit // empty')"
  if [ -n "$expected_commit" ]; then
    transient_short="$(git -C "$root" rev-parse --short HEAD 2>/dev/null || true)"
    verified_root="/hive/coded-builder/coded-miner"
    if [ "$transient_short" != "$expected_commit" ] && [ -d "$verified_root/.git" ]; then
      echo "[M10.99Z95_FORCE_BUILDER_VERIFIED_SOURCE_ROOT] transient_root=$root transient_short=$transient_short expected=$expected_commit switching_to=$verified_root"
      git -C "$verified_root" fetch --all --prune
      git -C "$verified_root" checkout "$branch"
      git -C "$verified_root" reset --hard "origin/$branch"
      root="$verified_root"
    fi
  fi

  commit="$(git -C "$root" rev-parse HEAD)"
  commit_short="$(git -C "$root" rev-parse --short HEAD)"
  echo "[M10.99W5B_RELEASE_BUILDER_ROUTES] commit=$commit"
  echo "[M10.99Z94_EXPECTED_COMMIT_AND_HRUN_PACKAGE_GUARD] expected_commit=$expected_commit actual_short=$commit_short"

  if [ -n "$expected_commit" ] && ! echo "$commit_short" | grep -q "^$expected_commit"; then
    fail "expected_commit mismatch expected=$expected_commit actual=$commit_short full=$commit"
  fi

  bash -n "$root/release/hiveos/coded-miner/start.sh"
  bash -n "$root/release/hiveos/coded-miner/h-run.sh"
  grep -q "M10.99Z92B_START_RUN_INTERRUPT_TO_TOP_LEVEL" "$root/release/hiveos/coded-miner/start.sh" || fail "Z92B marker missing in start.sh"
  grep -q "M10.99Z92B_START_RUN_INTERRUPT_TO_TOP_LEVEL" "$root/release/hiveos/coded-miner/h-run.sh" || fail "Z92B marker missing in h-run.sh"

  # M10.99Z247_DISABLE_PRE_Z245_W5_PACKAGING_PATH
  # The old W5 path built and copied coded-miner before the Z245/Z246 Linux ELF gates.
  # That allowed macOS Mach-O artifacts to leak into Hive releases.
  # From now on, all build/package selection happens only in the Z245/Z243/Z242F guarded path below.
  echo "[M10.99Z247_DISABLE_PRE_Z245_W5_PACKAGING_PATH] old pre-gate cmake/package path skipped; guarded Linux ELF path owns packaging" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

  # M10.99Z248_W5_FAIL_COMMAND_HELPER
  # Must be defined before Z245/Z243 build gates call it.
  z243_fail_command() {
    local msg="$1"
    local action="${2:-failed}"
    local observed="${3:-unknown}"

    echo "[M10.99Z248_W5_FAIL_COMMAND_HELPER] $msg action=$action observed=$observed" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

    if command -v jq >/dev/null 2>&1; then
      local payload
      payload="$(jq -nc \
        --arg error "$msg" \
        --arg marker "M10.99Z248_W5_FAIL_COMMAND_HELPER" \
        --arg action "$action" \
        --arg observed_binary_magic "$observed" \
        --arg version "${version:-}" \
        --arg artifact "${artifact:-}" \
        '{error:$error,result:{marker:$marker,action:$action,observed_binary_magic:$observed_binary_magic,version:$version,artifact:$artifact}}')"
      m1099w4_api_post_json "/analytics/commands/${cid:-$command_id}/fail" "$payload" >/dev/null 2>&1 || true
    else
      m1099w4_api_post_json "/analytics/commands/${cid:-$command_id}/fail" "{\"error\":\"$msg\",\"result\":{\"marker\":\"M10.99Z248_W5_FAIL_COMMAND_HELPER\",\"action\":\"$action\",\"observed_binary_magic\":\"$observed\",\"version\":\"${version:-}\",\"artifact\":\"${artifact:-}\"}}" >/dev/null 2>&1 || true
    fi
  }

  # M10.99Z245_W5_NATIVE_LINUX_BUILD_BEFORE_PACKAGE
  z245_native_linux_build_before_package() {
    echo "[M10.99Z245_W5_NATIVE_LINUX_BUILD_BEFORE_PACKAGE] start pwd=$(pwd) repo_dir=${repo_dir:-} build_log=${build_log:-}" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

  # M10.99Z246B_W5_AVX512VPOPCNTDQ_BUILD_FLAGS
  # Required for _mm512_popcnt_epi64 on GCC/Clang Linux builds.
  # Prevents: target specific option mismatch for avx512vpopcntdq intrinsics.
  export CODED_W5_AVX512_FLAGS="-O3 -mavx512f -mavx512bw -mavx512vl -mavx512dq -mavx512cd -mavx512vpopcntdq -mavx512vbmi2 -mbmi -mbmi2"
  export CFLAGS="${CFLAGS:-} ${CODED_W5_AVX512_FLAGS}"
  export CXXFLAGS="${CXXFLAGS:-} ${CODED_W5_AVX512_FLAGS}"
  export CMAKE_C_FLAGS="${CMAKE_C_FLAGS:-} ${CODED_W5_AVX512_FLAGS}"
  export CMAKE_CXX_FLAGS="${CMAKE_CXX_FLAGS:-} ${CODED_W5_AVX512_FLAGS}"
  # M10.99Z249A_FORCE_CLEAN_CMAKE_FLAGS
  # Prevent stale CMake cache from ignoring AVX512VBMI2/BMI flags.
  z249a_root="${repo_dir:-}"
  if [ -z "$z249a_root" ] || [ ! -d "$z249a_root" ]; then
    z249a_root="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
  fi
  echo "[M10.99Z249A_FORCE_CLEAN_CMAKE_FLAGS] root=$z249a_root flags=$CODED_W5_AVX512_FLAGS" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
  rm -rf \
    "$z249a_root/build" \
    "$z249a_root/cmake-build-release" \
    "$z249a_root/cmake-build-debug" \
    "$z249a_root/CMakeCache.txt" \
    "$z249a_root/CMakeFiles" \
    2>/dev/null || true

  echo "[M10.99Z246B_W5_AVX512VPOPCNTDQ_BUILD_FLAGS] CFLAGS=$CFLAGS" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
  echo "[M10.99Z246B_W5_AVX512VPOPCNTDQ_BUILD_FLAGS] CXXFLAGS=$CXXFLAGS" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

    local root=""
    root="${repo_dir:-}"
    if [ -z "$root" ] || [ ! -d "$root" ]; then
      root="$(git rev-parse --show-toplevel 2>/dev/null || true)"
    fi
    if [ -z "$root" ] || [ ! -d "$root" ]; then
      root="$(pwd)"
    fi

    echo "[M10.99Z245_W5_NATIVE_LINUX_BUILD_BEFORE_PACKAGE] root=$root" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

    cd "$root" || return 1

    rm -rf build-hive-release build_release_hive build
    mkdir -p build-hive-release

    if command -v cmake >/dev/null 2>&1 && [ -f CMakeLists.txt ]; then
      echo "[M10.99Z245_W5_NATIVE_LINUX_BUILD_BEFORE_PACKAGE] cmake configure" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
      cmake -S . -B build-hive-release \
        -DCMAKE_BUILD_TYPE=Release \
        -DCODED_TARGET_HIVE=ON \
        -DCODED_ENABLE_AVX512=ON \
        -DCODED_ENABLE_AVX2=ON \
        >> "${build_log:-/tmp/coded_release_builder_agent_w5.log}" 2>&1 || {
          echo "[M10.99Z245_W5_NATIVE_LINUX_BUILD_BEFORE_PACKAGE] cmake configure failed, retry minimal" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
          rm -rf build-hive-release
          cmake -S . -B build-hive-release -DCMAKE_BUILD_TYPE=Release >> "${build_log:-/tmp/coded_release_builder_agent_w5.log}" 2>&1 || return 2
        }

      echo "[M10.99Z245_W5_NATIVE_LINUX_BUILD_BEFORE_PACKAGE] cmake build" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

  # M10.99Z250A_BUILD_CODED_MINER_TARGET_ONLY
  # Release artifact requires only coded-miner. Do not build optional tests/bench targets.
  echo "[M10.99Z250A_BUILD_CODED_MINER_TARGET_ONLY] cmake target=coded-miner only" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
      cmake --build build-hive-release --config Release --target coded-miner --parallel "$(nproc 2>/dev/null || echo 24)" >> "${build_log:-/tmp/coded_release_builder_agent_w5.log}" 2>&1 || return 3
    elif [ -f Makefile ]; then
      echo "[M10.99Z245_W5_NATIVE_LINUX_BUILD_BEFORE_PACKAGE] make build" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
      make -j"$(nproc 2>/dev/null || echo 24)" >> "${build_log:-/tmp/coded_release_builder_agent_w5.log}" 2>&1 || return 4
    else
      echo "[M10.99Z245_W5_NATIVE_LINUX_BUILD_BEFORE_PACKAGE] no CMakeLists.txt or Makefile found root=$root" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
      return 5
    fi

    echo "[M10.99Z245_W5_NATIVE_LINUX_BUILD_BEFORE_PACKAGE] build output candidates:" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
    find "$root" -maxdepth 6 -type f -name coded-miner -print 2>/dev/null | sort | while read -r f; do
      if [ -s "$f" ]; then
        local m
        m="$(head -c 4 "$f" 2>/dev/null | od -An -tx1 | tr -d ' \n' || true)"
        echo "[M10.99Z245_W5_NATIVE_LINUX_BUILD_BEFORE_PACKAGE] candidate=$f magic=$m" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
      fi
    done

    return 0
  }

  z245_native_linux_build_before_package || {
    z245_rc="$?"
    z243_fail_command \
      "M10.99Z245_W5_NATIVE_LINUX_BUILD_BEFORE_PACKAGE native Linux build failed rc=$z245_rc version=$version log=${build_log:-}" \
      "failed_native_linux_build" \
      "missing"
    exit 95
  }


  # M10.99Z243_W5_FORCE_LINUX_BUILD_BINARY
  # The W5 builder must package the Linux build output, never a stale repo-root or macOS artifact.
  z243_fail_command() {
    local msg="$1"
    local action="$2"
    local observed="${3:-}"
    local api_base="${API:-${CODED_RELEASE_BUILDER_API:-${CODED_POOL_API_URL:-${POOL_API_URL:-http://178.104.150.57:4000}}}}"
    api_base="${api_base%/}"

    echo "[$msg]" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

    if command -v jq >/dev/null 2>&1; then
      local payload
      payload="$(jq -nc \
        --arg error "$msg" \
        --arg marker "M10.99Z243_W5_FORCE_LINUX_BUILD_BINARY" \
        --arg action "$action" \
        --arg version "${version:-}" \
        --arg artifact "${artifact:-}" \
        --arg expected_binary_magic "7f454c46" \
        --arg observed_binary_magic "$observed" \
        '{error:$error,result:{marker:$marker,action:$action,version:$version,artifact:$artifact,expected_binary_magic:$expected_binary_magic,observed_binary_magic:$observed_binary_magic}}')"

      curl -fsS -X POST "$api_base/analytics/commands/$command_id/fail" \
        -H "Content-Type: application/json" \
        -d "$payload" >/dev/null 2>&1 \
      || curl -fsS -X POST "$api_base/commands/$command_id/fail" \
        -H "Content-Type: application/json" \
        -d "$payload" >/dev/null 2>&1 \
      || true
    fi
  }

  z243_magic_of() {
    [ -s "$1" ] || { echo "missing"; return 0; }
    head -c 4 "$1" | od -An -tx1 | tr -d ' \n'
  }

  # M10.99Z244_W5_ROBUST_LINUX_BINARY_FINDER
  z243_find_linux_binary() {
    # M10.99Z250B_STDOUT_CLEAN_BINARY_FINDER
    # IMPORTANT: stdout must contain ONLY the selected binary path.
    # All diagnostics go to build_log, otherwise command substitution corrupts z243_bin.
    local root="${repo_dir:-}"
    if [ -z "$root" ] || [ ! -d "$root" ]; then
      root="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
    fi

    local log="${build_log:-/tmp/coded_release_builder_agent_w5.log}"
    echo "[M10.99Z250B_STDOUT_CLEAN_BINARY_FINDER] root=$root pwd=$(pwd)" >> "$log"

    local candidates=""
    candidates="$candidates $root/build-hive-release/coded-miner"
    candidates="$candidates $root/build-hive-release/src/app/coded-miner"
    candidates="$candidates $root/build-hive-release/src/coded-miner"
    candidates="$candidates $root/build/coded-miner"
    candidates="$candidates $root/build/src/app/coded-miner"
    candidates="$candidates $root/coded-miner"

    local f=""
    local m=""
    for f in $candidates; do
      [ -f "$f" ] || continue
      m="$(head -c 4 "$f" 2>/dev/null | od -An -tx1 | tr -d ' \n' || true)"
      echo "[M10.99Z250B_STDOUT_CLEAN_BINARY_FINDER] candidate=$f magic=$m" >> "$log"
      if [ "$m" = "7f454c46" ]; then
        echo "$f"
        return 0
      fi
    done

    while IFS= read -r f; do
      [ -f "$f" ] || continue
      m="$(head -c 4 "$f" 2>/dev/null | od -An -tx1 | tr -d ' \n' || true)"
      echo "[M10.99Z250B_STDOUT_CLEAN_BINARY_FINDER] find_candidate=$f magic=$m" >> "$log"
      if [ "$m" = "7f454c46" ]; then
        echo "$f"
        return 0
      fi
    done < <(find "$root" -maxdepth 7 -type f -name coded-miner 2>/dev/null | sort)

    echo "[M10.99Z250B_STDOUT_CLEAN_BINARY_FINDER] no Linux ELF found" >> "$log"
    return 1
  }


  # M10.99Z251_W5_DEFINE_PACKAGE_PATHS_BEFORE_BINARY_COPY
  # pkg/out_dir must exist before Z243 copies selected ELF into package.
  # Previous failure: line 692: pkg: unbound variable after Linux ELF was found.
  out_dir="${out_dir:-/tmp/coded-hive-release-${version:-unknown}}"
  pkg="${pkg:-$out_dir/coded-miner}"
  mkdir -p "$pkg" "$out_dir"
  echo "[M10.99Z251_W5_DEFINE_PACKAGE_PATHS_BEFORE_BINARY_COPY] out_dir=$out_dir pkg=$pkg" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

  z243_bin="$(z243_find_linux_binary || true)"
  echo "[M10.99Z250B_SELECTED_BINARY] z243_bin=$z243_bin" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
  if [ -z "$z243_bin" ] || [ ! -s "$z243_bin" ]; then
    z243_fail_command \
      "M10.99Z243_W5_FORCE_LINUX_BUILD_BINARY no Linux ELF coded-miner build output found; refusing package version=$version" \
      "failed_no_linux_elf_build_output" \
      "missing"
    exit 92
  fi

  z243_magic="$(z243_magic_of "$z243_bin")"
  if [ "$z243_magic" != "7f454c46" ]; then
    z243_fail_command \
      "M10.99Z243_W5_FORCE_LINUX_BUILD_BINARY selected binary is not Linux ELF magic=$z243_magic bin=$z243_bin version=$version" \
      "failed_selected_binary_not_elf" \
      "$z243_magic"
    exit 93
  fi

  install -m 0755 "$z243_bin" "$pkg/coded-miner"
  z243_pkg_magic="$(z243_magic_of "$pkg/coded-miner")"
  echo "[M10.99Z243_W5_FORCE_LINUX_BUILD_BINARY] packaged_bin=$pkg/coded-miner source=$z243_bin magic=$z243_pkg_magic" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

  if [ "$z243_pkg_magic" != "7f454c46" ]; then
    z243_fail_command \
      "M10.99Z243_W5_FORCE_LINUX_BUILD_BINARY packaged binary is not Linux ELF magic=$z243_pkg_magic version=$version" \
      "failed_packaged_binary_not_elf" \
      "$z243_pkg_magic"
    exit 94
  fi



  # M10.99Z252_W5_PACKAGE_HIVE_RUNTIME_SCRIPTS
  # Fleet artifact must contain start.sh/h-run.sh plus coded-miner and release_manifest.json.
  # Previous candidate 2775a5e had valid ELF but tar missed coded-miner/start.sh.
  for f in start.sh h-run.sh coded_release_builder_agent_w5.sh; do
    if [ -f "release/hiveos/coded-miner/$f" ]; then
      cp "release/hiveos/coded-miner/$f" "$pkg/$f"
      chmod +x "$pkg/$f" 2>/dev/null || true
      echo "[M10.99Z252_W5_PACKAGE_HIVE_RUNTIME_SCRIPTS] copied $f -> $pkg/$f" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
    else
      echo "[M10.99Z252_W5_PACKAGE_HIVE_RUNTIME_SCRIPTS][WARN] missing release/hiveos/coded-miner/$f" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"
    fi
  done

  cat > "$pkg/release_manifest.json" <<EOF
{
  "version": "$version",
  "target": "$target",
  "repo": "$repo",
  "branch": "$branch",
  "commit": "$commit",
  "built_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "builder_rig_id": "$RIG_ID",
  "marker": "M10.99W5B_RELEASE_BUILDER_ROUTES"
}
EOF

  tar -czf "$out_dir/$artifact" -C "$out_dir" coded-miner

  # M10.99Z242F_W5_POST_TAR_ELF_GATE_NO_HELPER
  # W5 real safety gate: verify the packaged artifact itself immediately after tar,
  # before latest_alias copy, SHA256, release repo handoff, git push, or command complete.
  z242f_fail_command() {
    local msg="$1"
    local action="$2"
    local observed="${3:-}"
    local api_base="${API:-${CODED_RELEASE_BUILDER_API:-${CODED_POOL_API_URL:-${POOL_API_URL:-http://178.104.150.57:4000}}}}"
    api_base="${api_base%/}"

    echo "[$msg]" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

    if command -v jq >/dev/null 2>&1; then
      local payload
      payload="$(jq -nc \
        --arg error "$msg" \
        --arg marker "M10.99Z242F_W5_POST_TAR_ELF_GATE_NO_HELPER" \
        --arg action "$action" \
        --arg version "${version:-}" \
        --arg artifact "${artifact:-}" \
        --arg expected_binary_magic "7f454c46" \
        --arg observed_binary_magic "$observed" \
        '{error:$error,result:{marker:$marker,action:$action,version:$version,artifact:$artifact,expected_binary_magic:$expected_binary_magic,observed_binary_magic:$observed_binary_magic}}')"

      curl -fsS -X POST "$api_base/analytics/commands/$command_id/fail" \
        -H "Content-Type: application/json" \
        -d "$payload" >/dev/null 2>&1 \
      || curl -fsS -X POST "$api_base/commands/$command_id/fail" \
        -H "Content-Type: application/json" \
        -d "$payload" >/dev/null 2>&1 \
      || true
    fi
  }

  {
    z242f_art="$out_dir/$artifact"
    z242f_tmp="/tmp/m1099z242f_w5_verify_${version}_$$"
    rm -rf "$z242f_tmp"
    mkdir -p "$z242f_tmp"

    if [ ! -s "$z242f_art" ]; then
      z242f_fail_command \
        "M10.99Z242F_W5_POST_TAR_ELF_GATE_NO_HELPER missing artifact after tar artifact=$artifact version=$version path=$z242f_art" \
        "failed_missing_artifact_after_tar" \
        "missing"
      rm -rf "$z242f_tmp"
      exit 88
    fi

    if ! tar -xzf "$z242f_art" -C "$z242f_tmp" coded-miner/coded-miner coded-miner/release_manifest.json >/dev/null 2>&1; then
      z242f_fail_command \
        "M10.99Z242F_W5_POST_TAR_ELF_GATE_NO_HELPER failed to extract packaged artifact artifact=$artifact version=$version" \
        "failed_extract_packaged_artifact" \
        "extract_failed"
      rm -rf "$z242f_tmp"
      exit 89
    fi

    if [ ! -s "$z242f_tmp/coded-miner/coded-miner" ]; then
      z242f_fail_command \
        "M10.99Z242F_W5_POST_TAR_ELF_GATE_NO_HELPER missing packaged coded-miner binary artifact=$artifact version=$version" \
        "failed_missing_packaged_binary" \
        "missing"
      rm -rf "$z242f_tmp"
      exit 90
    fi

    z242f_magic="$(head -c 4 "$z242f_tmp/coded-miner/coded-miner" | od -An -tx1 | tr -d ' \n')"
    echo "[M10.99Z242F_W5_POST_TAR_ELF_GATE_NO_HELPER] artifact=$artifact version=$version magic=$z242f_magic" | tee -a "${build_log:-/tmp/coded_release_builder_agent_w5.log}"

    if [ "$z242f_magic" != "7f454c46" ]; then
      z242f_fail_command \
        "M10.99Z242F_W5_POST_TAR_ELF_GATE_NO_HELPER blocked non-ELF packaged Hive artifact magic=$z242f_magic version=$version artifact=$artifact" \
        "blocked_after_tar_before_release_handoff" \
        "$z242f_magic"
      rm -rf "$z242f_tmp"
      exit 91
    fi

    rm -rf "$z242f_tmp"
  }

  cp "$out_dir/$artifact" "$out_dir/$latest_alias"
  (cd "$out_dir" && sha256sum "$artifact" "$latest_alias" > SHA256SUMS)
  cp "$pkg/release_manifest.json" "$out_dir/release_manifest.json"

  echo "[M10.99W5H_STRICT_BUILD_AND_RELEASE_PUSH] clone release repo=$release_repo url=$(m1099w5h_repo_url "$release_repo" "release")"
  m1099w5i_git_clone_retry "$(m1099w5h_repo_url "$release_repo" "release")" "$release_dir" "coded-miner-release" 5

  test -d "$release_dir/.git"

  cp "$out_dir/$artifact" "$release_dir/$artifact"
  cp "$out_dir/$latest_alias" "$release_dir/$latest_alias"
  cp "$out_dir/SHA256SUMS" "$release_dir/SHA256SUMS"
  cp "$out_dir/release_manifest.json" "$release_dir/release_manifest.json"

  test -s "$release_dir/$artifact"
  test -s "$release_dir/$latest_alias"
  test -s "$release_dir/SHA256SUMS"
  test -s "$release_dir/release_manifest.json"

  git -C "$release_dir" status --short
  git -C "$release_dir" add "$artifact" "$latest_alias" SHA256SUMS release_manifest.json
  git -C "$release_dir" commit -m "Release $version"

  # M10.99W5J_VERIFY_RELEASE_PUSH
  # Push must be explicit and verified. A release command must never complete
  # if GitHub rejects the key as read-only or the remote HEAD does not advance.
  local_commit="$(git -C "$release_dir" rev-parse HEAD)"
  echo "[M10.99W5J_VERIFY_RELEASE_PUSH] local_commit=$local_commit pushing release repo"

  if ! git -C "$release_dir" push origin HEAD:main; then
    fail "release repo push failed; likely read-only deploy key for coded-miner-release"
  fi

  remote_commit="$(git -C "$release_dir" ls-remote origin refs/heads/main | awk '{print $1}' | head -n1)"
  echo "[M10.99W5J_VERIFY_RELEASE_PUSH] remote_commit=$remote_commit local_commit=$local_commit"

  if [ "$remote_commit" != "$local_commit" ]; then
    fail "release repo push verification failed remote=$remote_commit local=$local_commit"
  fi

  # M10.99W5L_CREATE_GITHUB_RELEASE_ASSETS
  # HiveOS install URL uses releases/latest/download/coded-miner-latest.tar.gz.
  # Therefore pushing files to main is not enough; create a real GitHub Release
  # and upload the latest/versioned artifacts as release assets.
  git -C "$release_dir" tag -f "$version" "$local_commit"
  git -C "$release_dir" push origin "refs/tags/$version" --force

  m1099w5l_create_github_release "$release_repo" "$version" "$version" "$out_dir" "$artifact" "$latest_alias"

  echo "[M10.99Z145_PRIMARY_OWNS_GITHUB_RELEASE_ASSETS] completed handoff version=$version artifact=$artifact remote_commit=$remote_commit primary_owns_assets=${CODED_PRIMARY_OWNS_GITHUB_RELEASE_ASSETS:-1}"
} >> "$build_log" 2>&1 || fail "build script failed; see $build_log"


# --- M10.99Z73_ENSURE_HRUN_IN_RELEASE_PACKAGE ---
# Release packages must include coded-miner/h-run.sh because Hive root runner
# delegates to /hive/miners/custom/coded-miner/h-run.sh.
coded_z73_ensure_hrun_in_packages() {
  for d in /tmp/coded_hive_release_work_* /tmp/*coded*release*; do
    [ -d "$d" ] || continue
    while IFS= read -r start_file; do
      pkg_dir="$(dirname "$start_file")"
      if [ -f "$pkg_dir/start.sh" ] && [ ! -f "$pkg_dir/h-run.sh" ]; then
        cp "$pkg_dir/start.sh" "$pkg_dir/h-run.sh"
        chmod +x "$pkg_dir/h-run.sh" "$pkg_dir/start.sh" 2>/dev/null || true
        echo "[M10.99Z73] added missing h-run.sh to release package: $pkg_dir"
      fi
    done <<EOF
$(find "$d" -path "*/coded-miner/start.sh" -type f 2>/dev/null)
EOF
  done
}
coded_z73_ensure_hrun_in_packages
# --- /M10.99Z73_ENSURE_HRUN_IN_RELEASE_PACKAGE ---


# --- M10.99Z78_POST_UPLOAD_PUBLIC_VALIDATE ---
coded_z78_validate_public_latest "${version:-unknown}" || exit $?
# --- /M10.99Z78_POST_UPLOAD_PUBLIC_VALIDATE ---

post_json "/analytics/release-builder/complete" "$(jq -nc \
  --arg command_id "$command_id" \
  --arg version "$version" \
  --arg artifact "$artifact" \
  --arg latest_alias "$latest_alias" \
  --arg log "$build_log" \
  '{command_id:$command_id,result:{version:$version,artifact:$artifact,latest_alias:$latest_alias,log:$log,marker:"M10.99W5B_RELEASE_BUILDER_ROUTES"}}')" >/dev/null || true

echo "[M10.99W5B_RELEASE_BUILDER_ROUTES] command completed command=$command_id" | tee -a "$build_log"
