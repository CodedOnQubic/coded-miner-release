# CODED Miner HiveOS Test Release

Test package for validating:
- HiveOS auto install
- pool connectivity
- worker visibility in frontend
- live it/s reporting

This is a test release, not the final production package.