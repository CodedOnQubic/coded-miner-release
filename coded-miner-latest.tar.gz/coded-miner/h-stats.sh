#!/usr/bin/env bash
set -euo pipefail

LOG_FILE="/var/log/miner/coded-miner/coded-miner.log"

# Fallbacks
HASHRATE="0"
ACCEPTED="0"
REJECTED="0"
UPTIME="0"

# Try common HiveOS/custom miner log locations
if [ ! -f "$LOG_FILE" ]; then
  LOG_FILE="$(find /var/log/miner -type f 2>/dev/null | grep -i 'coded' | head -n1 || true)"
fi

if [ -n "${LOG_FILE:-}" ] && [ -f "$LOG_FILE" ]; then
  LAST_STATUS="$(grep '\[ \$0.01 CODED \]' "$LOG_FILE" | tail -n1 || true)"

  if [ -n "$LAST_STATUS" ]; then
    HASHRATE="$(printf '%s\n' "$LAST_STATUS" | sed -nE 's/.*\] ([0-9]+) it\/s.*/\1/p' | tail -n1)"
    ACCEPTED="$(printf '%s\n' "$LAST_STATUS" | sed -nE 's/.*SOLS: ([0-9]+)\/([0-9]+).*/\1/p' | tail -n1)"
    REJECTED="$(printf '%s\n' "$LAST_STATUS" | sed -nE 's/.*\(R:([0-9]+)\).*/\1/p' | tail -n1)"
  fi
fi

HASHRATE="${HASHRATE:-0}"
ACCEPTED="${ACCEPTED:-0}"
REJECTED="${REJECTED:-0}"

cat <<JSON
{
  "hs": [$HASHRATE],
  "hs_units": "it/s",
  "ar": [$ACCEPTED, $REJECTED],
  "algo": "CODED",
  "bus_numbers": [0],
  "uptime": $UPTIME
}
JSON
