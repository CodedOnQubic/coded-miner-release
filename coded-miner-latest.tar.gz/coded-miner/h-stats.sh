#!/usr/bin/env bash

LOG_FILE="/var/log/miner/coded-miner/coded-miner.log"

HASHRATE=0
ACCEPTED=0
REJECTED=0

if [ -f "$LOG_FILE" ]; then
  LAST_STATUS="$(grep '\[ \$0.01 CODED \].*it/s' "$LOG_FILE" | tail -n1)"

  if [ -n "$LAST_STATUS" ]; then
    HASHRATE="$(echo "$LAST_STATUS" | sed -nE 's/.*\[[A-Z0-9]+\][[:space:]]+([0-9]+)[[:space:]]+it\/s.*/\1/p')"
    ACCEPTED="$(echo "$LAST_STATUS" | sed -nE 's/.*SOLS:[[:space:]]*([0-9]+)\/([0-9]+).*/\1/p')"
    REJECTED="$(echo "$LAST_STATUS" | sed -nE 's/.*\(R:([0-9]+)\).*/\1/p')"
  fi
fi

HASHRATE="${HASHRATE:-0}"
ACCEPTED="${ACCEPTED:-0}"
REJECTED="${REJECTED:-0}"

khs="$HASHRATE"
stats="{\"hs\":[${HASHRATE}],\"hs_units\":\"hs\",\"ar\":[${ACCEPTED},${REJECTED}],\"algo\":\"CODED\",\"bus_numbers\":[0]}"