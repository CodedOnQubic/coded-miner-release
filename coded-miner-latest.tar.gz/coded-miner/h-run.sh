#!/usr/bin/env bash
set -euo pipefail

echo "[CODED] coded-miner h-run.sh starting..."
cd /hive/miners/custom/coded-miner
exec ./start.sh