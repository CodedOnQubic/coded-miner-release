#!/usr/bin/env bash
set -euo pipefail

echo "[CODED] ROOT h-run.sh starting..."

source /hive/miners/custom/h-config.sh

echo "[CODED] Generating config.json..."
miner_config_gen

echo "[CODED] Generated config:"
cat /hive/miners/custom/coded-miner/config.json || true

echo "[CODED] Starting coded-miner..."
source /hive/miners/custom/coded-miner/h-run.sh