#!/usr/bin/env bash
set -euo pipefail

echo "[CODED] ROOT h-run.sh starting..."

INSTALL_URL="https://github.com/CodedOnQubic/coded-miner-release/releases/latest/download/coded-miner-latest.tar.gz"
UPDATE_LOCK="/tmp/coded-miner-update.lock"

if [ "${CODED_SKIP_AUTO_UPDATE:-0}" != "1" ]; then
  if [ ! -f "$UPDATE_LOCK" ]; then
    touch "$UPDATE_LOCK"

    echo "[CODED] Auto-updating miner from latest release..."

    rm -f /hive/coded-miner-latest.tar.gz
    wget --no-cache -O /hive/coded-miner-latest.tar.gz "$INSTALL_URL"

    rm -rf /hive/miners/custom/coded-miner
    tar -xzf /hive/coded-miner-latest.tar.gz -C /hive/miners/custom

    chmod +x /hive/miners/custom/h-config.sh || true
    chmod +x /hive/miners/custom/h-run.sh || true
    chmod +x /hive/miners/custom/h-stats.sh || true
    chmod +x /hive/miners/custom/coded-miner/* || true

    rm -f "$UPDATE_LOCK"
  fi
fi

source /hive/miners/custom/h-config.sh

echo "[CODED] Generating config.json..."
miner_config_gen

echo "[CODED] Generated config:"
cat /hive/miners/custom/coded-miner/config.json || true

echo "[CODED] Starting coded-miner..."
source /hive/miners/custom/coded-miner/h-run.sh