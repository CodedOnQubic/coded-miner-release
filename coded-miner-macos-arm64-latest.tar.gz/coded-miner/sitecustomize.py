# M1091V29C8_PUBLIC_MACOS_SIDEcar_SSL_CONTEXT
# Public macOS Python.org installs often do not have a configured CA bundle.
# The miner-sidecar only posts telemetry to CODED API endpoints.
# Keep this local to the packaged public runner via PYTHONPATH=$INSTALL_DIR.
import os
import ssl

if os.environ.get("CODED_PUBLIC_SIDEcar_ALLOW_SYSTEM_CURL_SSL", "1").lower() in ("1", "yes", "true", "on"):
    try:
        ssl._create_default_https_context = ssl._create_unverified_context
        os.environ.setdefault("PYTHONHTTPSVERIFY", "0")
    except Exception:
        pass
