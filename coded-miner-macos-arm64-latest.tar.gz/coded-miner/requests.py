# M1091V29C7_REQUESTS_SHIM_CURL_FIRST
import json as _json
import shutil as _shutil
import subprocess as _subprocess
import urllib.error as _urllib_error
import urllib.request as _urllib_request

class Response:
    def __init__(self, status_code=0, text=""):
        self.status_code = int(status_code or 0)
        self.text = text or ""

    @property
    def ok(self):
        return 200 <= self.status_code < 300

    def json(self):
        try:
            return _json.loads(self.text or "{}")
        except Exception:
            return {}

    def raise_for_status(self):
        if not self.ok:
            raise RuntimeError(f"HTTP {self.status_code}: {self.text[:500]}")

def _curl_request(method, url, body=None, headers=None, timeout=20):
    curl = _shutil.which("curl") or "/usr/bin/curl"
    hdrs = []
    for k, v in dict(headers or {}).items():
        hdrs += ["-H", f"{k}: {v}"]

    cmd = [curl, "-sS", "-L", "-X", method, "--max-time", str(int(timeout or 20)), "-w", "\n%{http_code}"] + hdrs
    if body is not None:
        cmd += ["--data-binary", "@-"]
    cmd.append(str(url))

    try:
        proc = _subprocess.run(cmd, input=body, stdout=_subprocess.PIPE, stderr=_subprocess.PIPE, timeout=(timeout or 20) + 5, check=False)
        out = proc.stdout.decode("utf-8", errors="replace")
        err = proc.stderr.decode("utf-8", errors="replace")
        if "\n" in out:
            text, code_s = out.rsplit("\n", 1)
        else:
            text, code_s = out, "0"
        try:
            code = int(code_s.strip() or "0")
        except Exception:
            code = 0
        if code == 0 and err:
            text = err
        return Response(code, text)
    except Exception as e:
        return Response(0, f"{type(e).__name__}: {e}")

def post(url, json=None, data=None, headers=None, timeout=20, **kwargs):
    body = data
    hdrs = dict(headers or {})
    if body is None:
        body = _json.dumps(json if json is not None else {}).encode("utf-8")
        hdrs.setdefault("Content-Type", "application/json")
    elif isinstance(body, str):
        body = body.encode("utf-8")
    r = _curl_request("POST", url, body=body, headers=hdrs, timeout=timeout)
    if r.status_code:
        return r
    req = _urllib_request.Request(str(url), data=body, headers=hdrs, method="POST")
    try:
        with _urllib_request.urlopen(req, timeout=timeout) as resp:
            return Response(resp.getcode(), resp.read().decode("utf-8", errors="replace"))
    except _urllib_error.HTTPError as e:
        return Response(e.code, e.read().decode("utf-8", errors="replace"))
    except Exception as e:
        return Response(0, f"{type(e).__name__}: {e}")

def get(url, headers=None, timeout=20, **kwargs):
    r = _curl_request("GET", url, body=None, headers=headers, timeout=timeout)
    if r.status_code:
        return r
    req = _urllib_request.Request(str(url), headers=dict(headers or {}), method="GET")
    try:
        with _urllib_request.urlopen(req, timeout=timeout) as resp:
            return Response(resp.getcode(), resp.read().decode("utf-8", errors="replace"))
    except _urllib_error.HTTPError as e:
        return Response(e.code, e.read().decode("utf-8", errors="replace"))
    except Exception as e:
        return Response(0, f"{type(e).__name__}: {e}")
