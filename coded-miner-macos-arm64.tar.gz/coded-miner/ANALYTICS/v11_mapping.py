# M1091V19_RUNTIME_RAW_COUNTER_FIX
# M1091V12_ANALYTICS_FIELD_MAPPING
#
# Normalize V11 canonical analytics frames before upload/persist.
# Purpose:
# - use raw.analytics_frame as source of truth for live it/s
# - preserve real_score evidence when max_real_score_seen is present
# - fix semantic_reason=no_real_score_evidence on V11 frames
# - map score_mode from frame into score_context
# - never invent total_seen/pass/audited counts from max score
#
# This module is intentionally schema-safe: unsupported DB columns remain
# inside raw; existing top-level fields are only overwritten with real frame
# values when the frame actually contains them.

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, Optional


def _to_int(v: Any, default: int = 0) -> int:
    try:
        if v is None or v == "":
            return default
        return int(float(str(v)))
    except Exception:
        return default


def _to_float(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == "":
            return default
        return float(str(v))
    except Exception:
        return default


def _truthy(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("1", "true", "yes", "y", "on")


def _ensure_dict(d: Dict[str, Any], key: str) -> Dict[str, Any]:
    v = d.get(key)
    if not isinstance(v, dict):
        v = {}
        d[key] = v
    return v


def extract_analytics_frame(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Find the canonical CODED_ANALYTICS_FRAME in known payload shapes."""
    if not isinstance(payload, dict):
        return {}

    raw = payload.get("raw")
    if isinstance(raw, dict):
        frame = raw.get("analytics_frame")
        if isinstance(frame, dict):
            return frame

        nested = raw.get("raw")
        if isinstance(nested, dict):
            frame = nested.get("analytics_frame")
            if isinstance(frame, dict):
                return frame

    frame = payload.get("analytics_frame")
    if isinstance(frame, dict):
        return frame

    return {}


def has_v11_real_score_evidence(frame: Dict[str, Any]) -> bool:
    if not isinstance(frame, dict):
        return False

    if _truthy(frame.get("real_score_available")):
        return True

    if _to_int(frame.get("max_real_score_seen")) > 0:
        return True

    if _to_int(frame.get("max_real_score_passed")) > 0:
        return True

    if _to_int(frame.get("max_real_score_audited_skip")) > 0:
        return True

    if _to_int(frame.get("real300")) > 0 or _to_int(frame.get("real310")) > 0 or _to_int(frame.get("real321")) > 0:
        return True

    return False


def normalize_payload_for_upload(endpoint: Any, payload: Any) -> Any:
    """Idempotently normalize any analytics payload dict."""
    if not isinstance(payload, dict):
        return payload

    p = payload
    raw = _ensure_dict(p, "raw")
    frame = extract_analytics_frame(p)

    if not frame:
        return p

    marker = str(frame.get("marker", ""))
    is_v11 = marker == "M1091V11" or "max_real_score_seen" in frame or "total_iterations" in frame

    if not is_v11:
        return p

    # Identity / runtime basics. Do not overwrite with empty values.
    if frame.get("rig_id"):
        p["rig_id"] = str(frame.get("rig_id"))
    if frame.get("run_id"):
        p["run_id"] = str(frame.get("run_id"))
    if frame.get("worker") and not p.get("worker_name"):
        p["worker_name"] = str(frame.get("worker"))
    if frame.get("backend"):
        p["backend"] = str(frame.get("backend"))
    if frame.get("threads") is not None:
        p["threads"] = _to_int(frame.get("threads"), _to_int(p.get("threads")))
    if frame.get("threshold") is not None:
        p["threshold"] = _to_int(frame.get("threshold"), _to_int(p.get("threshold")))

    # M1099Z63H_FINAL_SPEED_ONLY
    # Legacy avg_its/last_its promotion removed. Final speed payload uses only:
    # hash_it_s, avg_hash_it_s_30s, pipeline_it_s, router_scoring_it_s, qatum_fullscore_it_s.

    # Existing persisted numeric fields.
    for k in ("total_seen", "total_pass", "total_audited", "false_negative", "real300", "real310", "real321"):
        if frame.get(k) is not None:
            p[k] = _to_int(frame.get(k), _to_int(p.get(k)))

    # M1091V24D_UNIVERSAL_SCORE_FRAME_PROMOTION
    # CODED_ANALYTICS_FRAME is the backend-neutral source for AVX2, AVX512,
    # ARM NEON and CUDA. Promote score bucket counters into raw so downstream
    # AI frames and frontend can read one universal shape.
    frame_real300 = _to_int(frame.get("real300"))
    frame_real310 = _to_int(frame.get("real310"))
    frame_real321 = _to_int(frame.get("real321"))

    frame_score_300_309 = max(_to_int(frame.get("score_300_309_count")), frame_real300)
    frame_score_310_320 = max(_to_int(frame.get("score_310_320_count")), frame_real310)
    frame_score_321_plus = max(_to_int(frame.get("score_321_plus_count")), frame_real321)

    frame_score_ge300 = max(
        _to_int(frame.get("score_ge300_count")),
        frame_score_300_309 + frame_score_310_320 + frame_score_321_plus,
    )
    frame_score_ge310 = max(
        _to_int(frame.get("score_ge310_count")),
        frame_score_310_320 + frame_score_321_plus,
    )
    frame_score_ge321 = max(
        _to_int(frame.get("score_ge321_count")),
        frame_score_321_plus,
    )

    # Top-level payload fields for DB columns where supported.
    p["real300"] = max(_to_int(p.get("real300")), frame_real300)
    p["real310"] = max(_to_int(p.get("real310")), frame_real310)
    p["real321"] = max(_to_int(p.get("real321")), frame_real321)

    # Raw-safe universal analytics fields.
    raw["real300"] = max(_to_int(raw.get("real300")), frame_real300)
    raw["real310"] = max(_to_int(raw.get("real310")), frame_real310)
    raw["real321"] = max(_to_int(raw.get("real321")), frame_real321)

    raw["score_300_309_count"] = max(_to_int(raw.get("score_300_309_count")), frame_score_300_309)
    raw["score_310_320_count"] = max(_to_int(raw.get("score_310_320_count")), frame_score_310_320)
    raw["score_321_plus_count"] = max(_to_int(raw.get("score_321_plus_count")), frame_score_321_plus)
    raw["score_ge300_count"] = max(_to_int(raw.get("score_ge300_count")), frame_score_ge300)
    raw["score_ge310_count"] = max(_to_int(raw.get("score_ge310_count")), frame_score_ge310)
    raw["score_ge321_count"] = max(_to_int(raw.get("score_ge321_count")), frame_score_ge321)

    raw["max_real_score_seen"] = max(
        _to_int(raw.get("max_real_score_seen")),
        _to_int(frame.get("max_real_score_seen")),
    )
    raw["m1091v24d_universal_score_frame_promotion"] = True

    # Extended V11 fields stay raw-safe even if DB has no columns yet.
    raw["v11_total_iterations"] = _to_int(frame.get("total_iterations"))

    # M1091V18_UNIVERSAL_RAW_SCORING_FULLSCORE_METRICS
    raw["raw_it_s"] = _to_float(frame.get("raw_it_s"), _to_float(frame.get("total_it_s"), _to_float(frame.get("avg_its"))))
    raw["total_it_s"] = _to_float(frame.get("total_it_s"), _to_float(frame.get("raw_it_s"), _to_float(frame.get("avg_its"))))

    # M1091V21F_HASH_IT_S_RAW_MAPPING
    # Naming contract:
    # - hash_it_s: candidate/hash hotloop input rate, main dashboard hashrate.
    # - avg_hash_it_s_30s: native rolling 30s average of hash_it_s.
    # - pipeline_it_s: full miner-loop throughput including router/fullscore stalls.
    # - router_scoring_it_s: candidates reaching router/scoring.
    # - qatum_fullscore_it_s: real Qatum fullscore evaluations.
    raw["backend_hotloop_it_s"] = _to_float(frame.get("backend_hotloop_it_s"), 0.0)
    raw["hash_it_s"] = _to_float(
        frame.get("hash_it_s"),
        _to_float(frame.get("backend_hotloop_it_s"), _to_float(frame.get("total_it_s"), 0.0)),
    )
    raw["avg_hash_it_s_30s"] = _to_float(frame.get("avg_hash_it_s_30s"), 0.0)
    raw["pipeline_it_s"] = _to_float(
        frame.get("pipeline_it_s"),
        _to_float(frame.get("end_to_end_raw_it_s"), _to_float(frame.get("raw_last_its"), 0.0)),
    )
    raw["end_to_end_raw_it_s"] = _to_float(frame.get("end_to_end_raw_it_s"), raw["pipeline_it_s"])
    raw["router_scoring_it_s"] = _to_float(
        frame.get("router_scoring_it_s"),
        _to_float(frame.get("scoring_it_s"), 0.0),
    )
    raw["qatum_fullscore_it_s"] = _to_float(
        frame.get("qatum_fullscore_it_s"),
        _to_float(frame.get("fullscore_it_s"), 0.0),
    )
    raw["scoring_stage_profile_it_s"] = _to_float(frame.get("scoring_stage_profile_it_s"), 0.0)
    raw["scoring_it_s"] = _to_float(frame.get("scoring_it_s"), 0.0)
    raw["fullscore_it_s"] = _to_float(frame.get("fullscore_it_s"), 0.0)
    # M1091V20G2_DYNAMIC_BATCH_FIELDS
    raw["batch_size"] = _to_int(frame.get("batch_size"))
    raw["worker_count"] = _to_int(frame.get("worker_count"))
    raw["raw_batch_span"] = _to_int(frame.get("raw_batch_span"))
    raw["batch_elapsed_ms"] = _to_int(frame.get("batch_elapsed_ms"))
    raw["completed_batch_hashrate"] = _to_float(frame.get("completed_batch_hashrate"), 0.0)
    raw["raw_speed_quality"] = frame.get("raw_speed_quality")
    raw["raw_total_iterations"] = _to_int(frame.get("raw_total_iterations"))
    raw["scoring_total_iterations"] = _to_int(frame.get("scoring_total_iterations"))
    raw["fullscore_total_iterations"] = _to_int(frame.get("fullscore_total_iterations"))
    raw["m1091v18_metrics"] = True

    # M1091V20G2_DYNAMIC_BATCH_FIELDS
    p["batch_size"] = raw["batch_size"]
    p["worker_count"] = raw["worker_count"]
    p["raw_batch_span"] = raw["raw_batch_span"]
    p["batch_elapsed_ms"] = raw["batch_elapsed_ms"]
    p["hash_it_s"] = raw["hash_it_s"]
    p["avg_hash_it_s_30s"] = raw["avg_hash_it_s_30s"]
    p["pipeline_it_s"] = raw["pipeline_it_s"]
    p["router_scoring_it_s"] = raw["router_scoring_it_s"]
    p["qatum_fullscore_it_s"] = raw["qatum_fullscore_it_s"]
    p["completed_batch_hashrate"] = raw["completed_batch_hashrate"]
    p["raw_speed_quality"] = raw["raw_speed_quality"]
    p["raw_total_iterations"] = raw["raw_total_iterations"]
    p["scoring_total_iterations"] = raw["scoring_total_iterations"]
    p["fullscore_total_iterations"] = raw["fullscore_total_iterations"]
    raw["v11_real_its_available"] = _truthy(frame.get("real_its_available"))
    raw["v11_max_real_score_seen"] = _to_int(frame.get("max_real_score_seen"))
    raw["v11_max_real_score_passed"] = _to_int(frame.get("max_real_score_passed"))
    raw["v11_max_real_score_audited_skip"] = _to_int(frame.get("max_real_score_audited_skip"))
    raw["v11_score_mode"] = str(frame.get("score_mode") or p.get("score_mode") or "unknown")
    raw["v11_mapping_marker"] = "M1091V12_ANALYTICS_FIELD_MAPPING"

    # Score mode normalization.
    if raw["v11_score_mode"] and raw["v11_score_mode"] != "unknown":
        p["score_mode"] = raw["v11_score_mode"]
        score_context = _ensure_dict(raw, "score_context")
        if not score_context.get("score_engine_mode") or score_context.get("score_engine_mode") == "unknown":
            score_context["score_engine_mode"] = raw["v11_score_mode"]

        analytics_context = _ensure_dict(raw, "analytics_context")
        score = _ensure_dict(analytics_context, "score")
        if not score.get("score_engine_mode") or score.get("score_engine_mode") == "unknown":
            score["score_engine_mode"] = raw["v11_score_mode"]

    # Real score evidence normalization.
    evidence = has_v11_real_score_evidence(frame)
    if evidence:
        raw["real_score_available"] = True
        raw["saw_real_score"] = True
        raw["semantic_reason"] = "v11_real_score_evidence"
        raw["saw_qatum_reference_score"] = True
    else:
        raw.setdefault("real_score_available", False)
        raw.setdefault("saw_real_score", False)

    raw["saw_analytics_frame"] = True

    # Inventory for debugging and future AI consumers.
    raw["v11_analytics_field_inventory"] = sorted([str(k) for k in frame.keys()])

    return p
