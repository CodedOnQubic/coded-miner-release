#!/usr/bin/env python3
# M1091V2_ANALYTICS_CONTEXT_MODULE
from __future__ import annotations

import json
import os
import platform as py_platform
import time
from pathlib import Path
from typing import Any, Dict, Optional

MARKER = "M1091V2_ANALYTICS_CONTEXT_MODULE"

def env_any(*names: str, default: str = "") -> str:
    for name in names:
        value = os.environ.get(name)
        if value is not None and str(value).strip() != "":
            return str(value).strip()
    return default

def int_any(value: Any, default: int = 0) -> int:
    try:
        if value is None or value == "":
            return default
        return int(float(str(value)))
    except Exception:
        return default

def load_json(path: Path) -> Dict[str, Any]:
    try:
        if path.exists() and path.is_file():
            return json.loads(path.read_text(errors="replace"))
    except Exception:
        pass
    return {}

def release_manifest(log_path: Optional[str] = None) -> Dict[str, Any]:
    candidates = []

    explicit = env_any("CODED_RELEASE_MANIFEST", "RELEASE_MANIFEST")
    if explicit:
        candidates.append(Path(explicit))

    base = env_any("BASE", "CODED_BASE")
    if base:
        candidates.append(Path(base) / "release_manifest.json")

    candidates.append(Path(__file__).resolve().parents[1] / "release_manifest.json")

    if log_path:
        lp = Path(log_path)
        candidates.append(lp.parent / "release_manifest.json")
        candidates.append(lp.parent.parent / "release_manifest.json")

    for p in candidates:
        data = load_json(p)
        if data:
            data["_manifest_path"] = str(p)
            return data

    return {}

def qubic_context(identity: Any, now_ts: Optional[float] = None) -> Dict[str, Any]:
    now_ts = now_ts or time.time()

    epoch = int_any(
        env_any(
            "QUBIC_EPOCH",
            "CODED_EPOCH",
            "EPOCH",
            default=str(getattr(identity, "epoch", 0) or 0),
        ),
        0,
    )

    tick = int_any(env_any("QUBIC_TICK", "CODED_TICK", "LAST_SEED_TICK", "SEED_TICK"), 0)
    seed = env_any("QUBIC_SEED", "CODED_SEED", "CURRENT_SEED", "LAST_SEED")
    seed_state = env_any("QUBIC_SEED_STATE", "CODED_SEED_STATE", "SEED_STATE", default="unknown")

    return {
        "epoch": epoch,
        "epoch_id": f"qubic_epoch_{epoch}" if epoch else None,
        "tick": tick or None,
        "seed": seed or None,
        "seed_state": seed_state,
        "captured_at_unix": int(now_ts),
        "captured_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now_ts)),
        "source": "env_or_runner_plus_server_enrichment",
    }

def analytics_context(identity: Any, log_path: Optional[str] = None, now: Optional[str] = None) -> Dict[str, Any]:
    now_ts = time.time()
    manifest = release_manifest(log_path)

    backend = str(
        getattr(identity, "backend", "")
        or env_any("CODED_KERNEL_BACKEND", "CODED_BACKEND", default="unknown")
    )

    platform_name = str(
        getattr(identity, "platform", "")
        or env_any("CODED_PLATFORM", "CODED_BACKEND_PLATFORM", default="unknown")
    )

    router = env_any(
        "CODED_PRIORITY_BUDGET_ROUTER",
        "CODED_PRIORITY_ROUTER",
        "CODED_ROUTER",
        default=str(getattr(identity, "router", "") or "sidecar"),
    )

    matrix = env_any(
        "CODED_PRIORITY_BUDGET_MATRIX",
        "CODED_ROUTER_MATRIX",
        "CODED_PRIORITY_MATRIX",
        default=str(getattr(identity, "matrix", "") or "sidecar"),
    )

    asset_name = (
        manifest.get("asset")
        or manifest.get("asset_name")
        or env_any("CODED_ASSET_NAME")
        or None
    )

    asset_version = (
        manifest.get("version")
        or manifest.get("asset_version")
        or manifest.get("release")
        or env_any("CODED_ASSET_VERSION", "CODED_RELEASE_VERSION")
        or None
    )

    source_commit = (
        manifest.get("source_commit")
        or manifest.get("commit")
        or manifest.get("git_commit")
        or env_any("CODED_SOURCE_COMMIT", "GIT_COMMIT")
        or None
    )

    return {
        "marker": MARKER,
        "version": "M1091V2",
        "posted_at": now or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now_ts)),
        "identity": {
            "rig_id": getattr(identity, "rig_id", None),
            "worker_name": getattr(identity, "worker_name", None),
            "run_id_env": env_any("RUN_ID", "CODED_RUN_ID"),
        },
        "runtime": {
            "platform": platform_name,
            "arch": getattr(identity, "arch", None) or py_platform.machine(),
            "os": py_platform.system().lower(),
            "backend": backend,
            "backend_variant": env_any("CODED_BACKEND_VARIANT", "CODED_KERNEL_BACKEND_VARIANT", default=backend),
            "threshold": int_any(getattr(identity, "threshold", 0), 0),
            "threads": int_any(getattr(identity, "threads", 0), 0),
            "poll_sec": int_any(getattr(identity, "poll_sec", 0), 0),
        },
        "asset": {
            "asset_name": asset_name,
            "asset_version": asset_version,
            "source_commit": source_commit,
            "manifest": manifest or None,
        },
        "router": {
            "router_name": router or None,
            "priority_budget_router": router or None,
            "router_profile": env_any("CODED_ROUTER_PROFILE", "CODED_PROFILE", "CODED_DEFAULT_PROFILE", default="default"),
            "priority_budget_matrix": matrix or None,
            "matrix": matrix or None,
        },
        "qubic": qubic_context(identity, now_ts),
        "score": {
            "score_engine_mode": env_any("CODED_SCORE_ENGINE_MODE", "QATUM_SCORE_ENGINE_MODE", default="unknown"),
            "force_fullscore": env_any("CODED_FORCE_FULLSCORE"),
            "fullscore_all_backends": env_any("CODED_FULLSCORE_ALL_BACKENDS"),
            "prefilter_difficulty": env_any("CODED_PREFILTER_DIFFICULTY"),
        },
    }
