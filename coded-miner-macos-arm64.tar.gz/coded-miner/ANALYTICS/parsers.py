# M1091V19_RUNTIME_RAW_COUNTER_FIX
#!/usr/bin/env python3
# M1091V8_CANONICAL_ANALYTICS_FRAME_PARSER
from dataclasses import dataclass, field
import os
import re

@dataclass
class Metrics:
    total_seen: int = 0
    total_audited: int = 0
    scores: list = field(default_factory=list)
    max_score: int = 0
    avg_its: float = 0.0
    last_its: float = 0.0
    # M1091V21D_FRAME_AUTHORITY_FOR_ITS
    # Once a CODED_ANALYTICS_FRAME is seen, avg/last it/s must come from that frame.
    # Legacy progress lines are still useful for fallback but must not override frames.
    saw_analytics_frame: bool = False
    raw_it_s: float = 0.0
    total_it_s: float = 0.0
    scoring_it_s: float = 0.0
    fullscore_it_s: float = 0.0
    # M1091V20G2_DYNAMIC_BATCH_FIELDS
    batch_size: int = 0
    worker_count: int = 0
    raw_batch_span: int = 0
    batch_elapsed_ms: int = 0
    completed_batch_hashrate: float = 0.0
    raw_speed_quality: str = ""
    raw_total_iterations: int = 0
    scoring_total_iterations: int = 0
    fullscore_total_iterations: int = 0
    real280: int = 0
    real290: int = 0
    real300: int = 0
    real310: int = 0
    real321: int = 0
    max_real_score_seen: int = 0
    max_real_score_passed: int = 0
    max_real_score_audited_skip: int = 0
    m1091v18_metrics: bool = False
    algo0_avg_ms: float = 0.0

    saw_analytics_frame: bool = False
    saw_scalar_console: bool = False
    saw_direct_score: bool = False
    saw_hi_timing: bool = False
    saw_real_score: bool = False
    saw_qatum_reference_score: bool = False

    analytics_frame: dict = field(default_factory=dict)

def _tail(path, max_bytes=512000):
    if not path or not os.path.exists(path):
        return ""
    with open(path, "rb") as f:
        f.seek(max(0, os.path.getsize(path) - max_bytes))
        return f.read().decode("utf-8", errors="ignore")

def _float(v, default=0.0):
    try:
        return float(str(v).strip())
    except Exception:
        return default

def _int(v, default=0):
    try:
        return int(float(str(v).strip()))
    except Exception:
        return default

def _kv(line):
    out = {}
    for token in line.split():
        if "=" not in token:
            continue
        k, v = token.split("=", 1)
        k = k.strip()
        v = v.strip().strip("'").strip('"')
        if k:
            out[k] = v
    return out

def _parse_analytics_frame(m, line):
    frame = _kv(line)
    if not frame:
        return

    m.saw_analytics_frame = True
    m.analytics_frame = frame

    is_estimated = str(frame.get("estimated", "0")).lower() in ("1", "true", "yes", "y")
    if not is_estimated:
        # M1091V21D_FRAME_AUTHORITY_FOR_ITS
        m.saw_analytics_frame = True
        frame_total_its = _float(frame.get("total_it_s", frame.get("raw_it_s", frame.get("avg_its", 0))), 0)
        frame_last_its = _float(frame.get("last_its", frame_total_its), frame_total_its)
        frame_avg_its = _float(frame.get("avg_its", frame_total_its), frame_total_its)
        m.avg_its = frame_avg_its
        m.last_its = frame_last_its

        # M1091V18_UNIVERSAL_RAW_SCORING_FULLSCORE_METRICS
        m.raw_it_s = max(m.raw_it_s, _float(frame.get("raw_it_s", frame.get("total_it_s", 0))))
        m.total_it_s = max(m.total_it_s, _float(frame.get("total_it_s", frame.get("raw_it_s", 0))))
        m.scoring_it_s = max(m.scoring_it_s, _float(frame.get("scoring_it_s", 0)))
        m.fullscore_it_s = max(m.fullscore_it_s, _float(frame.get("fullscore_it_s", 0)))
        # M1091V20G2_DYNAMIC_BATCH_FIELDS
        m.batch_size = max(m.batch_size, int(_float(frame.get("batch_size", 0))))
        m.worker_count = max(m.worker_count, int(_float(frame.get("worker_count", 0))))
        m.raw_batch_span = max(m.raw_batch_span, int(_float(frame.get("raw_batch_span", 0))))
        m.batch_elapsed_ms = max(m.batch_elapsed_ms, int(_float(frame.get("batch_elapsed_ms", 0))))
        m.completed_batch_hashrate = max(m.completed_batch_hashrate, _float(frame.get("completed_batch_hashrate", 0)))
        if frame.get("raw_speed_quality"):
            m.raw_speed_quality = str(frame.get("raw_speed_quality"))
        m.raw_total_iterations = max(m.raw_total_iterations, int(_float(frame.get("raw_total_iterations", frame.get("total_iterations", 0)))))
        m.scoring_total_iterations = max(m.scoring_total_iterations, int(_float(frame.get("scoring_total_iterations", 0))))
        m.fullscore_total_iterations = max(m.fullscore_total_iterations, int(_float(frame.get("fullscore_total_iterations", 0))))
        # M1091V24A: pass through miner live telemetry score counters.
        # These are produced by src/core/miner_live_telemetry.h and must not be
        # reconstructed from max-score flags in frontend/AI.
        for _name in (
            "real280",
            "real290",
            "real300",
            "real310",
            "real321",
            "max_real_score_seen",
            "max_real_score_passed",
            "max_real_score_audited_skip",
        ):
            try:
                setattr(m, _name, max(int(getattr(m, _name, 0)), int(_float(frame.get(_name, 0)))))
            except Exception:
                pass
        m.m1091v18_metrics = bool(m.raw_it_s or m.total_it_s or m.scoring_it_s or m.fullscore_it_s)

    total_seen = _int(frame.get("total_seen", 0))
    total_audited = _int(frame.get("total_audited", 0))

    if total_seen > 0:
        m.total_seen = max(m.total_seen, total_seen)
    if total_audited > 0:
        m.total_audited = max(m.total_audited, total_audited)

    real_available = str(frame.get("real_score_available", "")).lower()
    if real_available in ("1", "true", "yes", "on"):
        m.saw_real_score = True

def parse_log(path):
    text = _tail(path)
    m = Metrics()
    direct_seen = 0
    direct_avg_sum = 0.0
    direct_avg_n = 0

    for line in text.splitlines():
        if "[CODED_ANALYTICS_FRAME]" in line:
            _parse_analytics_frame(m, line)
            continue

        if "[HI_TIMING" in line:
            m.saw_hi_timing = True
            for rx in (r"\bglobal_count=([0-9]+)", r"\btotal=([0-9]+)", r"\balgo0_count=([0-9]+)"):
                g = re.search(rx, line)
                if g:
                    v = int(g.group(1))
                    m.total_seen = max(m.total_seen, v)
                    m.total_audited = max(m.total_audited, v)

            g = re.search(r"\balgo0_avg_ms=([0-9]+(?:\.[0-9]+)?)", line)
            if g:
                m.algo0_avg_ms = float(g.group(1))

            hm = re.search(r"\blocal_avg_ms=([0-9]+(?:\.[0-9]+)?)", line)
            if hm:
                m.algo0_avg_ms = float(hm.group(1))

        pm = re.search(r"(?i)\|\s*\[([A-Z0-9_-]+)\]\s*([0-9]+(?:\.[0-9]+)?)\s*it/s\s*\|\s*([0-9]+(?:\.[0-9]+)?)\s*avg\s*it/s", line)
        if pm:
            m.saw_scalar_console = True
            # M1091V21D_FRAME_AUTHORITY_FOR_ITS
            # Do not let legacy console progress override CODED_ANALYTICS_FRAME speed.
            if not getattr(m, "saw_analytics_frame", False):
                m.last_its = float(pm.group(2))
                m.avg_its = float(pm.group(3))

        if "[DIRECT_SCORE]" in line:
            m.saw_direct_score = True
            for dm in re.finditer(r"\bchecked=([0-9]+)\b", line):
                v = int(dm.group(1))
                if 0 < v <= 4096:
                    direct_seen += v
            for am in re.finditer(r"\bavg_ms=([0-9]+(?:\.[0-9]+)?)", line):
                v = float(am.group(1))
                if 0 < v < 10:
                    direct_avg_sum += v
                    direct_avg_n += 1

        if "QATUM_REFERENCE_SCORE" in line or "QATUM_REAL_SCORE" in line:
            m.saw_qatum_reference_score = True

        if "REAL_SCORE" in line:
            m.saw_real_score = True

        if "[REAL_SCORE_AUDIT_DEBUG]" in line:
            m.saw_real_score = True
            cm = re.search(r"\bcount=([0-9]+)", line)
            if cm:
                c = int(cm.group(1))
                if c > 0:
                    m.total_seen = max(m.total_seen, c)
                    m.total_audited = max(m.total_audited, c)

            rm = re.search(r"\breal_score=([0-9]+)", line)
            if rm:
                score = int(rm.group(1))
                m.scores.append(score)
                m.max_score = max(m.max_score, score)

        for sm in re.finditer(r"\breal_score=([0-9]+)", line):
            s = int(sm.group(1))
            if s not in m.scores[-3:]:
                m.scores.append(s)
            m.max_score = max(m.max_score, s)

        am = re.search(r"\bavg_its=([0-9]+(?:\.[0-9]+)?)", line)
        if am and not getattr(m, "saw_analytics_frame", False):
            m.avg_its = max(m.avg_its, float(am.group(1)))

        lm = re.search(r"\blast_its=([0-9]+(?:\.[0-9]+)?)", line)
        if lm and not getattr(m, "saw_analytics_frame", False):
            m.last_its = max(m.last_its, float(lm.group(1)))

    if m.total_seen <= 0 and direct_seen > 0:
        m.total_seen = direct_seen
        m.total_audited = direct_seen

    if m.algo0_avg_ms <= 0 and direct_avg_n > 0:
        m.algo0_avg_ms = direct_avg_sum / direct_avg_n

    # M1091V21D_FRAME_AUTHORITY_FOR_ITS
    # Final safety: with analytics-frame authority, do not allow legacy/microprofile speeds
    # to poison sidecar avg_its/last_its.
    if getattr(m, "saw_analytics_frame", False) and getattr(m, "analytics_frame", None):
        frame = m.analytics_frame
        frame_total_its = _float(frame.get("total_it_s", frame.get("raw_it_s", frame.get("avg_its", 0))), 0)
        frame_last_its = _float(frame.get("last_its", frame_total_its), frame_total_its)
        frame_avg_its = _float(frame.get("avg_its", frame_total_its), frame_total_its)
        if frame_total_its >= 0:
            m.avg_its = frame_avg_its
            m.last_its = frame_last_its

    return m

def bucket(scores, lo, hi=None):
    if hi is None:
        return sum(1 for s in scores if s >= lo)
    return sum(1 for s in scores if lo <= s <= hi)
