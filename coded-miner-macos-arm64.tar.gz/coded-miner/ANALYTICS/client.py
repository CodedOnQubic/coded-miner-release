#!/usr/bin/env python3
import json
import urllib.request

# M1091V12_ANALYTICS_CLIENT_NORMALIZE
try:
    from .v11_mapping import normalize_payload_for_upload as _m1091v12_normalize_payload_for_upload
except Exception:
    try:
        from v11_mapping import normalize_payload_for_upload as _m1091v12_normalize_payload_for_upload
    except Exception:
        def _m1091v12_normalize_payload_for_upload(endpoint, payload):
            return payload


def post_json(api, path, payload):
    # M1091V12B_APPLY_ANALYTICS_FIELD_MAPPING
    payload = _m1091v12_normalize_payload_for_upload(path, payload)
    data = json.dumps(payload, separators=(",", ":"), allow_nan=False).encode()
    req = urllib.request.Request(api.rstrip("/") + path, data=data, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            return r.getcode(), r.read().decode("utf-8", errors="ignore")[:600]
    except Exception as e:
        return 0, str(e)[:600]
