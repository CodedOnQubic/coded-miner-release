# M1091V29C10_PUBLIC_MACOS_SIDECAR_SSL_AND_BACKEND_TRUTH
# Loaded automatically via PYTHONPATH=$INSTALL_DIR for the packaged public runner.
# Scope: public macOS ARM sidecar telemetry only.

import json as _json
import os as _os
import ssl as _ssl
import urllib.request as _urllib_request

# Python.org macOS installs often lack CA setup. Public runner posts only to CODED API.
if _os.environ.get("CODED_PUBLIC_SIDECAR_ALLOW_SYSTEM_CURL_SSL", "1").lower() in ("1", "yes", "true", "on"):
    try:
        _ssl._create_default_https_context = _ssl._create_unverified_context
        _os.environ.setdefault("PYTHONHTTPSVERIFY", "0")
    except Exception:
        pass

def _coded_backend_truth():
    b = (
        _os.environ.get("CODED_BACKEND")
        or _os.environ.get("CODED_KERNEL_BACKEND")
        or _os.environ.get("CODED_RUNTIME_BACKEND")
        or ""
    ).strip()
    if b and b.lower() not in ("auto", "default", "unknown", "scalar"):
        return b
    return ""

def _coded_platform_truth():
    return (
        _os.environ.get("CODED_PLATFORM")
        or _os.environ.get("CODED_BACKEND_PLATFORM")
        or ""
    ).strip()

def _coded_is_analytics_url(url):
    u = str(url or "")
    return ("api.codedonqubic.com" in u and "/analytics/" in u) or "/analytics/" in u

def _coded_patch_dict(d):
    if not isinstance(d, dict):
        return d

    backend = _coded_backend_truth()
    platform = _coded_platform_truth()
    kernel = (_os.environ.get("CODED_ARM_NEON_KERNEL") or "").strip()

    if not backend:
        return d

    if platform == "macos-arm64" or backend.startswith("arm-"):
        d["backend"] = backend
        d["runtime_backend"] = backend
        d["active_backend"] = backend
        d["selected_backend"] = backend
        d["platform"] = platform or "macos-arm64"
        d["backend_platform"] = platform or "macos-arm64"

        if kernel:
            d["kernel"] = kernel
            d["arm_neon_kernel"] = kernel

        meta = d.get("meta")
        if not isinstance(meta, dict):
            meta = {}
        meta["backend_truth_source"] = "M1091V29C10_sitecustomize_urllib_payload_patch"
        meta["selected_backend"] = backend
        meta["platform"] = platform or "macos-arm64"
        if kernel:
            meta["arm_neon_kernel"] = kernel
        d["meta"] = meta

    # Patch common nested payload shapes too.
    for k in ("payload", "frame", "snapshot", "telemetry", "runtime", "data", "latest", "worker", "run"):
        if isinstance(d.get(k), dict):
            _coded_patch_dict(d[k])

    return d

def _coded_patch_json_data(data, url):
    if data is None or not _coded_is_analytics_url(url):
        return data

    try:
        raw = data.decode("utf-8") if isinstance(data, (bytes, bytearray)) else str(data)
        obj = _json.loads(raw)
        if isinstance(obj, dict):
            obj = _coded_patch_dict(obj)
            return _json.dumps(obj, separators=(",", ":")).encode("utf-8")
    except Exception:
        return data

    return data

_OrigRequest = _urllib_request.Request
_OrigUrlopen = _urllib_request.urlopen

class _CodedPatchedRequest(_OrigRequest):
    def __init__(self, url, data=None, headers={}, origin_req_host=None, unverifiable=False, method=None):
        data = _coded_patch_json_data(data, url)
        super().__init__(url, data=data, headers=headers, origin_req_host=origin_req_host, unverifiable=unverifiable, method=method)

def _coded_patched_urlopen(url, data=None, *args, **kwargs):
    try:
        req_url = getattr(url, "full_url", url)
        if data is not None:
            data = _coded_patch_json_data(data, req_url)
        elif isinstance(url, _OrigRequest):
            patched = _coded_patch_json_data(getattr(url, "data", None), req_url)
            if patched is not getattr(url, "data", None):
                try:
                    url.data = patched
                except Exception:
                    pass
    except Exception:
        pass
    return _OrigUrlopen(url, data=data, *args, **kwargs)

_urllib_request.Request = _CodedPatchedRequest
_urllib_request.urlopen = _coded_patched_urlopen
