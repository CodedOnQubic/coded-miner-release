#!/usr/bin/env python3
# M1091V43Q_PY_RELEASE_STATUS_POST_FROM_MANIFEST
def _coded_report_release_status_v43q():
    try:
        import json
        import os
        import socket
        import urllib.request
        from pathlib import Path

        here = Path(__file__).resolve()
        base = here.parent

        candidates = [
            base / "release_manifest.json",
            base.parent / "release_manifest.json",
            base / "coded-miner" / "release_manifest.json",
            Path.cwd() / "release_manifest.json",
            Path.cwd() / "coded-miner" / "release_manifest.json",
        ]

        manifest_path = None
        for c in candidates:
            if c.exists():
                manifest_path = c
                break

        if manifest_path is None:
            return

        try:
            manifest = json.loads(manifest_path.read_text())
        except Exception:
            return

        commit = str(manifest.get("source_commit") or manifest.get("commit") or "").strip().lower()
        version = str(manifest.get("asset_version") or manifest.get("version") or "").strip()
        backend = str(manifest.get("backend") or manifest.get("platform") or os.environ.get("CODED_BACKEND") or "unknown").strip()

        if not commit or len(commit) < 7:
            return

        worker = (
            os.environ.get("CODED_WORKER_NAME")
            or os.environ.get("WORKER_NAME")
            or os.environ.get("RIG_NAME")
            or os.environ.get("HIVE_WORKER_NAME")
            or ""
        )

        if not worker:
            parts = list(here.parts)
            # Detect ~/.coded-miner/public/<worker>/latest/...
            if "public" in parts:
                i = parts.index("public")
                if i + 1 < len(parts):
                    worker = parts[i + 1]

        if not worker:
            worker = socket.gethostname() or "unknown"

        pool_api = (
            os.environ.get("CODED_POOL_API_URL")
            or os.environ.get("POOL_API_URL")
            or "http://178.104.150.57:4000"
        ).rstrip("/")

        payload = json.dumps({
            "worker_name": worker,
            "rig_id": os.environ.get("RIG_ID") or os.environ.get("HIVE_RIG_ID") or worker,
            "backend": backend,
            "commit": commit,
            "version": version,
        }).encode("utf-8")

        req = urllib.request.Request(
            pool_api + "/api/miner/release-status",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        urllib.request.urlopen(req, timeout=6).read()
    except Exception:
        pass

_coded_report_release_status_v43q()
# M1091U2_ANALYTICS_COMPONENT
# Compatibility wrapper. Real logic lives in ANALYTICS/.
from ANALYTICS.main import main

if __name__ == "__main__":
    main()
