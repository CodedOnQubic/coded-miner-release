#!/usr/bin/env bash
# M10.99Z59D_CLEAN_HIVE_PACKAGING_BLOCK
# Hive custom miner entrypoint shim. Hive calls this file; it delegates to start.sh.
set -euo pipefail
cd "$(dirname "$0")"
exec bash ./start.sh
