#!/usr/bin/env bash

# M1091L_CANONICAL_HIVE_DEFAULTS_AND_AUTO_UPDATE
# Canonical Hive Fleet default profile resolver.
# Default/fallback/restore paths must converge here. Experiments may still override via command env.
m1091l_default_worker_for_rig() {
  local rig="${1:-${RIG_ID:-${CODED_RIG_ID:-$(hostname)}}}"
  case "$rig" in
    Rig1X3D*) echo "Rig1X3D_M1091B_REAL321_T508_DENSITY" ;;
    Rig2X3D*) echo "Rig2X3D_M1091B_REAL321_T509_BIAS_BREAK" ;;
    Rig3X*)   echo "Rig3X_M1091B_REAL321_T509_BROAD" ;;
    Rig4X*)   echo "Rig4X_M1091B_REAL321_T510_BALANCED" ;;
    Rig5X3D*) echo "Rig5X3D_M1091B_REAL321_T509_X3D" ;;
    Rig6X3D*) echo "Rig6X3D_M1091B_REAL321_T510_BALANCED" ;;
    *)        echo "${rig}_DEFAULT_ANALYTICS" ;;
  esac
}

m1091l_default_threshold_for_rig() {
  local rig="${1:-${RIG_ID:-${CODED_RIG_ID:-$(hostname)}}}"
  case "$rig" in
    Rig1X3D*) echo "508" ;;
    Rig2X3D*) echo "509" ;;
    Rig3X*)   echo "509" ;;
    Rig4X*)   echo "510" ;;
    Rig5X3D*) echo "509" ;;
    Rig6X3D*) echo "510" ;;
    *)        echo "${CODED_DEFAULT_THRESHOLD:-510}" ;;
  esac
}

m1091l_default_router_for_threshold() {
  local t="${1:-510}"
  case "$t" in
    508) echo "M1091D_T508_DENSITY" ;;
    509) echo "M1091D_T509_DISCOVERY" ;;
    510) echo "M1091D_T510_CURRENT" ;;
    *)   echo "M1091D_T510_CURRENT" ;;
  esac
}

m1091l_default_matrix_for_threshold() {
  local t="${1:-510}"
  case "$t" in
    508) echo "p0_511_100,p1_508_35,p2_509_25,p3_lt508_2" ;;
    509) echo "p0_511_100,p1_509_25,p2_510_35,p3_lt509_3" ;;
    510) echo "p0_511_100,p1_509_20,p2_510_30,p3_lt509_2" ;;
    *)   echo "p0_511_100,p1_509_20,p2_510_30,p3_lt509_2" ;;
  esac
}

m1091l_apply_canonical_default_profile() {
  local raw="${RIG_ID:-${CODED_RIG_ID:-$(hostname)}}"
  local rig="$raw"

  case "$raw" in
    Rig1X3D*) rig="Rig1X3D" ;;
    Rig2X3D*) rig="Rig2X3D" ;;
    Rig3X*)   rig="Rig3X" ;;
    Rig4X*)   rig="Rig4X" ;;
    Rig5X3D*) rig="Rig5X3D" ;;
    Rig6X3D*) rig="Rig6X3D" ;;
  esac

  local worker
  local threshold
  local router
  local matrix

  worker="$(m1091l_default_worker_for_rig "$rig")"
  threshold="$(m1091l_default_threshold_for_rig "$rig")"
  router="$(m1091l_default_router_for_threshold "$threshold")"
  matrix="$(m1091l_default_matrix_for_threshold "$threshold")"

  export RIG_ID="$rig"
  export CODED_RIG_ID="$rig"

  export WORKER_NAME="$worker"
  export CODED_WORKER_NAME="$worker"
  export RUN_WORKER="$worker"
  export COMMAND_WORKER_NAME="$worker"
  export CODED_COMMAND_WORKER_NAME="$worker"

  export THRESHOLD="$threshold"
  export COMMAND_THRESHOLD="$threshold"
  export CODED_FAST_SHADOW_THRESHOLD="$threshold"

  export CODED_PRIORITY_BUDGET_ROUTER="$router"
  export CODED_PRIORITY_BUDGET_MATRIX="$matrix"
  export CODED_ROUTER_MATRIX="$matrix"

  export CODED_ANALYTICS="YES"
  export CODED_THREADS="${CODED_THREADS:-24}"
  export COMMAND_THREADS="${COMMAND_THREADS:-24}"
  export CODED_SAFE_THREADS="${CODED_SAFE_THREADS:-24}"
  export CODED_FORCE_FULLSCORE="1"
  export CODED_FULLSCORE_ALL_BACKENDS="1"
  export CODED_PREFILTER_DIFFICULTY="0"
  export CODED_KERNEL_BACKEND="avx512"
  export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
  export CODED_KERNEL_ALLOW_FALLBACK="${CODED_KERNEL_ALLOW_FALLBACK:-1}"
  export CODED_FAST_SHADOW_GATE="1"
  export CODED_SHADOW_AVX512_LIVE="1"
  export CODED_HI_TIMING="1"
  export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-500}"
  export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"
  export CODED_ENABLE_DETAIL_UPLOAD="${CODED_ENABLE_DETAIL_UPLOAD:-1}"
  export CODED_ENABLE_SHADOW_UPLOAD="${CODED_ENABLE_SHADOW_UPLOAD:-1}"
  export CODED_ENABLE_PERFORMANCE_UPLOAD="${CODED_ENABLE_PERFORMANCE_UPLOAD:-1}"
  export CODED_ENABLE_PRIORITY_BUDGET_UPLOAD="${CODED_ENABLE_PRIORITY_BUDGET_UPLOAD:-1}"
  export CODED_ENABLE_SCORE_DISTRIBUTION_UPLOAD="${CODED_ENABLE_SCORE_DISTRIBUTION_UPLOAD:-1}"

  echo "[M1091L_CANONICAL_DEFAULT_PROFILE] rig=${RIG_ID:-unset} worker=${WORKER_NAME:-unset} threshold=${CODED_FAST_SHADOW_THRESHOLD:-unset} router=${CODED_PRIORITY_BUDGET_ROUTER:-unset} matrix=${CODED_PRIORITY_BUDGET_MATRIX:-unset} threads=${CODED_THREADS:-unset}"
}
# /M1091L_CANONICAL_HIVE_DEFAULTS_AND_AUTO_UPDATE


# M10.99Z233_RESTORE_SCORE_DISTRIBUTION_UPLOADER
# Canonical analytics endpoints:
# - Root routes: /analytics/runs/start, /analytics/runs/heartbeat, /analytics/performance-snapshot
# - Legacy score uploader expects CODED_API + /score-distribution, so CODED_API must include /analytics.
CODED_POOL_API_URL="${CODED_POOL_API_URL:-${POOL_API_URL:-http://178.104.150.57:4000}}"
POOL_API_URL="${POOL_API_URL:-$CODED_POOL_API_URL}"
CODED_API_ROOT="${CODED_API_ROOT:-${CODED_API:-${API:-http://178.104.150.57:4000/analytics}}}"
CODED_API="${CODED_API:-$CODED_API_ROOT}"
API="${API:-$CODED_API_ROOT}"
export CODED_POOL_API_URL POOL_API_URL CODED_API_ROOT CODED_API API
echo "[M10.99Z233_RESTORE_SCORE_DISTRIBUTION_UPLOADER] pool_api=$CODED_POOL_API_URL analytics_api=$CODED_API_ROOT"


# M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER
# Always-on default fleet command polling. This must run alongside normal mining.
# It restores Restore Default / Experiment command pickup after pool-api compact rewrites.
coded_z212_json_get() {
  local key="$1"
  node -e '
    const fs=require("fs");
    const key=process.argv[1];
    const input=fs.readFileSync(0,"utf8");
    try {
      const j=JSON.parse(input || "{}");
      const c=j.command || j.data?.command || j;
      const v=key.split(".").reduce((a,k)=>a&&a[k], c);
      if (v !== undefined && v !== null) process.stdout.write(String(v));
    } catch(e) {}
  ' "$key"
}

coded_z212_apply_env_from_command() {
  local cmd_json="$1"
  local env_json
  env_json="$(printf '%s' "$cmd_json" | node -e '
    const fs=require("fs");
    const input=fs.readFileSync(0,"utf8");
    try {
      const j=JSON.parse(input || "{}");
      const c=j.command || j.data?.command || j;
      const p=c.params || {};
      const env=p.env || {};
      for (const [k,v] of Object.entries(env)) {
        if (/^[A-Z0-9_]+$/.test(k) && v !== undefined && v !== null) {
          console.log(`export ${k}=${JSON.stringify(String(v))}`);
        }
      }
      for (const k of [
        "worker_name","worker","threshold","threads",
        "CODED_THREADS","COMMAND_THREADS","CODED_START_RUN_HANDOFF",
        "CODED_FAST_SHADOW_THRESHOLD","CODED_KERNEL_BACKEND"
      ]) {
        if (p[k] !== undefined && p[k] !== null) {
          const out = {
            worker_name: "WORKER_NAME",
            worker: "WORKER_NAME",
            threshold: "CODED_FAST_SHADOW_THRESHOLD",
            threads: "CODED_THREADS",
            CODED_THREADS: "CODED_THREADS",
            COMMAND_THREADS: "COMMAND_THREADS",
            CODED_START_RUN_HANDOFF: "CODED_START_RUN_HANDOFF",
            CODED_FAST_SHADOW_THRESHOLD: "CODED_FAST_SHADOW_THRESHOLD",
            CODED_KERNEL_BACKEND: "CODED_KERNEL_BACKEND"
          }[k];
          if (out) console.log(`export ${out}=${JSON.stringify(String(p[k]))}`);
        }
      }
    } catch(e) {}
  ')"

  if [ -n "$env_json" ]; then
    eval "$env_json"
  fi

  export CODED_ANALYTICS="${CODED_ANALYTICS:-YES}"
  export CODED_FORCE_FULLSCORE="${CODED_FORCE_FULLSCORE:-1}"
  export CODED_FULLSCORE_ALL_BACKENDS="${CODED_FULLSCORE_ALL_BACKENDS:-1}"
  export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
  export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"

  echo "[M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER] applied_env worker=${WORKER_NAME:-unset} threshold=${CODED_FAST_SHADOW_THRESHOLD:-unset} threads=${CODED_THREADS:-unset} backend=${CODED_KERNEL_BACKEND:-unset}"
}

coded_z212_post_json() {
  local url="$1"
  local json="$2"
  curl -fsS -m 10 -X POST "$url" \
    -H "Content-Type: application/json" \
    -d "$json" >/dev/null 2>&1 || true
}

coded_z212_handle_start_run() {
  local api="$1"
  local rig="$2"
  local cmd_json="$3"

  local cid worker threshold threads marker
  cid="$(printf '%s' "$cmd_json" | coded_z212_json_get "command_id")"
  worker="$(printf '%s' "$cmd_json" | coded_z212_json_get "params.worker_name")"
  [ -z "$worker" ] && worker="$(printf '%s' "$cmd_json" | coded_z212_json_get "params.worker")"
  threshold="$(printf '%s' "$cmd_json" | coded_z212_json_get "params.threshold")"
  threads="$(printf '%s' "$cmd_json" | coded_z212_json_get "params.threads")"
  marker="$(printf '%s' "$cmd_json" | coded_z212_json_get "params.marker")"

  [ -z "$cid" ] && return 0

  echo "[M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER] start_run picked cid=${cid} rig=${rig} worker=${worker} threshold=${threshold} threads=${threads} marker=${marker}"

  coded_z212_post_json "$api/commands/$cid/running" "{\"marker\":\"M10.99Z212_COMMAND_RUNNING\",\"rig_id\":\"$rig\",\"lease_minutes\":15}"

  coded_z212_apply_env_from_command "$cmd_json"

  # Z173/Z191 hard handoff path if available.
  if command -v coded_z191_start_run_post_override_handoff >/dev/null 2>&1; then
    coded_z191_start_run_post_override_handoff "M10.99Z212_after_command_pickup" || true
  fi

  # Kill old miner processes only when hard handoff requested.
  local hard kill replace
  hard="$(printf '%s' "$cmd_json" | coded_z212_json_get "params.hard_runtime_handoff")"
  kill="$(printf '%s' "$cmd_json" | coded_z212_json_get "params.kill_existing_miner")"
  replace="$(printf '%s' "$cmd_json" | coded_z212_json_get "params.replace_existing_runtime")"

  if [ "$hard" = "true" ] || [ "$kill" = "true" ] || [ "$replace" = "true" ]; then
    echo "[M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER] hard_handoff_kill_old_miner"
    pkill -f "coded-miner|qubic-miner|./qli-client|./qli-Service" 2>/dev/null || true
    sleep 2
  fi

  coded_z212_post_json "$api/commands/$cid/complete" "{\"marker\":\"M10.99Z212_COMMAND_COMPLETED_AFTER_HANDOFF\",\"rig_id\":\"$rig\",\"worker_name\":\"${WORKER_NAME:-$worker}\",\"threshold\":\"${CODED_FAST_SHADOW_THRESHOLD:-$threshold}\",\"threads\":\"${CODED_THREADS:-$threads}\"}"

  echo "[M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER] command_complete cid=${cid}"
}

coded_z212_command_poll_once() {
  local api="${CODED_POOL_API_URL:-${POOL_API_URL:-${API:-http://178.104.150.57:4000}}}"
  local rig="${CODED_RIG_ID:-${RIG_ID:-${WORKER_NAME:-$(hostname)}}}"

  [ -z "$rig" ] && return 0

  local resp ok cid ctype
  resp="$(curl -fsS -m 10 "$api/analytics/commands/next/$rig" 2>/dev/null || true)"
  [ -z "$resp" ] && return 0

  ok="$(printf '%s' "$resp" | node -e 'let s="";process.stdin.on("data",d=>s+=d);process.stdin.on("end",()=>{try{const j=JSON.parse(s);process.stdout.write(String(j.ok===true))}catch(e){}})')"
  [ "$ok" != "true" ] && return 0

  cid="$(printf '%s' "$resp" | coded_z212_json_get "command_id")"
  [ -z "$cid" ] && return 0

  ctype="$(printf '%s' "$resp" | coded_z212_json_get "command_type")"
  echo "[M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER] picked command cid=${cid} type=${ctype} rig=${rig}"

  case "$ctype" in
    start_run)
      coded_z212_handle_start_run "$api" "$rig" "$resp"
      ;;
    stop_run)
      echo "[M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER] stop_run cid=${cid}"
      pkill -f "coded-miner|qubic-miner|./qli-client|./qli-Service" 2>/dev/null || true
      coded_z212_post_json "$api/commands/$cid/complete" "{\"marker\":\"M10.99Z212_STOP_RUN_COMPLETED\",\"rig_id\":\"$rig\"}"
      ;;
    *)
      echo "[M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER] unsupported command type=${ctype} cid=${cid}"
      coded_z212_post_json "$api/commands/$cid/fail" "{\"marker\":\"M10.99Z212_UNSUPPORTED_COMMAND\",\"rig_id\":\"$rig\",\"error\":\"unsupported command type $ctype\"}"
      ;;
  esac
}

coded_z212_command_poll_loop() {
  local sec="${CODED_COMMAND_POLL_SEC:-10}"
  echo "[M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER] loop_start rig=${CODED_RIG_ID:-${RIG_ID:-${WORKER_NAME:-$(hostname)}}} sec=${sec} api=${CODED_POOL_API_URL:-${POOL_API_URL:-${API:-http://178.104.150.57:4000}}}"

  while true; do
    coded_z212_command_poll_once || true
    sleep "$sec"
  done
}

coded_z212_start_command_poller() {
  if [ "${CODED_DISABLE_COMMAND_POLLER:-0}" = "1" ]; then
    echo "[M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER] disabled"
    return 0
  fi

  if [ "${CODED_ANALYTICS:-YES}" != "YES" ] && [ "${CODED_FLEET_MODE:-0}" != "1" ]; then
    echo "[M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER] skip analytics=${CODED_ANALYTICS:-unset} fleet=${CODED_FLEET_MODE:-unset}"
    return 0
  fi

  if [ -n "${CODED_Z212_POLLER_STARTED:-}" ]; then
    return 0
  fi
  export CODED_Z212_POLLER_STARTED=1

  coded_z212_command_poll_loop &
  export CODED_Z212_POLLER_PID="$!"
  echo "[M10.99Z212_ALWAYS_ON_FLEET_COMMAND_POLLER] started pid=${CODED_Z212_POLLER_PID}"
}

coded_z212_start_command_poller || true


# M10.99Z191_POST_OVERRIDE_START_RUN_RUNTIME_HANDOFF
coded_z191_start_run_post_override_handoff() {
  local reason="${1:-post_override_start_run}"
  local desired_worker="${WORKER_NAME:-${COMMAND_WORKER_NAME:-${CODED_WORKER_NAME:-${RUN_WORKER:-}}}}"
  local desired_threshold="${CODED_FAST_SHADOW_THRESHOLD:-${COMMAND_THRESHOLD:-${THRESHOLD:-}}}"
  local handoff="${CODED_START_RUN_HANDOFF:-${COMMAND_START_RUN_HANDOFF:-}}"

  # Only hard-handoff explicit start_run commands. Do not affect normal local default boot.
  if [ "$handoff" != "M10.99Z173" ] && [ "${force_runtime_handoff:-}" != "true" ] && [ "${FORCE_RUNTIME_HANDOFF:-}" != "true" ]; then
    return 0
  fi

  if [ -z "$desired_worker" ]; then
    echo "[M10.99Z191_POST_OVERRIDE_START_RUN_RUNTIME_HANDOFF] skip reason=no_desired_worker handoff=${handoff}"
    return 0
  fi

  echo "[M10.99Z191_POST_OVERRIDE_START_RUN_RUNTIME_HANDOFF] begin reason=${reason} worker=${desired_worker} threshold=${desired_threshold} handoff=${handoff}"

  # Kill miner binaries/processes, but never kill wrapper/agent/control scripts.
  for sig in TERM KILL; do
    ps -eo pid=,args= | while read -r pid args; do
      case "$args" in
        *coded-miner*--worker*|*coded-miner*" --pool "*|*"./coded-miner "*|*" coded-miner "*)
          case "$args" in
            *start.sh*|*h-run.sh*|*grep*|*awk*|*sed*|*node*|*curl*|*bash*"-lc"*) ;;
            *)
              echo "[M10.99Z191_POST_OVERRIDE_START_RUN_RUNTIME_HANDOFF] kill_${sig} pid=${pid} args=${args}"
              kill -s "$sig" "$pid" 2>/dev/null || true
              ;;
          esac
          ;;
      esac
    done
    sleep 1
  done

  export WORKER_NAME="$desired_worker"
  export COMMAND_WORKER_NAME="$desired_worker"
  export CODED_WORKER_NAME="$desired_worker"
  export RUN_WORKER="$desired_worker"

  if [ -n "$desired_threshold" ]; then
    export CODED_FAST_SHADOW_THRESHOLD="$desired_threshold"
    export COMMAND_THRESHOLD="$desired_threshold"
    export THRESHOLD="$desired_threshold"
  fi

  export CODED_START_RUN_HANDOFF="M10.99Z173"
  export CODED_ANALYTICS="${CODED_ANALYTICS:-YES}"

  echo "[M10.99Z191_POST_OVERRIDE_START_RUN_RUNTIME_HANDOFF] env_applied worker=${WORKER_NAME} threshold=${CODED_FAST_SHADOW_THRESHOLD:-unset} threads=${CODED_THREADS:-unset}"
}


# M10.99Z173_START_RUN_HARD_RUNTIME_HANDOFF
coded_z173_hard_stop_runtime_before_start_run() {
  local reason="${1:-start_run}"
  echo "[M10.99Z173_START_RUN_HARD_RUNTIME_HANDOFF] begin reason=${reason} desired_worker=${WORKER_NAME:-${COMMAND_WORKER_NAME:-unset}} threshold=${CODED_FAST_SHADOW_THRESHOLD:-${COMMAND_THRESHOLD:-unset}}"

  # Stop existing miner runtime. Do not kill wrapper scripts.
  for sig in TERM KILL; do
    ps -eo pid=,args= | while read -r pid args; do
      case "$args" in
        *coded-miner*--worker*|*coded-miner*" --pool "*|*"./coded-miner "*)
          case "$args" in
            *start.sh*|*h-run.sh*|*grep*|*awk*|*sed*|*node*|*curl*) ;;
            *)
              echo "[M10.99Z173_START_RUN_HARD_RUNTIME_HANDOFF] ${sig} pid=${pid} args=${args}"
              kill -s "$sig" "$pid" 2>/dev/null || true
              ;;
          esac
          ;;
      esac
    done
    [ "$sig" = "TERM" ] && sleep 2
  done

  export CODED_START_RUN_HANDOFF="M10.99Z173"
  export CODED_DISABLE_LOCAL_DEFAULT_DURING_COMMAND="1"

  if [ -n "${COMMAND_WORKER_NAME:-}" ]; then export WORKER_NAME="$COMMAND_WORKER_NAME"; fi
  if [ -n "${COMMAND_THRESHOLD:-}" ]; then export CODED_FAST_SHADOW_THRESHOLD="$COMMAND_THRESHOLD"; fi
  if [ -n "${COMMAND_THREADS:-}" ]; then export CODED_THREADS="$COMMAND_THREADS"; fi

  echo "[M10.99Z173_START_RUN_HARD_RUNTIME_HANDOFF] done worker=${WORKER_NAME:-unset} threshold=${CODED_FAST_SHADOW_THRESHOLD:-unset} threads=${CODED_THREADS:-unset}"
}


# M10.99Z120_DISABLE_DEFAULT_START_RUN_ENQUEUE
# Safety default: default analytics must be started locally by HiveOS wrapper.
# Do not enqueue default start_run commands from the miner itself.
export CODED_DISABLE_DEFAULT_START_RUN_ENQUEUE="${CODED_DISABLE_DEFAULT_START_RUN_ENQUEUE:-1}"  # M10.99Z120_DISABLE_DEFAULT_START_RUN_ENQUEUE

# M10.99Z126_NARROW_DEFAULT_ENQUEUE_GUARD
# Keep local default/canonical worker logic alive, but block only pool-side
# default start_run enqueue calls. Experiment/build/release commands remain allowed.
coded_default_start_run_enqueue_disabled() {
  [ "${CODED_DISABLE_DEFAULT_START_RUN_ENQUEUE:-1}" = "1" ]
}

coded_skip_default_start_run_enqueue() {
  local reason="${1:-default_start_run_enqueue_disabled}"
  if coded_default_start_run_enqueue_disabled; then

  # M10.99Z173_START_RUN_HARD_RUNTIME_HANDOFF_CALL
  coded_z173_hard_stop_runtime_before_start_run "start_run_command"
    echo "[M10.99Z126_NARROW_DEFAULT_ENQUEUE_GUARD] skip default start_run enqueue reason=$reason; local default runtime remains active"
    return 0
  fi
  return 1
}

# M10.99Z127_HIVE_RIG_ALIAS_CANONICAL_DEFAULT
# HiveOS may pass worker names like Rig_5_X3D or numeric farm IDs.
# Canonical analytics/default profile logic must use logical rig IDs.
coded_canonical_rig_id() {
  local raw="${1:-${RIG_ID:-${WORKER_NAME:-${workerName:-}}}}"
  case "$raw" in
    Rig1X3D|Rig1X3D_*|Rig_1_X3D|10416307|10416307_*) echo "Rig1X3D" ;;
    Rig2X3D|Rig2X3D_*|Rig_2_X3D|10416308|10416308_*) echo "Rig2X3D" ;;
    Rig3X|Rig3X_*|Rig_3_X|10416309|10416309_*) echo "Rig3X" ;;
    Rig4X|Rig4X_*|Rig_4_X|10416310|10416310_*) echo "Rig4X" ;;
    Rig5X3D|Rig5X3D_*|Rig_5_X3D|10416311|10416311_*) echo "Rig5X3D" ;;
    Rig6X3D|Rig6X3D_*|Rig_6_X3D|10416315|10416315_*) echo "Rig6X3D" ;;
    *) echo "$raw" ;;
  esac
}

coded_apply_canonical_rig_id() {
  local canonical
  canonical="$(coded_canonical_rig_id "${RIG_ID:-${WORKER_NAME:-${workerName:-}}}")"
  if [ -n "$canonical" ] && [ "$canonical" != "${RIG_ID:-}" ]; then
    echo "[M10.99Z127_HIVE_RIG_ALIAS_CANONICAL_DEFAULT] canonicalize rig_id raw=${RIG_ID:-unset}/${WORKER_NAME:-unset} canonical=$canonical"
    export RIG_ID="$canonical"
  fi
}


# M10.99Z108_HIVE_FLIGHTSHEET_DEFAULT_JOIN
# Default analytics must be sourced from HiveOS Flight Sheet, not from pool start_run.
# Precedence:
# 1) explicit command params/env for experiment/build/start_run
# 2) Hive Flight Sheet WORKER_NAME / CUSTOM_TEMPLATE
# 3) custom config.json worker/workerName
# 4) canonical fallback by rig_id


# ============================================================


# M10.99Z216_RESPECT_SAFE_THREAD_ENV
# Safe thermal thread priority for all default analytics joins:
# COMMAND_THREADS > CODED_THREADS > THREADS > CODED_SAFE_THREADS > 24
coded_z216_resolve_safe_threads() {
  local chosen=""
  if [ -n "${COMMAND_THREADS:-}" ]; then
    chosen="$COMMAND_THREADS"
  elif [ -n "${CODED_THREADS:-}" ]; then
    chosen="$CODED_THREADS"
  elif [ -n "${THREADS:-}" ]; then
    chosen="$THREADS"
  elif [ -n "${CODED_SAFE_THREADS:-}" ]; then
    chosen="$CODED_SAFE_THREADS"
  else
    chosen="24"
  fi

  case "$chosen" in
    ''|*[!0-9]*)
      chosen="24"
      ;;
  esac

  # Thermal safety clamp for Hive defaults. Experiments may still pass lower values,
  # but default analytics must never silently jump back to 31.
  if [ "$chosen" -gt 28 ]; then
    chosen="24"
  fi

  export THREADS="$chosen"
  export CODED_THREADS="$chosen"
  export COMMAND_THREADS="$chosen"
  export CODED_SAFE_THREADS="${CODED_SAFE_THREADS:-24}"
}

# M10.99Z119_SELF_HEALING_DEFAULT_ANALYTICS_JOIN
# ------------------------------------------------------------
# Contract:
# - CODED_ANALYTICS=YES means this HiveOS miner joins the fleet.
# - If no experiment/build/release command is actively controlling runtime,
#   the wrapper must force the known default analytics worker for this rig.
# - Never use HiveOS numeric worker ids like 10416315_Z25... as fleet default.
# - Command layer is
# M10.99Z127_HIVE_RIG_ALIAS_CANONICAL_DEFAULT_APPLY
coded_apply_canonical_rig_id || true
# M10.99Z127_SYNTAX_REPAIR: for temporary actions only. Default runtime is local.
# ============================================================

coded_z119_norm() {
  echo "${1:-}" | tr '[:upper:]' '[:lower:]' | tr -d ' _-'
}

coded_z119_detect_logical_rig() {
  local candidates=""
  candidates="$candidates ${CODED_RIG_ID:-}"
  candidates="$candidates ${RIG_ID:-}"
  candidates="$candidates ${rig_id:-}"
  candidates="$candidates ${HOSTNAME:-}"
  candidates="$candidates $(hostname -s 2>/dev/null || true)"
  candidates="$candidates $(grep -E '^WORKER_NAME=' /hive-config/rig.conf 2>/dev/null | tail -n1 | cut -d= -f2- | tr -d '"' || true)"
  candidates="$candidates $(grep -E '^CUSTOM_TEMPLATE=' /hive-config/wallet.conf 2>/dev/null | tail -n1 | cut -d= -f2- | tr -d '"' || true)"

  local c n
  for c in $candidates; do
    n="$(coded_z119_norm "$c")"

    case "$n" in
      *rig1x3d*|*rig1*) echo "Rig1X3D"; return 0 ;;
      *rig2x3d*|*rig2*) echo "Rig2X3D"; return 0 ;;
      *rig3x*|*rig3*) echo "Rig3X"; return 0 ;;
      *rig4x*|*rig4*) echo "Rig4X"; return 0 ;;
      *rig5x3d*|*rig5*) echo "Rig5X3D"; return 0 ;;
      *rig6x3d*|*rig6*) echo "Rig6X3D"; return 0 ;;

      # Known HiveOS worker ids observed in fleet. These are physical rig ids,
      # not valid CODED fleet worker names.
      *10416311*) echo "Rig5X3D"; return 0 ;;
      *10416315*) echo "Rig6X3D"; return 0 ;;
      *10381613*) echo "Rig4X"; return 0 ;;
      *10381558*) echo "Rig3X"; return 0 ;;
    esac
  done

  return 1
}

coded_z119_default_worker_for_rig() {
  case "${1:-}" in
    Rig1X3D) echo "Rig1X3D_M1091B_REAL321_T508_DENSITY" ;;
    Rig2X3D) echo "Rig2X3D_M1091B_REAL321_T509_BIAS_BREAK" ;;
    Rig3X)   echo "Rig3X_M1091B_REAL321_T509_BROAD" ;;
    Rig4X)   echo "Rig4X_M1091B_REAL321_T510_BALANCED" ;;
    Rig5X3D) echo "Rig5X3D_M1091B_REAL321_T509_X3D" ;;
    Rig6X3D) echo "Rig6X3D_M1091B_REAL321_T510_BALANCED" ;;
    *) return 1 ;;
  esac
}

coded_z119_default_threshold_for_worker() {
  case "${1:-}" in
    *T509*) echo "509" ;;
    *T510*) echo "510" ;;
    *T511*) echo "511" ;;
    *) echo "${CODED_FAST_SHADOW_THRESHOLD:-510}" ;;
  esac
}

coded_z119_is_temporary_command_context() {
  local blob="${COMMAND_TYPE:-} ${COMMAND_JSON:-} ${PARAMS:-} ${EXPERIMENT_ID:-} ${RUN_WORKER:-} ${WORKER_NAME:-}"

  echo "$blob" | grep -Eqi 'git_experiment_run|build_hive_release|build_release|release_update|stop_run|priority[": ]+experiment|source_command_type[": ]+git_experiment_run|profile_source[": ]+git_experiment_run_backend_handoff|Z86|AB_|CANARY|CONTROL'
}

coded_z119_apply_default_analytics_join() {
  # Only activate for fleet analytics mode.
  if [ "${CODED_ANALYTICS:-}" != "YES" ] && [ "${CODED_ANALYTICS:-}" != "yes" ] && [ "${CODED_ANALYTICS:-}" != "1" ]; then
    return 0
  fi

  # Experiments/build/release remain authoritative while active.
  if coded_z119_is_temporary_command_context; then
    echo "[M10.99Z119_SELF_HEALING_DEFAULT_ANALYTICS_JOIN] temporary command context detected; skip default override"
    return 0
  fi

  local rig worker threshold wallet cfg_dir
  rig="$(coded_z119_detect_logical_rig || true)"
  if [ -z "$rig" ]; then
    echo "[M10.99Z119_SELF_HEALING_DEFAULT_ANALYTICS_JOIN] logical rig unknown; keeping existing worker=${WORKER_NAME:-${RUN_WORKER:-unknown}}"
    return 0
  fi

  worker="$(coded_z119_default_worker_for_rig "$rig" || true)"
  if [ -z "$worker" ]; then
    echo "[M10.99Z119_SELF_HEALING_DEFAULT_ANALYTICS_JOIN] no default worker for rig=$rig"
    return 0
  fi

  threshold="$(coded_z119_default_threshold_for_worker "$worker")"
  wallet="${WALLET:-${wallet:-${CODED_WALLET:-EUELEOZEENRCEDYVEAZEBYVHQFABSUFFWTUWTFNSFALSTCNJLCDSEROGOSYI}}}"
  cfg_dir="/hive/miners/custom/coded-miner"

  export CODED_RIG_ID="$rig"
  export RIG_ID="$rig"
  export WORKER_NAME="$worker"
  export CODED_WORKER_NAME="$worker"
  export RUN_WORKER="$worker"
  export worker="$worker"
  export worker_name="$worker"

  export CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx512}"
  export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
  export CODED_PREFILTER_DIFFICULTY="0"
  export CODED_FAST_SHADOW_GATE="${CODED_FAST_SHADOW_GATE:-1}"
  export CODED_FAST_SHADOW_THRESHOLD="$threshold"
  export THRESHOLD="$threshold"
  export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-500}"
  export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"
  export CODED_SHADOW_AVX512_LIVE="${CODED_SHADOW_AVX512_LIVE:-1}"
  export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
  export CODED_KERNEL_ALLOW_FALLBACK="${CODED_KERNEL_ALLOW_FALLBACK:-1}"
  export CODED_PRIORITY_BUDGET_ROUTER="${CODED_PRIORITY_BUDGET_ROUTER:-$(m1091l_default_router_for_threshold "${CODED_FAST_SHADOW_THRESHOLD:-${THRESHOLD:-510}}")}"
  export CODED_ENABLE_DETAIL_UPLOAD="${CODED_ENABLE_DETAIL_UPLOAD:-1}"
  export CODED_ENABLE_SHADOW_UPLOAD="${CODED_ENABLE_SHADOW_UPLOAD:-1}"
  export CODED_ENABLE_PERFORMANCE_UPLOAD="${CODED_ENABLE_PERFORMANCE_UPLOAD:-1}"
  export CODED_ENABLE_PRIORITY_BUDGET_UPLOAD="${CODED_ENABLE_PRIORITY_BUDGET_UPLOAD:-1}"
  export CODED_ENABLE_SCORE_DISTRIBUTION_UPLOAD="${CODED_ENABLE_SCORE_DISTRIBUTION_UPLOAD:-1}"
  coded_z216_resolve_safe_threads
  export CODED_THREADS="$THREADS"

  # Keep Hive local config consistent, but do not fail runtime if FS is read-only.
  if [ -d /hive-config ]; then
    sed -i '/^WORKER_NAME=/d' /hive-config/rig.conf 2>/dev/null || true
    echo "WORKER_NAME=\"$worker\"" >> /hive-config/rig.conf 2>/dev/null || true

    sed -i '/^CUSTOM_TEMPLATE=/d' /hive-config/wallet.conf 2>/dev/null || true
    echo "CUSTOM_TEMPLATE=\"$wallet-$worker\"" >> /hive-config/wallet.conf 2>/dev/null || true
  fi

  if [ -d "$cfg_dir" ]; then
    cat > "$cfg_dir/config.json" 2>/dev/null <<EOF || true
{
  "pool": "pool.codedonqubic.com:7777",
  "wallet": "$wallet",
  "walletTemplate": "$wallet",
  "worker": "$worker",
  "workerName": "$worker",
  "threads": 31,
  "threshold": $threshold,
  "env": "CODED_ANALYTICS=YES CODED_FAST_SHADOW_THRESHOLD=$threshold CODED_PRIORITY_BUDGET_ROUTER=M1098E"
}
EOF
  fi

  echo "[M10.99Z119_SELF_HEALING_DEFAULT_ANALYTICS_JOIN] rig=$rig worker=$worker threshold=$threshold threads=${THREADS:-24} source=local_default_join"
}

# Apply early so HiveOS numeric worker ids cannot leak into default runtime.
coded_z119_apply_default_analytics_join || true

coded_z108_read_file_value() {
  local file="$1"
  local key="$2"
  [ -f "$file" ] || return 1
  grep -E "^${key}=" "$file" 2>/dev/null | tail -n 1 | sed -E 's/^[^=]+=//' | sed -E 's/^"//; s/"$//' || true
}

coded_z108_extract_worker_from_template() {
  local tpl="${1:-}"
  [ -n "$tpl" ] || return 1
  # Expected: WALLET-WORKER. Wallet is long uppercase Qubic id.
  echo "$tpl" | sed -E 's/^[A-Z]{40,}-//'
}

coded_z108_json_worker() {
  local cfg="${1:-/hive/miners/custom/coded-miner/config.json}"
  [ -f "$cfg" ] || return 1
  if command -v jq >/dev/null 2>&1; then
    jq -r '.worker_name // .workerName // .worker // empty' "$cfg" 2>/dev/null | head -n 1
  else
    grep -E '"(worker_name|workerName|worker)"[[:space:]]*:' "$cfg" 2>/dev/null | head -n 1 | sed -E 's/^.*:[[:space:]]*"([^"]+)".*$/\1/'
  fi
}

coded_z108_canonical_worker_for_rig() {
  local rig="${1:-${RIG_ID:-${CODED_RIG_ID:-unknown}}}"
  case "$rig" in
    Rig1X3D*) echo "Rig1X3D_M1091B_REAL321_T508_DENSITY" ;;
    Rig2X3D*) echo "Rig2X3D_M1091B_REAL321_T509_BIAS_BREAK" ;;
    Rig3X*)   echo "Rig3X_M1091B_REAL321_T509_BROAD" ;;
    Rig4X*)   echo "Rig4X_M1091B_REAL321_T510_BALANCED" ;;
    Rig5X3D*) echo "Rig5X3D_M1091B_REAL321_T509_X3D" ;;
    Rig6X3D*) echo "Rig6X3D_M1091B_REAL321_T510_BALANCED" ;;
    *) echo "${rig}_DEFAULT_ANALYTICS" ;;
  esac
}

coded_z108_default_threshold_for_worker() {
  local worker="${1:-}"
  case "$worker" in
    *T509*) echo "509" ;;
    *T510*) echo "510" ;;
    *T511*) echo "511" ;;
    *) echo "${CODED_FAST_SHADOW_THRESHOLD:-510}" ;;
  esac
}

coded_z108_apply_hive_flightsheet_default() {
  # Only default analytics fallback. Do not override explicit experiment/build/start_run command params.
  if [ "${CODED_ANALYTICS:-}" != "YES" ]; then
    return 0
  fi

  local fs_worker=""
  local template=""
  local json_worker=""
  local canonical=""
  local selected=""

  fs_worker="$(coded_z108_read_file_value /hive-config/rig.conf WORKER_NAME || true)"
  template="$(coded_z108_read_file_value /hive-config/wallet.conf CUSTOM_TEMPLATE || true)"
  [ -n "$fs_worker" ] || fs_worker="$(coded_z108_extract_worker_from_template "$template" || true)"
  json_worker="$(coded_z108_json_worker /hive/miners/custom/coded-miner/config.json || true)"
  canonical="$(coded_z108_canonical_worker_for_rig "${RIG_ID:-${CODED_RIG_ID:-}}")"

  selected="${WORKER_NAME:-${CODED_WORKER_NAME:-${worker_name:-${worker:-}}}}"
  [ -n "$selected" ] || selected="$fs_worker"
  [ -n "$selected" ] || selected="$json_worker"
  [ -n "$selected" ] || selected="$canonical"

  export WORKER_NAME="$selected"
  export CODED_WORKER_NAME="$selected"
  export worker="$selected"
  export worker_name="$selected"

  export CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx512}"
  export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
  export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
  export CODED_FAST_SHADOW_GATE="${CODED_FAST_SHADOW_GATE:-1}"
  export CODED_FAST_SHADOW_THRESHOLD="${CODED_FAST_SHADOW_THRESHOLD:-$(coded_z108_default_threshold_for_worker "$selected")}"
  export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-500}"
  export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"
  export CODED_SHADOW_AVX512_LIVE="${CODED_SHADOW_AVX512_LIVE:-1}"
  export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
  export CODED_KERNEL_ALLOW_FALLBACK="${CODED_KERNEL_ALLOW_FALLBACK:-1}"
  export CODED_PRIORITY_BUDGET_ROUTER="${CODED_PRIORITY_BUDGET_ROUTER:-$(m1091l_default_router_for_threshold "${CODED_FAST_SHADOW_THRESHOLD:-${THRESHOLD:-510}}")}"
  export CODED_ENABLE_DETAIL_UPLOAD="${CODED_ENABLE_DETAIL_UPLOAD:-1}"
  export CODED_ENABLE_SHADOW_UPLOAD="${CODED_ENABLE_SHADOW_UPLOAD:-1}"
  export CODED_ENABLE_PERFORMANCE_UPLOAD="${CODED_ENABLE_PERFORMANCE_UPLOAD:-1}"
  export CODED_ENABLE_PRIORITY_BUDGET_UPLOAD="${CODED_ENABLE_PRIORITY_BUDGET_UPLOAD:-1}"
  export CODED_ENABLE_SCORE_DISTRIBUTION_UPLOAD="${CODED_ENABLE_SCORE_DISTRIBUTION_UPLOAD:-1}"
  export CODED_API_ROOT="${CODED_API_ROOT:-http://178.104.150.57:4000/analytics}"

  m1091l_apply_canonical_default_profile
  echo "[M10.99Z108_HIVE_FLIGHTSHEET_DEFAULT_JOIN] rig=${RIG_ID:-${CODED_RIG_ID:-unknown}} worker=$WORKER_NAME threshold=$CODED_FAST_SHADOW_THRESHOLD source=flight_sheet_default"
}


# --- M10.99Z73_SAFE_WORKER_DEFAULTS ---
# Hive/Fleet scripts may run with nounset. Ensure lowercase worker aliases
# exist before command lifecycle / fallback code references them.
worker="${worker:-${WORKER:-${WORKER_NAME:-${RIG_ID:-unknown}}}}"
worker_name="${worker_name:-${WORKER_NAME:-$worker}}"
WORKER_NAME="${WORKER_NAME:-$worker_name}"
# --- /M10.99Z73_SAFE_WORKER_DEFAULTS ---

# M10.99Z62_RESTORE_DETAIL_UPLOADER_LOG_BRIDGE - ensure detail uploader tails current LIVE log and canonical coded-miner.log
# M10.99Z61_BUILDER_ONLY_NO_NODE_API_FIX - build_hive_release only on builder rig, no node dependency, fixed API base
# M10.99Z60_RESTORE_KNOWN_GOOD_ANALYTICS_ENV - restore known-good M1098E shadow/pass/budget analytics env in Z52 direct live runtime
# M10.99Z59E_RELEASE_PUSH_RETRY_NONBLOCKING - retry release repo push but do not block GitHub latest asset publish
# M10.99Z59D_CLEAN_HIVE_PACKAGING_BLOCK - clean W4 Hive package block and include h-run.sh
# M10.99Z59C_FIX_PKG_VAR_HRUN_PACKAGING - copy h-run.sh using real W4 package variable pkg, not undefined pkg_dir
# M10.99Z59B_FORCE_HRUN_BEFORE_TAR - force h-run.sh into package directory immediately before tar creation
# M10.99Z59_INCLUDE_HRUN_IN_HIVE_RELEASE_TAR - Hive release tar must include h-run.sh entrypoint
# M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE - Rig builder publishes GitHub Releases/latest asset using local token
# M10.99Z57B_FORCE_COMMAND_SHAPE_AND_HANDLER_CONTEXT - force /commands/next command wrapper parsing and W4 handler env context
# M10.99Z56C_PREFETCH_COMMAND_BEFORE_RELEASE_HANDLER - prefetch /commands/next before calling W4/Z53 release handler
# M10.99Z55_FORCE_RELEASE_BUILDER_EXECUTE - release-builder-only executes build_hive_release directly before fleet wait
# M10.99Z54_RELEASE_BUILDER_MODE_AND_HRUN_SHIM - release-builder-only mode disables mining fallbacks and ships h-run shim

# M10.99Z54_RELEASE_BUILDER_MODE_AND_HRUN_SHIM
# When building/publishing a release, the wrapper must NOT start default mining
# via Z45/Z52 never-idle paths. The command agent/release-builder must get control.
coded_z54_release_builder_only_enabled() {
  case "$(echo "${CODED_RELEASE_BUILDER_ONLY:-${RELEASE_BUILDER_ONLY:-}}" | tr '[:lower:]' '[:upper:]')" in
    1|YES|TRUE|ON) return 0 ;;
    *) return 1 ;;
  esac
}


# M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE
# Publish GitHub Releases/latest from the builder rig. pool-primary only enqueues the command.
m1099z58_read_github_token() {
  local token="${CODED_RELEASE_GITHUB_TOKEN:-${GITHUB_TOKEN:-${GH_TOKEN:-}}}"
  local f
  for f in \
    "${CODED_RELEASE_GITHUB_TOKEN_FILE:-}" \
    "/root/.coded/github_release_token" \
    "/hive/miners/custom/coded-miner/github_release_token" \
    "/hive/codedonqubic/.github_release_token"
  do
    if [ -z "$token" ] && [ -n "$f" ] && [ -f "$f" ]; then
      token="$(tr -d '\r\n ' < "$f" 2>/dev/null || true)"
    fi
  done
  printf '%s' "$token"
}

m1099z58_gh_api() {
  local method="$1"
  local url="$2"
  local token="$3"
  local json="${4:-}"

  if [ -n "$json" ]; then
    curl -fsS -X "$method" \
      -H "Authorization: Bearer $token" \
      -H "Accept: application/vnd.github+json" \
      -H "Content-Type: application/json" \
      -H "User-Agent: coded-release-builder" \
      "$url" \
      --data "$json"
  else
    curl -fsS -X "$method" \
      -H "Authorization: Bearer $token" \
      -H "Accept: application/vnd.github+json" \
      -H "User-Agent: coded-release-builder" \
      "$url"
  fi
}

m1099z58_upload_asset() {
  local upload_url="$1"
  local token="$2"
  local file="$3"
  local name="$4"

  echo "[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] upload asset name=$name file=$file size=$(stat -c%s "$file" 2>/dev/null || echo 0)"

  curl -fsS -X POST \
    -H "Authorization: Bearer $token" \
    -H "Accept: application/vnd.github+json" \
    -H "Content-Type: application/octet-stream" \
    -H "User-Agent: coded-release-builder" \
    --data-binary @"$file" \
    "${upload_url}?name=${name}" \
    > "/tmp/coded_z58_upload_${name}.json"

  python3 - "/tmp/coded_z58_upload_${name}.json" <<'PYJSON'
import json, sys
p = sys.argv[1]
j = json.load(open(p))
print("[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] uploaded", j.get("name"), j.get("state"), j.get("browser_download_url"))
PYJSON
}

m1099z58_publish_github_latest_release() {
  local version="$1"
  local artifact="$2"
  local latest_alias="$3"
  local out_dir="$4"
  local release_repo_slug="${5:-CodedOnQubic/coded-miner-release}"

  local token
  token="$(m1099z58_read_github_token)"

  if [ -z "$token" ]; then
    echo "[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] ERROR missing GitHub token on builder rig"
    return 58
  fi

  local latest_file="$out_dir/$latest_alias"
  local artifact_file="$out_dir/$artifact"
  local sums_file="$out_dir/SHA256SUMS"
  local manifest_file="$out_dir/release_manifest.json"

  [ -s "$latest_file" ] || { echo "[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] ERROR missing latest_file=$latest_file"; return 59; }
  [ -s "$artifact_file" ] || { echo "[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] ERROR missing artifact_file=$artifact_file"; return 60; }
  [ -s "$sums_file" ] || { echo "[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] ERROR missing SHA256SUMS"; return 61; }
  [ -s "$manifest_file" ] || { echo "[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] ERROR missing release_manifest.json"; return 62; }

  local tag="$version"
  local title="CODED Miner $version"
  local api="https://api.github.com/repos/$release_repo_slug"

  echo "[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] publish latest release repo=$release_repo_slug tag=$tag artifact=$artifact latest=$latest_alias"

  local existing_id
  existing_id="$(curl -fsS \
    -H "Authorization: Bearer $token" \
    -H "Accept: application/vnd.github+json" \
    "$api/releases/tags/$tag" 2>/dev/null | python3 -c 'import sys,json; print(json.load(sys.stdin).get("id",""))' 2>/dev/null || true)"

  if [ -n "$existing_id" ]; then
    echo "[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] delete existing release id=$existing_id"
    m1099z58_gh_api DELETE "$api/releases/$existing_id" "$token" >/dev/null
  fi

  curl -fsS -X DELETE \
    -H "Authorization: Bearer $token" \
    -H "Accept: application/vnd.github+json" \
    "$api/git/refs/tags/$tag" >/dev/null 2>&1 || true

  local create_json
  create_json="$(python3 - <<PYJSON
import json
print(json.dumps({
  "tag_name": "$tag",
  "target_commitish": "main",
  "name": "$title",
  "body": "Fleet release published by Rig2 builder. HiveOS latest URL: https://github.com/CodedOnQubic/coded-miner-release/releases/latest/download/coded-miner-latest.tar.gz",
  "draft": False,
  "prerelease": False,
  "make_latest": "true"
}))
PYJSON
)"

  local resp upload_url html_url
  resp="$(m1099z58_gh_api POST "$api/releases" "$token" "$create_json")"
  upload_url="$(printf '%s' "$resp" | python3 -c 'import sys,json; print(json.load(sys.stdin)["upload_url"].split("{")[0])')"
  html_url="$(printf '%s' "$resp" | python3 -c 'import sys,json; print(json.load(sys.stdin)["html_url"])')"

  echo "[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] release_url=$html_url"

  m1099z58_upload_asset "$upload_url" "$token" "$latest_file" "$latest_alias"
  m1099z58_upload_asset "$upload_url" "$token" "$artifact_file" "$artifact"
  m1099z58_upload_asset "$upload_url" "$token" "$sums_file" "SHA256SUMS"
  m1099z58_upload_asset "$upload_url" "$token" "$manifest_file" "release_manifest.json"

  echo "[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] verify releases/latest endpoint"
  curl -fsSLI "https://github.com/$release_repo_slug/releases/latest/download/$latest_alias" | grep -Ei 'HTTP/|location:|content-length|content-type' | tail -20 || return 63

  echo "[M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE] completed latest release tag=$tag latest_alias=$latest_alias"
  return 0
}


# M10.99Z59B_FORCE_HRUN_BEFORE_TAR
m1099z59b_force_hrun_into_package() {
  local root_dir="${1:-${root:-}}"
  local out_dir_arg="${2:-${out_dir:-}}"

  echo "[M10.99Z59B_FORCE_HRUN_BEFORE_TAR] force h-run root=$root_dir out_dir=$out_dir_arg"

  local src=""
  for c in \
    "$root_dir/release/hiveos/coded-miner/h-run.sh" \
    "/hive/codedonqubic/release/hiveos/coded-miner/h-run.sh" \
    "/hive/miners/custom/coded-miner/h-run.sh"
  do
    if [ -s "$c" ]; then
      src="$c"
      break
    fi
  done

  if [ -z "$src" ]; then
    echo "[M10.99Z59B_FORCE_HRUN_BEFORE_TAR] ERROR no h-run.sh source found"
    return 591
  fi

  local copied=0
  for d in \
    "$out_dir_arg/coded-miner" \
    "${pkg_dir:-}" \
    "${package_dir:-}" \
    "${release_pkg_dir:-}"
  do
    if [ -n "$d" ] && [ -d "$d" ]; then
      cp "$src" "$d/h-run.sh"
      chmod +x "$d/h-run.sh"
      echo "[M10.99Z59B_FORCE_HRUN_BEFORE_TAR] copied h-run.sh -> $d/h-run.sh"
      copied=1
    fi
  done

  if [ "$copied" != "1" ]; then
    echo "[M10.99Z59B_FORCE_HRUN_BEFORE_TAR] ERROR no package directory found for h-run.sh"
    find "$out_dir_arg" -maxdepth 3 -type d -print 2>/dev/null | sed -n '1,80p'
    return 592
  fi

  if [ -n "$out_dir_arg" ] && [ -d "$out_dir_arg/coded-miner" ]; then
    ls -lah "$out_dir_arg/coded-miner" || true
  fi

  return 0
}

# M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL - release builder uses HTTPS/token and hard-fails upload errors

# M10.99Z52_FLEET_DIRECT_LIVE_RELEASE
# Stable emergency/fleet default path:
# If Hive flight sheet sets CODED_ANALYTICS=YES, start the real miner directly,
# keep it in the Hive screen foreground, and run a small analytics uploader.
# This restores default fleet runtime without requiring SSH per rig.
coded_z52_direct_live_release() {
  if coded_z54_release_builder_only_enabled; then
    echo "[M10.99Z54_RELEASE_BUILDER_MODE_AND_HRUN_SHIM] release-builder-only: skip Z52 direct live runtime"
    return 99
  fi
  set +e

  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)"
  MINER_BIN="${SCRIPT_DIR}/coded-miner"
  CONFIG_JSON="${SCRIPT_DIR}/config.json"
  LOG_DIR="/var/log/miner/coded-miner"
  mkdir -p "$LOG_DIR" 2>/dev/null || true

  local analytics="${CODED_ANALYTICS:-${coded_analytics:-${CUSTOM_CODED_ANALYTICS:-}}}"
  if [ -z "$analytics" ] && [ -f "$CONFIG_JSON" ]; then
    analytics="$(grep -Eo '"CODED_ANALYTICS"[[:space:]]*:[[:space:]]*"[^"]+"' "$CONFIG_JSON" 2>/dev/null | head -n1 | sed -E 's/.*"CODED_ANALYTICS"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/')"
  fi

  case "$(echo "$analytics" | tr '[:lower:]' '[:upper:]')" in
    YES|TRUE|1|ON) ;;
    *) return 99 ;;
  esac

  if [ "${CODED_Z52_DISABLE:-0}" = "1" ]; then
    echo "[M10.99Z52_FLEET_DIRECT_LIVE_RELEASE] disabled by CODED_Z52_DISABLE=1"
    return 99
  fi

  local rig="${CODED_RIG_ID:-${RIG_ID:-$(hostname 2>/dev/null | sed 's/[^A-Za-z0-9]//g')}}"
  [ -z "$rig" ] && rig="RigUnknown"

  m1091l_apply_canonical_default_profile
  local threshold="${CODED_FAST_SHADOW_THRESHOLD:-${THRESHOLD:-}}"
  if [ -z "$threshold" ]; then
    case "$rig" in
      Rig1X3D|Rig3X) threshold=509 ;;
      Rig2X3D|Rig4X) threshold=510 ;;
      Rig5X3D|Rig6X3D) threshold=511 ;;
      *) threshold=510 ;;
    esac
  fi

  local worker="${WORKER_NAME:-${RUN_WORKER:-$(m1091l_default_worker_for_rig "$rig")}}"
  local threads="${THREADS:-${COMMAND_THREADS:-${CODED_THREADS:-${CODED_SAFE_THREADS:-24}}}}"
  local pool="${POOL:-${CUSTOM_POOL:-${POOL_URL:-178.104.150.57:7777}}}"
  local api="${POOL_API_URL:-${CODED_POOL_API_URL:-http://178.104.150.57:4000}}"
  local token="${CODED_ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}"

  local wallet="${WALLET:-${CUSTOM_TEMPLATE:-${walletTemplate:-}}}"
  if [ -z "$wallet" ] && [ -f "$CONFIG_JSON" ]; then
    wallet="$(grep -Eo '"walletTemplate"[[:space:]]*:[[:space:]]*"[^"]+"' "$CONFIG_JSON" 2>/dev/null | head -n1 | sed -E 's/.*"walletTemplate"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/')"
  fi
  if [ -z "$wallet" ] && [ -f "$CONFIG_JSON" ]; then
    wallet="$(grep -Eo '"wallet"[[:space:]]*:[[:space:]]*"[^"]+"' "$CONFIG_JSON" 2>/dev/null | head -n1 | sed -E 's/.*"wallet"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/')"
  fi

  local run_id="${CODED_RUN_ID:-LIVE_${rig}_T${threshold}_$(date -u +%Y%m%d_%H%M%S)}"
  local run_log="${LOG_DIR}/${run_id}.log"
  touch "$run_log" 2>/dev/null || true

  echo "[M10.99Z52_FLEET_DIRECT_LIVE_RELEASE] start rig=$rig worker=$worker threshold=$threshold threads=$threads pool=$pool wallet_len=${#wallet} run_id=$run_id bin=$MINER_BIN log=$run_log" | tee -a "$run_log"

  if [ ! -x "$MINER_BIN" ]; then
    echo "[M10.99Z52_FLEET_DIRECT_LIVE_RELEASE] ERROR miner binary missing/not executable: $MINER_BIN" | tee -a "$run_log"
    exit 21
  fi

  if [ -z "$wallet" ] || [ "${#wallet}" -lt 20 ]; then
    echo "[M10.99Z52_FLEET_DIRECT_LIVE_RELEASE] ERROR missing real wallet; wallet_len=${#wallet}" | tee -a "$run_log"
    exit 22
  fi

  # Register live run. Failure must not block mining.
  curl -sS -m 5 -X POST "$api/analytics/runs/start" \
    -H "Authorization: Bearer $token" \
    -H "Content-Type: application/json" \
    -d "{\"run_id\":\"$run_id\",\"rig_id\":\"$rig\",\"worker_name\":\"$worker\",\"backend\":\"avx512\",\"threads\":$threads,\"threshold\":$threshold,\"gate_mode\":\"fast_shadow\",\"audit_rate\":500,\"status\":\"running\",\"pool_url\":\"$pool\",\"wallet\":\"$wallet\",\"miner_version\":\"M10.99Z52_FLEET_DIRECT_LIVE_RELEASE\"}" \
    > /tmp/coded_z52_run_start_resp.log 2>&1 || true
  echo "[M10.99Z52_FLEET_DIRECT_LIVE_RELEASE] run_start_resp=$(cat /tmp/coded_z52_run_start_resp.log 2>/dev/null | tr '\n' ' ' | head -c 300)" | tee -a "$run_log"

  # Kill old emergency uploader only. Do not kill unrelated Hive agent/autofan.
  pkill -9 -f coded_z52_default_uploader 2>/dev/null || true
  pkill -9 -f coded_default_uploader 2>/dev/null || true

  (
    LAST_TOTAL=0
    LAST_TS="$(date +%s)"
    while true; do
      NOW="$(date +%s)"
      TOTAL="$(grep -aoE 'HI_TIMING_SUMMARY\] total=[0-9]+' "$run_log" 2>/dev/null | tail -n1 | grep -aoE '[0-9]+$' || echo 0)"
      MAX_SCORE="$(grep -aoE 'score=[0-9]+' "$run_log" 2>/dev/null | grep -aoE '[0-9]+' | sort -nr | head -n1 || echo 0)"

      UI_LINE="$(grep -aE '\[[A-Z0-9]+\] [0-9]+ it/s \| [0-9]+ avg it/s' "$run_log" 2>/dev/null | tail -n1 || true)"
      LAST_ITS="$(echo "$UI_LINE" | grep -aoE '\[[A-Z0-9]+\] [0-9]+ it/s' | grep -aoE '[0-9]+' | tail -n1 || echo 0)"
      AVG_ITS="$(echo "$UI_LINE" | grep -aoE '\| [0-9]+ avg it/s' | grep -aoE '[0-9]+' | tail -n1 || echo 0)"

      if [ -z "$LAST_ITS" ] || [ "$LAST_ITS" = "0" ]; then
        DELTA=$((TOTAL-LAST_TOTAL))
        DT=$((NOW-LAST_TS))
        [ "$DT" -lt 1 ] && DT=1
        LAST_ITS=$((DELTA/DT))
        AVG_ITS="$LAST_ITS"
      fi

      curl -sS -m 5 -X POST "$api/analytics/runs/summary" \
        -H "Authorization: Bearer $token" \
        -H "Content-Type: application/json" \
        -d "{\"run_id\":\"$run_id\",\"rig_id\":\"$rig\",\"worker_name\":\"$worker\",\"live_status\":\"running\",\"status\":\"running\",\"backend\":\"avx512\",\"threads\":$threads,\"threshold\":$threshold,\"avg_its\":$AVG_ITS,\"last_its\":$LAST_ITS,\"total_seen\":$TOTAL,\"total_pass\":0,\"pass_rate\":0,\"false_negative\":0,\"max_real_score_passed\":$MAX_SCORE,\"max_real_score_audited_skip\":$MAX_SCORE}" \
        > /tmp/coded_z52_uploader_resp.log 2>&1 || true

      LAST_TOTAL="$TOTAL"
      LAST_TS="$NOW"
      sleep 20
    done
  ) &
  UPLOADER_PID=$!
  echo "[M10.99Z52_FLEET_DIRECT_LIVE_RELEASE] uploader_pid=$UPLOADER_PID" | tee -a "$run_log"

  export CODED_ANALYTICS=YES
  export CODED_RUN_ID="$run_id"
  export RIG_ID="$rig"
  export CODED_RIG_ID="$rig"
  export CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx512}"
  export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
  export CODED_KERNEL_ALLOW_FALLBACK="${CODED_KERNEL_ALLOW_FALLBACK:-1}"
  export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
  export CODED_FAST_SHADOW_GATE="${CODED_FAST_SHADOW_GATE:-1}"
  export CODED_FAST_SHADOW_THRESHOLD="$threshold"
  export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-500}"
  export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"
  export CODED_SHADOW_AVX512_LIVE="${CODED_SHADOW_AVX512_LIVE:-1}"
  export CODED_PRIORITY_BUDGET_ROUTER="${CODED_PRIORITY_BUDGET_ROUTER:-$(m1091l_default_router_for_threshold "${CODED_FAST_SHADOW_THRESHOLD:-${THRESHOLD:-510}}")}"

  # M10.99Z60_RESTORE_KNOWN_GOOD_ANALYTICS_ENV
  # Restore the known-good analytics/gate env that previously produced passrate,
  # shadow summaries, histograms, score distribution and priority-budget telemetry.
  export CODED_ANALYTICS="${CODED_ANALYTICS:-YES}"
  export CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx512}"
  export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
  export CODED_KERNEL_ALLOW_FALLBACK="${CODED_KERNEL_ALLOW_FALLBACK:-1}"
  export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
  export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
  export CODED_FAST_SHADOW_GATE="${CODED_FAST_SHADOW_GATE:-1}"
  export CODED_FAST_SHADOW_THRESHOLD="${CODED_FAST_SHADOW_THRESHOLD:-$threshold}"
  export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-500}"
  export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"
  export CODED_SHADOW_AVX512_LIVE="${CODED_SHADOW_AVX512_LIVE:-1}"
  export CODED_PRIORITY_BUDGET_ROUTER="${CODED_PRIORITY_BUDGET_ROUTER:-$(m1091l_default_router_for_threshold "${CODED_FAST_SHADOW_THRESHOLD:-${THRESHOLD:-510}}")}"
  export CODED_SCORE_SAMPLE_BATCH_RATE="${CODED_SCORE_SAMPLE_BATCH_RATE:-1}"
  export CODED_SCORE_SAMPLE_RATE="${CODED_SCORE_SAMPLE_RATE:-1}"

  echo "[M10.99Z60_RESTORE_KNOWN_GOOD_ANALYTICS_ENV] env backend=$CODED_KERNEL_BACKEND activation=$CODED_KERNEL_ACTIVATION prefilter=$CODED_PREFILTER_DIFFICULTY shadow_gate=$CODED_FAST_SHADOW_GATE shadow_threshold=$CODED_FAST_SHADOW_THRESHOLD audit=$CODED_FAST_SHADOW_AUDIT_RATE summary_sec=$CODED_FAST_SHADOW_SUMMARY_SEC router=$CODED_PRIORITY_BUDGET_ROUTER score_mode=$CODED_SCORE_ALGO_MODE avx512_live=$CODED_SHADOW_AVX512_LIVE" | tee -a "$run_log"

  # M10.99Z62_RESTORE_DETAIL_UPLOADER_LOG_BRIDGE
  # Restore old detail-pipeline behaviour:
  # - current run log is exposed under every legacy variable name the uploader may use
  # - current LIVE_*.log is mirrored into canonical coded-miner.log for legacy tailers
  export RUN_LOG="$run_log"
  export CODED_RUN_LOG="$run_log"
  export MINER_LOG="$run_log"
  export CODED_MINER_LOG="$run_log"
  export CODED_ANALYTICS_LOG="$run_log"
  export CODED_FLEET_UPLOADER_LOG="$run_log"
  export CODED_DETAIL_UPLOADER_LOG="$run_log"
  export CODED_ENABLE_DETAIL_UPLOAD="${CODED_ENABLE_DETAIL_UPLOAD:-1}"
  export CODED_ENABLE_SHADOW_UPLOAD="${CODED_ENABLE_SHADOW_UPLOAD:-1}"
  export CODED_ENABLE_PRIORITY_BUDGET_UPLOAD="${CODED_ENABLE_PRIORITY_BUDGET_UPLOAD:-1}"
  export CODED_ENABLE_SCORE_DISTRIBUTION_UPLOAD="${CODED_ENABLE_SCORE_DISTRIBUTION_UPLOAD:-1}"
  export CODED_ENABLE_PERFORMANCE_UPLOAD="${CODED_ENABLE_PERFORMANCE_UPLOAD:-1}"

  canonical_log="/var/log/miner/coded-miner/coded-miner.log"
  mkdir -p "$(dirname "$canonical_log")" 2>/dev/null || true
  touch "$canonical_log" 2>/dev/null || true

  if [ "$run_log" != "$canonical_log" ]; then
    # Bridge LIVE log to canonical log so old M10.88/M10.92 uploader parsers see FAST_SHADOW_* and PRIORITY_BUDGET_ROUTER again.
    # Start after current end to avoid replaying huge historical logs.
    ( tail -n 0 -F "$run_log" >> "$canonical_log" 2>/dev/null ) &
    coded_log_bridge_pid="$!"
    echo "[M10.99Z62_RESTORE_DETAIL_UPLOADER_LOG_BRIDGE] bridge_pid=$coded_log_bridge_pid run_log=$run_log canonical_log=$canonical_log" | tee -a "$run_log"
  else
    echo "[M10.99Z62_RESTORE_DETAIL_UPLOADER_LOG_BRIDGE] bridge skipped same log=$run_log" | tee -a "$run_log"
  fi

  echo "[M10.99Z62_RESTORE_DETAIL_UPLOADER_LOG_BRIDGE] uploader_log_env RUN_LOG=$RUN_LOG CODED_ANALYTICS_LOG=$CODED_ANALYTICS_LOG canonical=$canonical_log shadow_upload=$CODED_ENABLE_SHADOW_UPLOAD budget_upload=$CODED_ENABLE_PRIORITY_BUDGET_UPLOAD" | tee -a "$run_log"

  echo "[M10.99Z52_FLEET_DIRECT_LIVE_RELEASE] exec miner now" | tee -a "$run_log"

  exec "$MINER_BIN" --pool "$pool" --wallet "$wallet" --worker "$worker" --threads "$threads" >> "$run_log" 2>&1
}

coded_z52_direct_live_release
Z52_RC=$?
if [ "$Z52_RC" = "0" ]; then
  exit 0
fi
# If analytics is not enabled, continue into legacy wrapper below.

# M10.99Z45_NEVER_IDLE_DEFAULT_RUNTIME - CODED_ANALYTICS=YES must always launch default runtime if command loop is idle
# M10.99Z47_HIVE_CONFIG_WALLETTEMPLATE - read HiveOS walletTemplate/pool/env from config.json
# M10.99Z49B_ENQUEUE_THEN_LAUNCH_LOCAL_FLEX - after fallback enqueue, launch local runtime immediately
API="${CODED_API_ROOT:-${CODED_API:-${API:-http://178.104.150.57:4000/analytics}}}"
API_ROOT="${API%/}"
API_ROOT="${API_ROOT%/analytics}"
CODED_API_ROOT="$API_ROOT"

# M10.99Z45_NEVER_IDLE_DEFAULT_RUNTIME
coded_z45_default_worker() {
  case "${RIG_ID:-${CODED_RIG_ID:-$(hostname)}}" in
    Rig1X3D*) echo "Rig1X3D_M1091B_REAL321_T508_DENSITY" ;;
    Rig2X3D*) echo "Rig2X3D_M1091B_REAL321_T509_BIAS_BREAK" ;;
    Rig3X*)   echo "Rig3X_M1091B_REAL321_T509_BROAD" ;;
    Rig4X*)   echo "Rig4X_M1091B_REAL321_T510_BALANCED" ;;
    Rig5X3D*) echo "Rig5X3D_M1091B_REAL321_T509_X3D" ;;
    Rig6X3D*) echo "Rig6X3D_M1091B_REAL321_T510_BALANCED" ;;
    *)        echo "$(m1091l_default_worker_for_rig "${RIG_ID:-${CODED_RIG_ID:-coded-worker}}")" ;;
  esac
}

coded_z45_default_threshold() {
  case "$(coded_z45_default_worker)" in
    *T509) echo "509" ;;
    *T511) echo "511" ;;
    *) echo "510" ;;
  esac
}

coded_z45_find_wallet() {
  # Prefer already exported runtime env.
  for v in WALLET CODED_WALLET QUBIC_WALLET HIVE_WALLET; do
    eval val="\${$v:-}"
    if [ -n "$val" ] && [ "$val" != "TEST" ] && [ "$val" != "TEST_WALLET" ]; then
      echo "$val"
      return 0
    fi
  done

  # Try custom miner config.
  if [ -f /hive/miners/custom/coded-miner/config.json ]; then
    val="$(grep -Eo '"wallet"[[:space:]]*:[[:space:]]*"[^"]+"' /hive/miners/custom/coded-miner/config.json 2>/dev/null | head -n1 | sed -E 's/.*"wallet"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/' || true)"
    if [ -n "$val" ] && [ "$val" != "TEST" ] && [ "$val" != "TEST_WALLET" ]; then
      echo "$val"
      return 0
    fi
  fi

  # M10.99Z47_HIVE_CONFIG_WALLETTEMPLATE
  # HiveOS custom miner config uses walletTemplate, not wallet.
  if [ -f /hive/miners/custom/coded-miner/config.json ]; then
    val="$(grep -Eo '"walletTemplate"[[:space:]]*:[[:space:]]*"[^"]+"' /hive/miners/custom/coded-miner/config.json 2>/dev/null | head -n1 | sed -E 's/.*"walletTemplate"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/' || true)"
    if [ -n "$val" ] && [ "$val" != "TEST" ] && [ "$val" != "TEST_WALLET" ]; then
      echo "$val"
      return 0
    fi
  fi


  # Try Hive common config files and environment dumps.
  val="$(grep -RhoE '[A-Z]{55,70}' /hive/miners/custom/coded-miner /hive-config /hive/etc 2>/dev/null | head -n1 || true)"
  if [ -n "$val" ]; then
    echo "$val"
    return 0
  fi

  return 1
}

coded_z45_never_idle_default_runtime() {
  if coded_z54_release_builder_only_enabled; then
    echo "[M10.99Z54_RELEASE_BUILDER_MODE_AND_HRUN_SHIM] release-builder-only: skip Z45 never-idle runtime"
    return 99
  fi
  # Only in analytics/fleet mode.
  case "${CODED_ANALYTICS:-${coded_analytics:-}}" in
    YES|yes|1|true|TRUE) ;;
    *) return 0 ;;
  esac

  # If miner already runs, do nothing.
  if pgrep -f "/hive/miners/custom/coded-miner/coded-miner.*--worker" >/dev/null 2>&1 || pgrep -f "coded-miner.*--worker" >/dev/null 2>&1; then
    return 0
  fi

  MINER_BIN="${MINER_BIN:-/hive/miners/custom/coded-miner/coded-miner}"
  RUN_LOG="${RUN_LOG:-/var/log/miner/coded-miner/Z45_${RIG_ID:-$(hostname)}_$(date -u +%Y%m%d_%H%M%S).log}"
  mkdir -p "$(dirname "$RUN_LOG")"

  # M10.99Z47_HIVE_CONFIG_WALLETTEMPLATE
  CONFIG_POOL="$(grep -Eo '"pool"[[:space:]]*:[[:space:]]*"[^"]+"' /hive/miners/custom/coded-miner/config.json 2>/dev/null | head -n1 | sed -E 's/.*"pool"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/' || true)"
  POOL="${POOL:-${CODED_POOL:-${POOL_URL:-${CONFIG_POOL:-178.104.150.57:7777}}}}"
  WALLET="$(coded_z45_find_wallet || true)"
  RUN_WORKER="${RUN_WORKER:-$(coded_z45_default_worker)}"
  THREADS="${THREADS:-${COMMAND_THREADS:-${CODED_THREADS:-${CODED_SAFE_THREADS:-24}}}}"
  THRESHOLD="${THRESHOLD:-$(coded_z45_default_threshold)}"
  RUN_ID="${RUN_ID:-Z45_${RUN_WORKER}_$(date -u +%Y%m%d_%H%M%S)}"

  export CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx512}"
  export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
  export CODED_KERNEL_ALLOW_FALLBACK="${CODED_KERNEL_ALLOW_FALLBACK:-1}"
  export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
  export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
  export CODED_FAST_SHADOW_GATE="${CODED_FAST_SHADOW_GATE:-1}"
  export CODED_FAST_SHADOW_THRESHOLD="${CODED_FAST_SHADOW_THRESHOLD:-$THRESHOLD}"
  export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-500}"
  export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"
  export CODED_SHADOW_AVX512_LIVE="${CODED_SHADOW_AVX512_LIVE:-1}"
  export CODED_PRIORITY_BUDGET_ROUTER="${CODED_PRIORITY_BUDGET_ROUTER:-$(m1091l_default_router_for_threshold "${CODED_FAST_SHADOW_THRESHOLD:-${THRESHOLD:-510}}")}"
  export CODED_RUN_ID="$RUN_ID"
  export RUN_ID="$RUN_ID"

  m1091l_apply_canonical_default_profile
  echo "[M10.99Z45_NEVER_IDLE_DEFAULT_RUNTIME] fallback_check pool=$POOL wallet_len=${#WALLET} worker=$RUN_WORKER threads=$THREADS threshold=$THRESHOLD bin=$MINER_BIN run_id=$RUN_ID" | tee -a "$RUN_LOG"

  if [ ! -x "$MINER_BIN" ]; then
    echo "[M10.99Z45_NEVER_IDLE_DEFAULT_RUNTIME] ERROR miner binary missing/not executable bin=$MINER_BIN" | tee -a "$RUN_LOG"
    return 45
  fi

  if [ -z "$WALLET" ] || [ "$WALLET" = "TEST" ] || [ "$WALLET" = "TEST_WALLET" ]; then
    echo "[M10.99Z45_NEVER_IDLE_DEFAULT_RUNTIME] ERROR missing real wallet; refusing fallback launch" | tee -a "$RUN_LOG"
    return 46
  fi

  nc -zvw3 "$(echo "$POOL" | cut -d: -f1)" "$(echo "$POOL" | cut -d: -f2)" >> "$RUN_LOG" 2>&1 || {
    echo "[M10.99Z45_NEVER_IDLE_DEFAULT_RUNTIME] ERROR pool tcp unavailable pool=$POOL" | tee -a "$RUN_LOG"
    return 47
  }

  echo "[M10.99Z45_NEVER_IDLE_DEFAULT_RUNTIME] launching miner" | tee -a "$RUN_LOG"
  "$MINER_BIN" --pool "$POOL" --wallet "$WALLET" --worker "$RUN_WORKER" --threads "$THREADS" >> "$RUN_LOG" 2>&1 &
  MINER_PID="$!"
  echo "[M10.99Z45_NEVER_IDLE_DEFAULT_RUNTIME] miner_pid=$MINER_PID" | tee -a "$RUN_LOG"

  sleep 5
  if ! kill -0 "$MINER_PID" >/dev/null 2>&1; then
    echo "[M10.99Z45_NEVER_IDLE_DEFAULT_RUNTIME] ERROR miner exited immediately" | tee -a "$RUN_LOG"
    tail -80 "$RUN_LOG" || true
    return 48
  fi

  return 0
}


set -euo pipefail

# M10.99Z199_FULLSCORE_BACKEND_ENV
# Fullscore is authoritative on every backend. Shadow/Priority telemetry may run,
# but it must not suppress authoritative fullscore while this contract is active.
export CODED_FORCE_FULLSCORE="${CODED_FORCE_FULLSCORE:-1}"
export CODED_FULLSCORE_ALL_BACKENDS="${CODED_FULLSCORE_ALL_BACKENDS:-1}"
export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
export CODED_SAFE_THREADS="${CODED_SAFE_THREADS:-24}"
coded_z216_resolve_safe_threads
export CODED_THREADS="$THREADS"
export COMMAND_THREADS="$THREADS"
export CODED_PLATFORM="${CODED_PLATFORM:-hive-linux-amd64-avx512}"


echo "[CODED] start.sh starting..."

CONFIG_PATH="/hive/miners/custom/coded-miner/config.json"
MINER_BIN="/hive/miners/custom/coded-miner/coded-miner"

if [ ! -f "$CONFIG_PATH" ]; then
  if [ "${CODED_FLEET:-}" = "1" ] || [ "${CODED_ANALYTICS:-}" = "YES" ]; then
    echo "[M10.99J_CONFIG_RECOVERY] missing config.json at $CONFIG_PATH; reconstructing fleet config from env/defaults"
    mkdir -p "$(dirname "$CONFIG_PATH")"
    cat > "$CONFIG_PATH" <<EOF
{
  "pool": "${CODED_POOL:-pool.codedonqubic.com:7777}",
  "walletTemplate": "${CODED_WALLET:-EUELEOZEENRCEDYVEAZEBYVHQFABSUFFWTUWTFNSFALSTCNJLCDSEROGOSYI}",
  "workerName": "${CODED_DEFAULT_WORKER:-${CODED_RIG_ID:-$(hostname)}}",
  "amountOfThreads": ${COMMAND_THREADS:-${CODED_THREADS:-${CODED_SAFE_THREADS:-24}}},
  "threads": ${COMMAND_THREADS:-${CODED_THREADS:-${CODED_SAFE_THREADS:-24}}},
  "env": "CODED_ANALYTICS=YES"
}
EOF
  else
    echo "[CODED] ERROR: missing config.json at $CONFIG_PATH"
    exit 1
  fi
fi

if [ ! -x "$MINER_BIN" ]; then
  echo "[CODED] ERROR: miner binary not executable at $MINER_BIN"
  ls -la /hive/miners/custom/coded-miner || true
  exit 1
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "[CODED] jq not found, installing..."
  apt-get update
  apt-get install -y jq
fi

POOL="$(jq -r '.pool' "$CONFIG_PATH")"
WALLET="$(jq -r '.walletTemplate' "$CONFIG_PATH")"
WORKER="$(jq -r '.workerName' "$CONFIG_PATH")"
THREADS="$(jq -r '.threads' "$CONFIG_PATH")"
EXTRA_CONFIG="$(jq -r '.extraConfig // .pass // .user_config // ""' "$CONFIG_PATH")"

if [ -z "$POOL" ] || [ "$POOL" = "null" ]; then
  echo "[CODED] ERROR: invalid pool in config.json"
  exit 1
fi

if [ -z "$WALLET" ] || [ "$WALLET" = "null" ]; then
  echo "[CODED] ERROR: invalid walletTemplate in config.json"
  exit 1
fi

if [ -z "$WORKER" ] || [ "$WORKER" = "null" ]; then
  echo "[CODED] ERROR: invalid workerName in config.json"
  exit 1
fi

THREADS="$(jq -r '.amountOfThreads // .threads // 0' "$CONFIG_PATH")"
if [ "$THREADS" = "1" ] || [ "$THREADS" = "0" ]; then
  TOTAL_THREADS="$(nproc 2>/dev/null || echo 2)"
  if [ "$TOTAL_THREADS" -gt 1 ]; then
    THREADS="$((TOTAL_THREADS - 1))"
  else
    THREADS="1"
  fi
fi
EXTRA_CONFIG="$(jq -r '.env // .extraConfig // .pass // .user_config // ""' "$CONFIG_PATH")"

if [ -z "$THREADS" ] || [ "$THREADS" = "null" ]; then
  THREADS="0"
fi

if ! printf '%s' "$THREADS" | grep -Eq '^[0-9]+$'; then
  THREADS="0"
fi

echo "[CODED] POOL=$POOL"
echo "[CODED] WALLET=$WALLET"
echo "[CODED] WORKER=$WORKER"
echo "[CODED] THREADS=$THREADS"
# M10.99Z46_EARLY_NEVER_IDLE_HOOK
# The old command/wait loops can block before reaching footer fallback.
# If CODED_ANALYTICS=YES and no miner is alive, launch default runtime now.
# M10.99Z47_HIVE_CONFIG_WALLETTEMPLATE
CONFIG_ENV_ANALYTICS="$(grep -Eo '"env"[[:space:]]*:[[:space:]]*"[^"]*CODED_ANALYTICS=YES[^"]*"' /hive/miners/custom/coded-miner/config.json 2>/dev/null || true)"
case "${CODED_ANALYTICS:-${coded_analytics:-}}" in
  YES|yes|1|true|TRUE)
    echo "[M10.99Z46_EARLY_NEVER_IDLE_HOOK] analytics enabled; checking early fallback"; if coded_z54_release_builder_only_enabled; then echo "[M10.99Z54_RELEASE_BUILDER_MODE_AND_HRUN_SHIM] release-builder-only: early fallback suppressed"; else
    if coded_z54_release_builder_only_enabled; then echo "[M10.99Z55_FORCE_RELEASE_BUILDER_EXECUTE] suppress Z45 call in release-builder-only"; else coded_z45_never_idle_default_runtime || true; fi
    fi # M10.99Z54 early fallback guard
    ;;
  *)
    if [ -n "$CONFIG_ENV_ANALYTICS" ]; then
      export CODED_ANALYTICS=YES
      echo "[M10.99Z47_HIVE_CONFIG_WALLETTEMPLATE] analytics enabled from config.json env; checking early fallback"
      if coded_z54_release_builder_only_enabled; then echo "[M10.99Z55_FORCE_RELEASE_BUILDER_EXECUTE] suppress Z45 call in release-builder-only"; else coded_z45_never_idle_default_runtime || true; fi
    fi
    ;;
esac


if [ -n "$EXTRA_CONFIG" ] && [ "$EXTRA_CONFIG" != "null" ]; then
  echo "[CODED] applying HiveOS extra config"
  while IFS= read -r line; do
    line="$(echo "$line" | sed 's/^ *//;s/ *$//')"
    [ -z "$line" ] && continue
    echo "$line" | grep -q '^#' && continue

    case "$line" in
      CODED_*=*)
        export "$line"
        ;;
      *)
        echo "[CODED] ignoring unsupported extra config line: $line"
        ;;
    esac
  done <<EOF
$EXTRA_CONFIG
EOF
fi

export CODED_HYPER_HIT_MODE="${CODED_HYPER_HIT_MODE:-crypto}"
export CODED_LOG_MODE="${CODED_LOG_MODE:-public}"

# M10.99Z2: if miner stays in WAITING FOR FIRST JOB too long, restart only the miner process.
# This protects fleet runtime after release/pool handshakes without killing the supervisor.
export CODED_FIRST_JOB_TIMEOUT_SEC="${CODED_FIRST_JOB_TIMEOUT_SEC:-180}"

# M10.99Z12_DURATION_PRODUCTIVE_RUNTIME_GUARD
# A command heartbeat alone is not productive mining.
# If a launched miner does not produce SOLS/it/s/summary within this window,
# restart only the miner process and let the outer loop recover.
export CODED_PRODUCTIVE_RUNTIME_TIMEOUT_SEC="${CODED_PRODUCTIVE_RUNTIME_TIMEOUT_SEC:-180}"

# M10.25a production preset: validated Shadow500 path.
# Can be overridden from HiveOS extra config.
export CODED_RANDOM2_HUGEPAGE="${CODED_RANDOM2_HUGEPAGE:-1}"
export CODED_BATCH_SIZE="${CODED_BATCH_SIZE:-64}"
export CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx512}"
export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
export CODED_SCORE_SAMPLE_BATCH_RATE="${CODED_SCORE_SAMPLE_BATCH_RATE:-0}"
export CODED_SCORE_DEBUG="${CODED_SCORE_DEBUG:-0}"
# ============================================================
# M10.96H Analytics Auto Defaults
# HiveOS must stay simple:
#   CODED_ANALYTICS=YES
#
# When analytics is enabled, the miner automatically enters the
# safest research profile:
# - Fast shadow gate enabled
# - Per-rig threshold cohort assignment
# - Dual-gate observe mode T509 -> T511
# - No hard dual-gate rejection
# - Fullscore remains authoritative
# ============================================================

coded_bool_yes_early() {
  case "${1:-}" in
    1|yes|YES|true|TRUE|on|ON) return 0 ;;
    *) return 1 ;;
  esac
}

coded_infer_analytics_threshold_early() {
  case "${CODED_RIG_ID:-$(hostname)}" in
    Rig1X3D) echo "509" ;;
    Rig2X3D) echo "510" ;;
    Rig3X) echo "509" ;;
    Rig4X) echo "510" ;;
    Rig5X3D) echo "511" ;;
    Rig6X3D) echo "511" ;;
    *) echo "510" ;;
  esac
}

export CODED_FAST_SHADOW_GATE="${CODED_FAST_SHADOW_GATE:-1}"

if coded_bool_yes_early "${CODED_ANALYTICS:-}"; then
  export CODED_FAST_SHADOW_THRESHOLD="${CODED_FAST_SHADOW_THRESHOLD:-$(coded_infer_analytics_threshold_early)}"
  export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-500}"
  export CODED_MULTI_GATE_MODE="${CODED_MULTI_GATE_MODE:-observe}"
  export CODED_MULTI_GATE_STAGE1="${CODED_MULTI_GATE_STAGE1:-509}"
  export CODED_MULTI_GATE_STAGE2="${CODED_MULTI_GATE_STAGE2:-511}"
  export CODED_MULTI_GATE_HARD_REJECT="${CODED_MULTI_GATE_HARD_REJECT:-0}"
  export CODED_PRIORITY_ROUTER="${CODED_PRIORITY_ROUTER:-observe}"
  export CODED_PRIORITY_BUDGET_ROUTER="${CODED_PRIORITY_BUDGET_ROUTER:-M1098C}"
else
  export CODED_FAST_SHADOW_THRESHOLD="${CODED_FAST_SHADOW_THRESHOLD:-507}"
  export CODED_FAST_SHADOW_AUDIT_RATE="${CODED_FAST_SHADOW_AUDIT_RATE:-0}"
fi

export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"

echo "[CODED] BACKEND=$CODED_KERNEL_BACKEND"
echo "[CODED] ACTIVATION=$CODED_KERNEL_ACTIVATION"
echo "[CODED] RANDOM2_HUGEPAGE=$CODED_RANDOM2_HUGEPAGE"
echo "[CODED] BATCH_SIZE=$CODED_BATCH_SIZE"
echo "[CODED] PREFILTER=$CODED_PREFILTER_DIFFICULTY"
echo "[CODED] SCORE_ALGO_MODE=$CODED_SCORE_ALGO_MODE"
echo "[CODED] SCORE_SAMPLE_BATCH_RATE=$CODED_SCORE_SAMPLE_BATCH_RATE"
echo "[CODED] FAST_SHADOW_GATE=$CODED_FAST_SHADOW_GATE"
echo "[CODED] FAST_SHADOW_THRESHOLD=$CODED_FAST_SHADOW_THRESHOLD"
echo "[CODED] FAST_SHADOW_AUDIT_RATE=$CODED_FAST_SHADOW_AUDIT_RATE"
echo "[CODED] FAST_SHADOW_SUMMARY_SEC=$CODED_FAST_SHADOW_SUMMARY_SEC"
echo "[CODED] MULTI_GATE_MODE=${CODED_MULTI_GATE_MODE:-off}"
echo "[CODED] MULTI_GATE_STAGE1=${CODED_MULTI_GATE_STAGE1:-}"
echo "[CODED] MULTI_GATE_STAGE2=${CODED_MULTI_GATE_STAGE2:-}"
echo "[CODED] MULTI_GATE_HARD_REJECT=${CODED_MULTI_GATE_HARD_REJECT:-0}"
echo "[CODED] PRIORITY_ROUTER=${CODED_PRIORITY_ROUTER:-off}"
echo "[CODED] PRIORITY_BUDGET_ROUTER=${CODED_PRIORITY_BUDGET_ROUTER:-off}"



# ============================================================
# M10.84A Fleet Analytics Runtime
# ============================================================

ANALYTICS_ENABLED="${CODED_ANALYTICS:-0}"

if [ "$ANALYTICS_ENABLED" = "1" ]; then

  echo "[CODED_ANALYTICS] enabled"

  ANALYTICS_API="${CODED_ANALYTICS_API:-https://api.codedonqubic.com/analytics}"
  ANALYTICS_TOKEN="${CODED_ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}"

  RIG_ID="${CODED_RIG_ID:-$(hostname)}"

  RUN_ID="M1084_${RIG_ID}_$(date +%Y%m%d_%H%M%S)"

  CPU_MODEL="$(lscpu | grep "Model name" | sed "s/.*: *//" | head -1)"
  CPU_THREADS="$(nproc)"
  RAM_MB="$(free -m | awk "/Mem:/ {print $2}")"

  AVX2_SUPPORTED=false
  AVX512_SUPPORTED=false

  grep -m1 flags /proc/cpuinfo | grep -qw avx2 && AVX2_SUPPORTED=true
  grep -m1 flags /proc/cpuinfo | grep -qw avx512f && AVX512_SUPPORTED=true

  HUGEPAGES_TOTAL="$(grep HugePages_Total /proc/meminfo | awk "{print \$2}")"
  HUGEPAGES_FREE="$(grep HugePages_Free /proc/meminfo | awk "{print \$2}")"

  export RUN_ID

  curl -s -X POST "${ANALYTICS_API}/runs/start" \
    -H "Authorization: Bearer ${ANALYTICS_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{
      \"run_id\":\"${RUN_ID}\",
      \"rig_id\":\"${RIG_ID}\",
      \"worker_name\":\"${WORKER}\",
      \"miner_version\":\"m10.84a\",
      \"backend\":\"${CODED_KERNEL_BACKEND}\",
      \"threshold\":${CODED_FAST_SHADOW_THRESHOLD},
      \"threads\":${THREADS},
      \"batch_size\":${CODED_BATCH_SIZE},
      \"audit_rate\":${CODED_FAST_SHADOW_AUDIT_RATE},
      \"gate_mode\":\"single\",
      \"hostname\":\"$(hostname)\",
      \"cpu_model\":\"${CPU_MODEL}\",
      \"cpu_threads\":${CPU_THREADS},
      \"ram_mb\":${RAM_MB},
      \"avx2_supported\":${AVX2_SUPPORTED},
      \"avx512_supported\":${AVX512_SUPPORTED},
      \"hugepages_total\":${HUGEPAGES_TOTAL:-0},
      \"hugepages_free\":${HUGEPAGES_FREE:-0},
      \"hardware\":{
        \"cpu_model\":\"${CPU_MODEL}\",
        \"cpu_threads\":${CPU_THREADS},
        \"ram_mb\":${RAM_MB},
        \"avx2\":${AVX2_SUPPORTED},
        \"avx512\":${AVX512_SUPPORTED}
      }
    }" >/dev/null || true

  echo "[CODED_ANALYTICS] RUN_ID=${RUN_ID}"

  # M10.86 Statistical Fleet Analysis bridge
  # Flightsheet stays simple: CODED_ANALYTICS=YES
  # This enables score-distribution upload without adding extra HiveOS fields.
  ANALYTICS_BASE="${API%/analytics}"

  export CODED_SCORE_DIST_UPLOAD=1
  export CODED_ANALYTICS_URL="${CODED_ANALYTICS_URL:-${ANALYTICS_BASE}}"
  export CODED_ANALYTICS_INGEST_TOKEN="${CODED_ANALYTICS_INGEST_TOKEN:-${TOKEN}}"
  export CODED_RUN_ID="${CODED_RUN_ID:-${RUN_ID}}"
  export CODED_RIG_ID="${CODED_RIG_ID:-${RIG_ID:-$(hostname)}}"
  export CODED_WORKER_NAME="${CODED_WORKER_NAME:-${WORKER_NAME:-$(hostname)}}"

  echo "[CODED_ANALYTICS] M10.86 score distribution upload enabled"
  echo "[CODED_ANALYTICS] SCORE_DIST_URL=${CODED_ANALYTICS_URL}/analytics/score-distribution"

fi


LOG_DIR="/var/log/miner/coded-miner"
LOG_FILE="$LOG_DIR/coded-miner.log"

mkdir -p "$LOG_DIR"
touch "$LOG_FILE"

if [ "${CODED_ANALYTICS:-}" = "YES" ] || [ "${CODED_ANALYTICS:-}" = "1" ]; then
  
# ============================================================


# M10.91A Always-On Runtime Supervisor
# Goal:
# - Never leave rigs idle.
# - If no experiment command is active, run a deterministic fallback profile.
# - Analytics rigs use analytics_baseline as fallback.
# - Production rigs use production fallback.
# - Experiment commands may interrupt fallback, then agent resumes fallback.

coded_bool_yes() {
  case "${1:-}" in
    1|yes|YES|true|TRUE|on|ON) return 0 ;;
    *) return 1 ;;
  esac
}

coded_infer_default_threshold() {
  case "${RIG_ID:-}" in
    Rig1X3D) echo "509" ;;
    Rig3X) echo "509" ;;
    Rig5X3D) echo "511" ;;
    Rig6X3D) echo "511" ;;
    *) echo "${CODED_DEFAULT_THRESHOLD:-510}" ;;
  esac
}

coded_default_mode() {
  if coded_bool_yes "${CODED_ANALYTICS:-}"; then
    echo "analytics_baseline"
  else
    echo "production"
  fi
}

coded_default_worker() {
  local T
  T="$(coded_infer_default_threshold)"
  if coded_bool_yes "${CODED_ANALYTICS:-}"; then
    echo "${RIG_ID}_BASELINE_ANALYTICS_T${T}"
  else
    echo "${RIG_ID}_PROD_T${T}"
  fi
}

coded_default_profile_json() {
  local T MODE WORKER HOURS THREADS BATCH AUDIT
  T="$(coded_infer_default_threshold)"
  MODE="$(coded_default_mode)"
  WORKER="$(coded_default_worker)"
  HOURS="${CODED_FALLBACK_HOURS:-8760}"
  THREADS="${THREADS:-${COMMAND_THREADS:-${CODED_THREADS:-${CODED_SAFE_THREADS:-24}}}}"
  BATCH="${CODED_BATCH_SIZE:-4000}"
  AUDIT="${CODED_AUDIT_RATE:-500}"

  jq -nc \
    --arg mode "$MODE" \
    --arg worker_name "$WORKER" \
    --argjson threshold "$T" \
    --argjson hours "$HOURS" \
    --argjson threads "$THREADS" \
    --argjson batch_size "$BATCH" \
    --argjson audit_rate "$AUDIT" \
    '{mode:$mode,worker_name:$worker_name,threshold:$threshold,hours:$hours,threads:$threads,batch_size:$batch_size,audit_rate:$audit_rate,resume_after:true,fallback:true}'
}


# M10.91B Fleet Idle Fallback
# In fleet mode, if there is no pending command and no miner process,
# create a fallback start_run command so the existing command runner starts
# the deterministic baseline/production worker instead of idling.
coded_has_miner_process() {
  pgrep -f "$MINER_BIN" >/dev/null 2>&1 && return 0

# ============================================================
# M10.96G8O start_run command params override
# ============================================================
# Backend G8N converts git_experiment_run into a direct start_run.
# For these experiment start_runs, command params are runtime truth.
# They must override default analytics profile/fallback values.
coded_apply_start_run_params_override() {
  local raw="${CMD:-${COMMAND_JSON:-}}"

  if [ -z "$raw" ]; then
    return 0
  fi

  local ctype
  ctype="$(echo "$raw" | jq -r '.command.command_type // .command_type // empty' 2>/dev/null || true)"
  if [ "$ctype" != "start_run" ]; then
    return 0
  fi

  local handoff profile_source priority source_type
  handoff="$(echo "$raw" | jq -r '.command.params.backend_handoff // .params.backend_handoff // empty' 2>/dev/null || true)"
  profile_source="$(echo "$raw" | jq -r '.command.params.profile_source // .params.profile_source // empty' 2>/dev/null || true)"
  priority="$(echo "$raw" | jq -r '.command.params.priority // .params.priority // empty' 2>/dev/null || true)"
  source_type="$(echo "$raw" | jq -r '.command.params.source_command_type // .params.source_command_type // empty' 2>/dev/null || true)"

  if [ "$handoff" != "M10.96G8N" ] && [ "$profile_source" != "git_experiment_run_backend_handoff" ] && [ "$priority" != "experiment" ] && [ "$source_type" != "git_experiment_run" ]; then
    return 0
  fi

  local exp_worker exp_threads exp_threshold exp_batch exp_audit exp_backend exp_hours exp_id
  exp_worker="$(echo "$raw" | jq -r '.command.params.worker_name // .params.worker_name // empty' 2>/dev/null || true)"
  exp_threads="$(echo "$raw" | jq -r '.command.params.threads // .params.threads // empty' 2>/dev/null || true)"
  exp_threshold="$(echo "$raw" | jq -r '.command.params.threshold // .params.threshold // empty' 2>/dev/null || true)"
  exp_batch="$(echo "$raw" | jq -r '.command.params.batch_size // .params.batch_size // empty' 2>/dev/null || true)"
  exp_audit="$(echo "$raw" | jq -r '.command.params.audit_rate // .params.audit_rate // empty' 2>/dev/null || true)"
  exp_backend="$(echo "$raw" | jq -r '.command.params.backend // .params.backend // "avx512"' 2>/dev/null || true)"
  exp_hours="$(echo "$raw" | jq -r '.command.params.hours // .params.hours // empty' 2>/dev/null || true)"
  exp_id="$(echo "$raw" | jq -r '.command.params.experiment_id // .params.experiment_id // empty' 2>/dev/null || true)"

  if [ -n "$exp_worker" ] && [ "$exp_worker" != "null" ]; then RUN_WORKER="$exp_worker"; fi
  if [ -n "$exp_threads" ] && [ "$exp_threads" != "null" ]; then THREADS="$exp_threads"; fi
  if [ -n "$exp_threshold" ] && [ "$exp_threshold" != "null" ]; then THRESHOLD="$exp_threshold"; fi
  if [ -n "$exp_batch" ] && [ "$exp_batch" != "null" ]; then BATCH_SIZE="$exp_batch"; fi
  if [ -n "$exp_audit" ] && [ "$exp_audit" != "null" ]; then AUDIT_RATE="$exp_audit"; fi
  if [ -n "$exp_backend" ] && [ "$exp_backend" != "null" ]; then BACKEND="$exp_backend"; fi
  if [ -n "$exp_hours" ] && [ "$exp_hours" != "null" ]; then HOURS="$exp_hours"; fi

  export CODED_KERNEL_BACKEND="$BACKEND"
  export CODED_FAST_SHADOW_THRESHOLD="$THRESHOLD"
  export CODED_BATCH_SIZE="$BATCH_SIZE"
  export CODED_FAST_SHADOW_AUDIT_RATE="$AUDIT_RATE"

  echo "$RUN_WORKER" > "/tmp/coded_expected_worker_${RIG_ID:-unknown}.txt" 2>/dev/null || true

  echo "[M10.96G8O_START_RUN_PARAMS_OVERRIDE] command_id=${COMMAND_ID:-unknown} worker=$RUN_WORKER threads=$THREADS threshold=$THRESHOLD batch=$BATCH_SIZE audit=$AUDIT_RATE backend=$BACKEND hours=${HOURS:-} experiment_id=$exp_id handoff=$handoff source=$profile_source priority=$priority" | tee -a "${RUN_LOG:-/tmp/coded_m1096g8o.log}"
}

coded_enforce_expected_worker_before_launch() {
  local expected_file="/tmp/coded_expected_worker_${RIG_ID:-unknown}.txt"
  if [ -f "$expected_file" ]; then
    local expected
    expected="$(cat "$expected_file" 2>/dev/null || true)"
    if [ -n "$expected" ] && [ "$RUN_WORKER" != "$expected" ]; then
      echo "[M10.96G8O_START_RUN_PARAMS_OVERRIDE] correcting RUN_WORKER before launch old=$RUN_WORKER expected=$expected" | tee -a "${RUN_LOG:-/tmp/coded_m1096g8o.log}"
      RUN_WORKER="$expected"
    fi
  fi
}

  pgrep -f "coded-miner.*--worker" >/dev/null 2>&1 && return 0
  return 1
}

coded_ensure_fleet_idle_fallback() {


  if coded_has_miner_process; then
    return 0
  fi

  local NOW LAST
  NOW="$(date +%s)"
  LAST="${CODED_LAST_FALLBACK_ENQUEUE_TS:-0}"

  if [ $((NOW - LAST)) -lt "${CODED_FALLBACK_ENQUEUE_COOLDOWN:-60}" ]; then
    return 0
  fi

  CODED_LAST_FALLBACK_ENQUEUE_TS="$NOW"
  export CODED_LAST_FALLBACK_ENQUEUE_TS

  local PARAMS MODE WORKER
  PARAMS="$(coded_default_profile_json)"
  MODE="$(echo "$PARAMS" | jq -r '.mode // "production"')"
  WORKER="$(echo "$PARAMS" | jq -r '.worker_name // empty')"

  echo "[M10.91B_FLEET_IDLE] no miner process detected; enqueue fallback mode=$MODE worker=$WORKER"

  curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":$PARAMS}" >/dev/null || true
}



# M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF
# A top-level git_experiment_run must never remain only picked_up.
# It is an orchestration command: convert it into a concrete start_run command,
# then complete this git_experiment_run. Runtime truth remains miner_run_dashboard.
coded_m1099z156_handle_git_experiment_run() {
  local command_id="${1:-}"
  local params="${2:-{}}"

  if [ -z "$command_id" ]; then
    echo "[M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF] missing command_id" | tee -a "${RUN_LOG:-/tmp/coded_m1099z156.log}"
    return 2
  fi

  if [ -z "$params" ] || [ "$params" = "null" ]; then
    params="{}"
  fi

  local worker threshold experiment_id duration_minutes duration_hours threads batch audit run_id start_command_id start_params create_resp create_ok api_root
  api_root="${CODED_API_ROOT:-${API:-http://127.0.0.1:4000}}"

  worker="$(echo "$params" | jq -r '.worker_name // .worker // empty' 2>/dev/null || true)"
  threshold="$(echo "$params" | jq -r '.threshold // .env.CODED_FAST_SHADOW_THRESHOLD // empty' 2>/dev/null || true)"
  experiment_id="$(echo "$params" | jq -r '.experiment_id // empty' 2>/dev/null || true)"
  duration_minutes="$(echo "$params" | jq -r '.duration_minutes // empty' 2>/dev/null || true)"
  duration_hours="$(echo "$params" | jq -r '.duration_hours // .hours // empty' 2>/dev/null || true)"
  threads="$(echo "$params" | jq -r '.threads // 31' 2>/dev/null || echo 31)"
  batch="$(echo "$params" | jq -r '.batch_size // 4000' 2>/dev/null || echo 4000)"
  audit="$(echo "$params" | jq -r '.audit_rate // .env.CODED_FAST_SHADOW_AUDIT_RATE // 500' 2>/dev/null || echo 500)"
  run_id="$(echo "$params" | jq -r '.run_id // empty' 2>/dev/null || true)"

  if [ -z "$duration_hours" ] || [ "$duration_hours" = "null" ]; then
    if [ -n "$duration_minutes" ] && [ "$duration_minutes" != "null" ]; then
      duration_hours="$(awk "BEGIN { printf \"%.6f\", (${duration_minutes}+0)/60 }" 2>/dev/null || echo "0.083333")"
    else
      duration_hours="0.083333"
      duration_minutes="5"
    fi
  fi

  if [ -z "$duration_minutes" ] || [ "$duration_minutes" = "null" ]; then
    duration_minutes="$(awk "BEGIN { printf \"%d\", (${duration_hours}+0)*60 }" 2>/dev/null || echo "5")"
  fi

  if [ -z "$worker" ] || [ -z "$threshold" ] || [ -z "$experiment_id" ]; then
    local err="M10.99Z156 missing required params worker=$worker threshold=$threshold experiment_id=$experiment_id"
    echo "[M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF] FAILED $err command=$command_id params=$params" | tee -a "${RUN_LOG:-/tmp/coded_m1099z156.log}"
    coded_fail_command "$command_id" "$err" "{\"marker\":\"M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF\",\"status\":\"failed_missing_required_params\"}" || true
    return 3
  fi

  echo "[M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF] claim-to-start command=$command_id exp=$experiment_id worker=$worker threshold=$threshold minutes=$duration_minutes" | tee -a "${RUN_LOG:-/tmp/coded_m1099z156.log}"

  coded_mark_command_running "$command_id" || true

  start_command_id="cmd_$(date +%s%3N)_z156_$(tr -dc a-z0-9 </dev/urandom | head -c 6)"
  start_params="$(echo "$params" | jq -c \
    --arg marker "M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF" \
    --arg mode "experiment_runtime" \
    --arg worker "$worker" \
    --argjson threshold "$threshold" \
    --arg duration_minutes "$duration_minutes" \
    --arg duration_hours "$duration_hours" \
    --arg source_command_id "$command_id" \
    '. + {
      marker:$marker,
      mode:$mode,
      command_source:"git_experiment_run_direct_handoff",
      source_command_id:$source_command_id,
      worker_name:$worker,
      worker:$worker,
      threshold:$threshold,
      duration_minutes:($duration_minutes|tonumber),
      duration_hours:($duration_hours|tonumber),
      hours:($duration_hours|tonumber),
      resume_default_after:true,
      resume_after:true
    }' 2>/dev/null || echo "{}")"

  if [ "$start_params" = "{}" ] || [ -z "$start_params" ]; then
    local err="M10.99Z156 failed to build start_run params"
    echo "[M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF] FAILED $err command=$command_id" | tee -a "${RUN_LOG:-/tmp/coded_m1099z156.log}"
    coded_fail_command "$command_id" "$err" "{\"marker\":\"M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF\",\"status\":\"failed_param_build\"}" || true
    return 4
  fi

  create_resp="$(jq -n \
    --arg command_id "$start_command_id" \
    --arg rig_id "${RIG_ID:-${CODED_RIG_ID:-unknown}}" \
    --argjson params "$start_params" \
    '{
      command_id:$command_id,
      rig_id:$rig_id,
      command_type:"start_run",
      status:"pending",
      requested_by:"m1099z156_git_experiment_direct_handoff",
      params:$params
    }' | curl -s -X POST "$api_root/analytics/commands/create" \
      -H "Authorization: Bearer ${TOKEN:-${CODED_API_TOKEN:-}}" \
      -H "Content-Type: application/json" \
      -d @- 2>/dev/null || true)"

  create_ok="$(echo "$create_resp" | jq -r '.ok // .success // empty' 2>/dev/null || true)"

  echo "[M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF] start_run_create_resp command=$command_id start_command=$start_command_id resp=$create_resp" | tee -a "${RUN_LOG:-/tmp/coded_m1099z156.log}"

  if echo "$create_resp" | grep -qiE '"error"|false|unauthorized|forbidden'; then
    local err="M10.99Z156 start_run create failed"
    coded_fail_command "$command_id" "$err" "{\"marker\":\"M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF\",\"status\":\"failed_start_run_create\",\"create_response\":$create_resp}" || true
    return 5
  fi

  coded_complete_command_id "$command_id" "{\"marker\":\"M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF\",\"status\":\"completed_start_run_enqueued\",\"experiment_id\":\"$experiment_id\",\"worker_name\":\"$worker\",\"threshold\":$threshold,\"start_run_command_id\":\"$start_command_id\",\"create_response\":$create_resp}" || true
  echo "[M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF] completed command=$command_id start_run=$start_command_id exp=$experiment_id" | tee -a "${RUN_LOG:-/tmp/coded_m1099z156.log}"

  return 0
}


coded_mark_command_running() {
  local command_id="$1"
  curl -s -X POST "$CODED_API_ROOT/commands/$command_id/running" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{}" >/dev/null || true
}

coded_command_heartbeat_bg() {
  local command_id="$1"
  local build_log="$2"
  (
    while true; do
      curl -s -X POST "$CODED_API_ROOT/commands/$command_id/heartbeat" \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "{}" >/dev/null || true
      echo "[M10.97B4_HEARTBEAT] command=$command_id ts=$(date -u +%FT%TZ)" >> "$build_log"
      sleep 30
    done
  ) &
  echo $!
}

coded_resume_default_after_gitexp() {


  local reason="${1:-git_experiment_resume_default}"
  local params
  params="$(coded_default_profile_json)"
  curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":$params}" >/dev/null || true
  echo "[M10.96G2_RESUME_DEFAULT] reason=$reason params=$params"
}


coded_run_profile() {
  local PARAMS RUN_MODE RUN_WORKER RUN_THRESHOLD RUN_HOURS RUN_THREADS RUN_BATCH RUN_AUDIT RUN_ID RUN_LOG
  PARAMS="$1"

  RUN_MODE="$(echo "$PARAMS" | jq -r '.mode // "experiment"')"
  RUN_WORKER="$(echo "$PARAMS" | jq -r '.worker_name // empty')"
  RUN_THRESHOLD="$(echo "$PARAMS" | jq -r '.threshold // empty')"
  RUN_HOURS="$(echo "$PARAMS" | jq -r '.hours // 24')"
  RUN_THREADS="$(echo "$PARAMS" | jq -r '.threads // empty')"
  RUN_BATCH="$(echo "$PARAMS" | jq -r '.batch_size // 4000')"
  RUN_AUDIT="$(echo "$PARAMS" | jq -r '.audit_rate // 500')"

  [ -z "$RUN_WORKER" ] && RUN_WORKER="$(coded_default_worker)"
  [ -z "$RUN_THRESHOLD" ] && RUN_THRESHOLD="$(coded_infer_default_threshold)"
  [ -z "$RUN_THREADS" ] && RUN_THREADS="${THREADS:-${COMMAND_THREADS:-${CODED_THREADS:-${CODED_SAFE_THREADS:-24}}}}"

  RUN_ID="M1091_${RIG_ID}_T${RUN_THRESHOLD}_$(date -u +%Y%m%d_%H%M%S)"
  RUN_LOG="$LOG_DIR/${RUN_ID}.log"  # M10.95A unified fleet run log path

  echo "[M10.91A_SUPERVISOR] start_profile mode=$RUN_MODE rig=$RIG_ID worker=$RUN_WORKER threshold=$RUN_THRESHOLD threads=$RUN_THREADS hours=$RUN_HOURS batch=$RUN_BATCH audit=$RUN_AUDIT run_id=$RUN_ID"

  curl -s -X POST "$API/runs/start" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"threshold\":$RUN_THRESHOLD,\"threads\":$RUN_THREADS,\"batch_size\":$RUN_BATCH,\"audit_rate\":$RUN_AUDIT,\"milestone\":\"M10.91A\",\"params\":$PARAMS}" >/dev/null || true

  CODED_RUNTIME_MODE="$RUN_MODE" \
  CODED_RUN_ID="$RUN_ID" \
  CODED_RUN_WORKER="$RUN_WORKER" \
  CODED_THRESHOLD="$RUN_THRESHOLD" \
  CODED_BATCH_SIZE="$RUN_BATCH" \
  CODED_AUDIT_RATE="$RUN_AUDIT" \
      coded_apply_start_run_params_override || true
    # M10.99Z191_POST_OVERRIDE_START_RUN_RUNTIME_HANDOFF_CALL
    coded_z191_start_run_post_override_handoff "after_coded_apply_start_run_params_override" || true
      coded_enforce_expected_worker_before_launch || true
  "$MINER_BIN" \
    --pool "$POOL" \
    --wallet "$WALLET" \
    --worker "$RUN_WORKER" \
    --threads "$RUN_THREADS" > "$RUN_LOG" 2>&1 &

  MINER_PID=$!

  echo "[M10.91A_SUPERVISOR] miner_pid=$MINER_PID worker=$RUN_WORKER log=$RUN_LOG"

  # Start analytics uploader if existing function/path exists later in file.
  # The existing M10.89/M10.90 uploader loop reads RUN_LOG variables in command mode.
  # For now, keep process supervision here and let normal log ingestion continue where supported.

  local END_TS
  # ============================================================
  # M10.96G8AG float-safe RUN_HOURS duration
  # ============================================================
  RUN_DURATION_SEC="$(awk -v h="${RUN_HOURS:-24}" 'BEGIN { if (h <= 0) h = 24; printf "%d", h * 3600 }' 2>/dev/null || echo 86400)"
  [ -z "$RUN_DURATION_SEC" ] && RUN_DURATION_SEC=86400
  [ "$RUN_DURATION_SEC" -lt 60 ] 2>/dev/null && RUN_DURATION_SEC=60
  END_TS=$(( $(date +%s) + RUN_DURATION_SEC ))
  echo "[M10.96G8AG_RUN_HOURS_DURATION] run_hours=${RUN_HOURS:-} duration_sec=$RUN_DURATION_SEC"
  if [ -n "${PARAMS:-}" ]; then coded_m1099k_apply_duration_override "$PARAMS" || true; fi
  # M10.99Z22_EARLY_ROUTER_FINALIZER
  if [ -n "${PARAMS:-}" ]; then
    coded_m1099m_export_params_env "$PARAMS" "${RUN_LOG:-/tmp/coded_m1099m_env_forwarding.log}" || true
    coded_m1099z22_finalize_priority_router_intent "$PARAMS" "${RUN_LOG:-/tmp/coded_m1099z22_router_finalizer.log}" || true
  fi
  while kill -0 "$MINER_PID" 2>/dev/null; do
    # Fallback/default runs can be interrupted by high priority commands.
    # Experiment runs can also be interrupted by stop/build commands.
    if coded_check_interrupt_command; then
      echo "[M10.91A_SUPERVISOR] interrupt type=$INTERRUPT_TYPE pid=$MINER_PID worker=$RUN_WORKER"
      kill "$MINER_PID" 2>/dev/null || true
      sleep 2
      kill -9 "$MINER_PID" 2>/dev/null || true
      wait "$MINER_PID" 2>/dev/null || true
      return 90
    fi

    if [ "$(date +%s)" -ge "$END_TS" ]; then
      echo "[M10.91A_SUPERVISOR] profile duration completed mode=$RUN_MODE worker=$RUN_WORKER"
      kill "$MINER_PID" 2>/dev/null || true
      wait "$MINER_PID" 2>/dev/null || true
      curl -s -X POST "$API/runs/end" \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"run_id\":\"$RUN_ID\",\"status\":\"completed\",\"end_reason\":\"profile_duration_completed\"}" >/dev/null || true
      return 0
    fi

    sleep 10
  done

  echo "[M10.91A_SUPERVISOR] miner process exited mode=$RUN_MODE worker=$RUN_WORKER pid=$MINER_PID"
  curl -s -X POST "$API/runs/end" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"run_id\":\"$RUN_ID\",\"status\":\"completed\",\"end_reason\":\"miner_process_exited\"}" >/dev/null || true

  return 0
}

# M10.90A Interruptible Fleet Agent
# ============================================================
# During long start_run mining loops, periodically check whether
# a high-priority control command is pending. This prevents
# release builds from requiring manual SSH restarts.
#
# Supported interrupt command types:
# - stop_run

# M10.99W4_FORCE_RELEASE_COMMAND_FIRST

# M1091M_HIVE_RELEASE_BUILDER_RIG5_NODELESS_FIX
# HiveOS builder path must not depend on node. Use python3 for JSON payloads.
m1091m_json_payload_running() {
  local cid="${1:-}"
  python3 - "$cid" <<'PYJSON'
import sys,json,datetime
cid=sys.argv[1] if len(sys.argv)>1 else ""
print(json.dumps({
  "command_id": cid,
  "marker": "M1091M_HIVE_RELEASE_BUILDER_RIG5_NODELESS_FIX",
  "lease_minutes": 60,
  "started_at": datetime.datetime.utcnow().isoformat()+"Z"
}))
PYJSON
}

m1091m_json_payload_complete() {
  local cid="${1:-}"
  local payload="${2:-{}}"
  python3 - "$cid" "$payload" <<'PYJSON'
import sys,json
cid=sys.argv[1] if len(sys.argv)>1 else ""
raw=sys.argv[2] if len(sys.argv)>2 else "{}"
try:
  p=json.loads(raw or "{}")
except Exception:
  p={"raw": raw}
p["command_id"]=cid
print(json.dumps(p))
PYJSON
}

m1091m_json_get_builder_rig() {
  local raw="${1:-{}}"
  python3 - <<'PYJSON' "$raw"
import sys,json,os
raw=sys.argv[1] if len(sys.argv)>1 else "{}"
try:
  j=json.loads(raw or "{}")
except Exception:
  j={}
d=j.get("command") or j.get("data") or j
p=d.get("params") or {}
env=p.get("env") or {}
val = (
  p.get("builder_rig_id")
  or p.get("release_builder_rig_id")
  or p.get("selected_builder_rig_id")
  or env.get("CODED_RELEASE_BUILDER_RIG_ID")
  or env.get("CODED_BUILDER_RIG_ID")
  or env.get("RELEASE_BUILDER_RIG_ID")
  or env.get("BUILDER_RIG_ID")
  or os.environ.get("CODED_RELEASE_BUILDER_RIG_ID")
  or os.environ.get("CODED_BUILDER_RIG_ID")
  or os.environ.get("RELEASE_BUILDER_RIG_ID")
  or os.environ.get("BUILDER_RIG_ID")
  or "Rig2X3D"
)
print(val)
PYJSON
}


# M1091N_W4_MARK_FUNCTIONS_NODELESS
# Replace remaining node -e usage in W4 command status helpers.
m1091n_json_payload_fail() {
  local cid="${1:-}"
  local err="${2:-failed}"
  python3 - "$cid" "$err" <<'PYJSON'
import sys,json,datetime
cid=sys.argv[1] if len(sys.argv)>1 else ""
err=sys.argv[2] if len(sys.argv)>2 else "failed"
print(json.dumps({
  "command_id": cid,
  "marker": "M1091N_W4_MARK_FUNCTIONS_NODELESS",
  "error": err,
  "failed_at": datetime.datetime.utcnow().isoformat()+"Z"
}))
PYJSON
}

m1091n_json_payload_release_success() {
  local version="${1:-}"
  local artifact="${2:-}"
  local latest_alias="${3:-}"
  local build_log="${4:-}"
  local cid="${5:-}"
  local rig="${6:-unknown}"
  local ctype="${7:-build_hive_release}"
  python3 - "$version" "$artifact" "$latest_alias" "$build_log" "$cid" "$rig" "$ctype" <<'PYJSON'
import sys,json
version,artifact,latest,log,cid,rig,ctype=(sys.argv[1:8]+[""]*7)[:7]
print(json.dumps({
  "command_id": cid,
  "result": {
    "status": "success",
    "release": version,
    "version": version,
    "artifact": artifact,
    "latest_alias": latest,
    "log": log,
    "repo": "CodedOnQubic/coded-miner-release",
    "builder": rig,
    "command_type": ctype,
    "marker": "M1091N_W4_MARK_FUNCTIONS_NODELESS",
    "artifacts": [latest, artifact, "SHA256SUMS", "release_manifest.json"]
  }
}))
PYJSON
}

# Release commands must be exclusive and must be handled before default analytics fallback.
# This block is intentionally self-contained so release build cannot get stuck in picked_up.
m1099w4_json_get() {
  node -e '
    const obj = JSON.parse(process.argv[1] || "{}");
    const path = String(process.argv[2] || "").split(".");
    let v = obj;
    for (const p of path) v = v && Object.prototype.hasOwnProperty.call(v,p) ? v[p] : undefined;
    if (v === undefined || v === null) process.exit(0);
    if (typeof v === "object") process.stdout.write(JSON.stringify(v));
    else process.stdout.write(String(v));
  ' "$1" "$2" 2>/dev/null || true
}

m1099w4_api_post_json() {
  local path="$1"
  local json="${2:-{}}"
  local base="${POOL_API_URL:-${CODED_POOL_API_URL:-${API:-http://127.0.0.1:4000}}}"
  base="${base%/}"
  curl -fsS -m 20 \
    -H "Authorization: Bearer ${CODED_ANALYTICS_TOKEN:-${ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}}" \
    -H "Content-Type: application/json" \
    -X POST "$base$path" \
    --data "$json" 2>/dev/null || true
}

m1099w4_mark_running() {
  local cid="${1:-}"
  local payload
  payload="$(m1091m_json_payload_running "$cid")"
  m1099w4_api_post_json "/analytics/commands/$cid/running" "$payload" >/dev/null || true
  m1099w4_api_post_json "/analytics/commands/running" "$payload" >/dev/null || true
}

m1099w4_mark_complete() {
  local cid="${1:-}"
  local payload="${2:-{}}"
  local wrapped
  wrapped="$(m1091m_json_payload_complete "$cid" "$payload")"
  m1099w4_api_post_json "/analytics/commands/$cid/complete" "$payload" >/dev/null || true
  m1099w4_api_post_json "/analytics/commands/complete" "$wrapped" >/dev/null || true
}

m1099w4_mark_fail() {
  local cid="${1:-}"
  local err="${2:-failed}"
  local payload
  payload="$(m1091n_json_payload_fail "$cid" "$err")"
  m1099w4_api_post_json "/analytics/commands/$cid/fail" "$payload" >/dev/null || true
  m1099w4_api_post_json "/analytics/commands/fail" "$payload" >/dev/null || true
}


# M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL
# Robust release-builder helpers. The old W4 path used git@github SSH and
# could falsely complete even when release upload failed.
m1099z53_repo_url() {
  local slug="$1"
  local mode="${2:-read}"
  local token="${CODED_RELEASE_GITHUB_TOKEN:-${GITHUB_TOKEN:-}}"
  local token_file="${CODED_RELEASE_GITHUB_TOKEN_FILE:-/root/.coded/github_release_token}"

  if [ -z "$token" ] && [ -f "$token_file" ]; then
    token="$(tr -d '\r\n ' < "$token_file" 2>/dev/null || true)"
  fi

  if [ "$mode" = "write" ]; then
    if [ -z "$token" ]; then
      echo ""
      return 1
    fi
    echo "https://x-access-token:${token}@github.com/${slug}.git"
    return 0
  fi

  if [ -n "$token" ]; then
    echo "https://x-access-token:${token}@github.com/${slug}.git"
  else
    echo "https://github.com/${slug}.git"
  fi
}

m1099z53_clone_retry() {
  local url="$1"
  local dir="$2"
  local label="$3"
  local max_attempts="${4:-5}"
  local attempt=1

  while [ "$attempt" -le "$max_attempts" ]; do
    rm -rf "$dir"
    echo "[M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL] clone label=$label attempt=$attempt/$max_attempts dir=$dir"
    if git clone --depth 1 "$url" "$dir"; then
      echo "[M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL] clone ok label=$label"
      return 0
    fi
    echo "[M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL] clone failed label=$label attempt=$attempt"
    attempt=$((attempt+1))
    sleep 3
  done

  echo "[M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL] ERROR clone exhausted label=$label"
  return 51
}

m1099z53_verify_file() {
  local file="$1"
  local label="$2"
  if [ ! -s "$file" ]; then
    echo "[M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL] ERROR missing/empty $label file=$file"
    return 52
  fi
  return 0
}

m1099w4_handle_release_command_first() {
  echo "[M10.99Z55_FORCE_RELEASE_BUILDER_EXECUTE] Z55 W4 handler entered release_builder_only=$(coded_z54_release_builder_only_enabled && echo yes || echo no)"
  if coded_z54_release_builder_only_enabled; then
    echo "[M10.99Z54_RELEASE_BUILDER_MODE_AND_HRUN_SHIM] release-builder-only mode active before W4 handler"
  fi

# M10.99W4_RELEASE_GUARD
# If a release command is active for this rig, do not enqueue/start default analytics.
# This prevents release builds from being overwritten by fallback/default runtime.
m1099w4_release_guard_active() {
  local base="${POOL_API_URL:-${CODED_POOL_API_URL:-${API:-http://127.0.0.1:4000}}}"
  base="${base%/}"
  local rig="${RIG_ID:-${WORKER_RIG_ID:-${HOSTNAME:-unknown}}}"
  local out
  out="$(curl -fsS -m 15 \
    -H "Authorization: Bearer ${CODED_ANALYTICS_TOKEN:-${ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}}" \
    "$base/analytics/commands/active?rig_id=$rig" 2>/dev/null || true)"
  echo "$out" | grep -qE 'build_hive_release|build_release'
}


  # M10.99Z57B_FORCE_COMMAND_SHAPE_AND_HANDLER_CONTEXT
  # M1091M: cid/raw must be available before builder-rig parsing.
  local type="${COMMAND_TYPE:-${CMD_TYPE:-}}"
  local cid="${COMMAND_ID:-${CMD_ID:-}}"
  local raw="${COMMAND_RAW:-${CMD_RAW:-{}}}"
  echo "[M10.99Z57B_FORCE_COMMAND_SHAPE_AND_HANDLER_CONTEXT] handler context type=${type:-} cid=${cid:-} raw_prefix=$(echo "$raw" | head -c 180)"

  # M10.99Z61_BUILDER_ONLY_NO_NODE_API_FIX
  # M1091M_HIVE_RELEASE_BUILDER_RIG5_NODELESS_FIX
  # build_hive_release is allowed only on the selected builder rig.
  if [ "${type:-}" = "build_hive_release" ]; then
    builder_rig="$(m1091m_json_get_builder_rig "$raw")"
    this_rig="${RIG_ID:-${CODED_RIG_ID:-$(hostname 2>/dev/null || echo unknown)}}"
    if [ "$this_rig" != "$builder_rig" ]; then
      echo "[M10.99Z61_BUILDER_ONLY_NO_NODE_API_FIX] skip build_hive_release on non-builder rig=$this_rig builder=$builder_rig cid=${cid:-}"
      return 0
    fi
    echo "[M10.99Z61_BUILDER_ONLY_NO_NODE_API_FIX] builder accepted rig=$this_rig builder=$builder_rig cid=${cid:-}"
  fi

  if [ "$type" != "build_hive_release" ] && [ "$type" != "build_release" ]; then
    return 1
  fi

  local params version artifact latest_alias build_log branch repo release_repo target work root build_dir out_dir release_dir expected_commit actual_commit manifest_version
  params="$(m1099w4_json_get "$raw" "params")"
  [ -z "$params" ] && params="{}"

  version="$(m1099w4_json_get "$params" "version")"
  [ -z "$version" ] && version="$(m1099w4_json_get "$params" "version_prefix")"
  [ -z "$version" ] && version="v0.7.2-m1099w4-$(date -u +%Y%m%d%H%M%S)"

  artifact="$(m1099w4_json_get "$params" "artifact_name")"
  [ -z "$artifact" ] && artifact="$(m1099w4_json_get "$params" "artifact")"
  # M10.99Z234_RELEASE_BUILDER_EXPECTED_OUTPUT_GATE
  # Safety: frontend Build Release passes params.version + params.expected_commit.
  # The builder must fail hard if the produced artifact does not match exactly.
  expected_commit="$(m1099w4_json_get "$params" "expected_commit")"
  [ -z "$expected_commit" ] && expected_commit="$(m1099w4_json_get "$params" "source_commit")"
  [ -z "$artifact" ] && artifact="coded-miner-hive-linux-amd64-avx512-${version}.tar.gz"

  latest_alias="$(m1099w4_json_get "$params" "latest_alias")"
  [ -z "$latest_alias" ] && latest_alias="coded-miner-latest.tar.gz"

  branch="$(m1099w4_json_get "$params" "branch")"
  [ -z "$branch" ] && branch="main"

  repo="$(m1099w4_json_get "$params" "repo")"
  [ -z "$repo" ] && repo="CodedOnQubic/coded-miner"

  release_repo="$(m1099w4_json_get "$params" "release_repo")"
  [ -z "$release_repo" ] && release_repo="CodedOnQubic/coded-miner-release"

  target="$(m1099w4_json_get "$params" "target")"
  [ -z "$target" ] && target="hive-linux-amd64-avx512"

  build_log="$(m1099w4_json_get "$params" "build_log")"
  [ -z "$build_log" ] && build_log="/tmp/coded_hive_release_${version}.log"

  mkdir -p "$(dirname "$build_log")"
  : > "$build_log"

  {
    echo "[M10.99W4_RELEASE_COMMAND_FIRST] begin command=$cid type=$type version=$version target=$target branch=$branch repo=$repo release_repo=$release_repo"
    echo "[M10.99W4_RELEASE_COMMAND_FIRST] log=$build_log artifact=$artifact latest_alias=$latest_alias"
    date -u
  } >> "$build_log" 2>&1

  m1099w4_mark_running "$cid"

  (
    set -euo pipefail

    export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
    export CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx512}"
    export CODED_KERNEL_ACTIVATION="${CODED_KERNEL_ACTIVATION:-prefer_requested}"
    export CODED_KERNEL_ALLOW_FALLBACK="${CODED_KERNEL_ALLOW_FALLBACK:-1}"

    work="/tmp/coded_hive_release_work_${version}"
    root="$work/coded-miner"
    build_dir="$root/build-release"
    out_dir="$work/out"
    release_dir="$work/coded-miner-release"

    rm -rf "$work"
    mkdir -p "$work" "$out_dir"

    echo "[M10.99W4_RELEASE_COMMAND_FIRST] clone coded-miner branch=$branch"
    if [ -d "/hive/codedonqubic/.git" ]; then
      git -C /hive/codedonqubic fetch origin "$branch"
      git -C /hive/codedonqubic reset --hard "origin/$branch"
      cp -a /hive/codedonqubic "$root"
    else
      src_url="$(m1099z53_repo_url "$repo" "read")"
      m1099z53_clone_retry "$src_url" "$root" "coded-miner" 5
      git -C "$root" fetch origin "$branch"
      git -C "$root" checkout "$branch"
      git -C "$root" reset --hard "origin/$branch"
    fi

    commit="$(git -C "$root" rev-parse HEAD)"
    echo "[M10.99W4_RELEASE_COMMAND_FIRST] coded-miner commit=$commit"

    # M10.99Z234_RELEASE_BUILDER_EXPECTED_OUTPUT_GATE
    if [ -n "${expected_commit:-}" ]; then
      echo "[M10.99Z234_RELEASE_BUILDER_EXPECTED_OUTPUT_GATE] checkout expected_commit=$expected_commit"
      git -C "$root" fetch origin "$expected_commit" || true
      git -C "$root" checkout "$expected_commit"
      commit="$(git -C "$root" rev-parse --short=12 HEAD)"
      actual_commit="$(git -C "$root" rev-parse HEAD)"
      echo "[M10.99Z234_RELEASE_BUILDER_EXPECTED_OUTPUT_GATE] actual_commit=$actual_commit short=$commit"
      case "$actual_commit" in
        "$expected_commit"* ) ;;
        * )
          echo "[M10.99Z234_RELEASE_BUILDER_EXPECTED_OUTPUT_GATE] ERROR expected_commit_mismatch expected=$expected_commit actual=$actual_commit"
          return 234
          ;;
      esac
    fi

    bash -n "$root/release/hiveos/coded-miner/start.sh"

    echo "[M10.99W4_RELEASE_COMMAND_FIRST] configure/build"
    cmake -S "$root" -B "$build_dir" \
      -DCMAKE_BUILD_TYPE=Release \
      -DCODED_ENABLE_AVX2=ON \
      -DCODED_ENABLE_AVX512=ON

    # M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL
    # Build the production miner target only. Full all-target build can fail on
    # optional tests while coded-miner itself is valid.
    cmake --build "$build_dir" --target coded-miner -j"$(nproc)"

    miner_bin="$(find "$build_dir" "$root" -type f -name coded-miner -perm -111 | head -n1)"
    if [ -z "$miner_bin" ]; then
      echo "[M10.99W4_RELEASE_COMMAND_FIRST] ERROR coded-miner binary not found"
      exit 21
    fi

    echo "[M10.99W4_RELEASE_COMMAND_FIRST] miner_bin=$miner_bin"

    pkg="$out_dir/coded-miner"
    mkdir -p "$pkg"

    # M10.99Z59D_CLEAN_HIVE_PACKAGING_BLOCK
    # Hive package must contain exactly the runtime payload Hive expects.
    cp -a "$miner_bin" "$pkg/coded-miner"
    cp -a "$root/release/hiveos/coded-miner/start.sh" "$pkg/start.sh"
    cp -a "$root/release/hiveos/coded-miner/h-run.sh" "$pkg/h-run.sh"

    chmod +x "$pkg/coded-miner" "$pkg/start.sh" "$pkg/h-run.sh"

    echo "[M10.99Z59D_CLEAN_HIVE_PACKAGING_BLOCK] package payload:"
    ls -lah "$pkg"

    cat > "$pkg/release_manifest.json" <<EOF
{
  "version": "$version",
  "target": "$target",
  "repo": "$repo",
  "branch": "$branch",
  "commit": "$commit",
  "built_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "builder_rig_id": "${RIG_ID:-unknown}",
  "marker": "M10.99W4_FORCE_RELEASE_COMMAND_FIRST"
}
EOF


    tar -czf "$out_dir/$artifact" -C "$out_dir" coded-miner
    cp "$out_dir/$artifact" "$out_dir/$latest_alias"
    (cd "$out_dir" && sha256sum "$artifact" "$latest_alias" > SHA256SUMS)
    # M10.99Z234_RELEASE_BUILDER_EXPECTED_OUTPUT_GATE
    manifest_version="$(python3 - <<PY2
import json
with open("$pkg/release_manifest.json","r",encoding="utf-8") as f:
    print(json.load(f).get("version",""))
PY2
)"
    actual_commit="$(git -C "$root" rev-parse HEAD 2>/dev/null || true)"

    echo "[M10.99Z234_RELEASE_BUILDER_EXPECTED_OUTPUT_GATE] expected_version=$version manifest_version=$manifest_version expected_commit=${expected_commit:-unset} actual_commit=${actual_commit:-unset}"

    if [ -z "$manifest_version" ] || [ "$manifest_version" != "$version" ]; then
      echo "[M10.99Z234_RELEASE_BUILDER_EXPECTED_OUTPUT_GATE] ERROR version_mismatch expected=$version actual=$manifest_version"
      return 235
    fi

    if [ -n "${expected_commit:-}" ]; then
      case "$actual_commit" in
        "$expected_commit"* ) ;;
        * )
          echo "[M10.99Z234_RELEASE_BUILDER_EXPECTED_OUTPUT_GATE] ERROR commit_mismatch expected=$expected_commit actual=$actual_commit"
          return 236
          ;;
      esac
    fi

    if echo "$manifest_version" | grep -q "v0.7.2-m1099w4"; then
      echo "[M10.99Z234_RELEASE_BUILDER_EXPECTED_OUTPUT_GATE] ERROR legacy_w4_version_blocked version=$manifest_version"
      return 237
    fi

    cp "$pkg/release_manifest.json" "$out_dir/release_manifest.json"

    echo "[M10.99W4_RELEASE_COMMAND_FIRST] artifact=$(ls -lh "$out_dir/$artifact")"
    echo "[M10.99W4_RELEASE_COMMAND_FIRST] sha256:"
    cat "$out_dir/SHA256SUMS"

    echo "[M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL] clone release repo=$release_repo"
    release_url="$(m1099z53_repo_url "$release_repo" "write")"
    if [ -z "$release_url" ]; then
      echo "[M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL] ERROR CODED_RELEASE_GITHUB_TOKEN missing; cannot push release repo"
      exit 53
    fi

    m1099z53_clone_retry "$release_url" "$release_dir" "coded-miner-release" 5

    cp "$out_dir/$artifact" "$release_dir/$artifact"
    cp "$out_dir/$latest_alias" "$release_dir/$latest_alias"
    cp "$out_dir/SHA256SUMS" "$release_dir/SHA256SUMS"
    cp "$out_dir/release_manifest.json" "$release_dir/release_manifest.json"

    m1099z53_verify_file "$release_dir/$artifact" "$artifact"
    m1099z53_verify_file "$release_dir/$latest_alias" "$latest_alias"
    m1099z53_verify_file "$release_dir/SHA256SUMS" "SHA256SUMS"
    m1099z53_verify_file "$release_dir/release_manifest.json" "release_manifest.json"

    git -C "$release_dir" config user.email "release-bot@codedonqubic.com"
    git -C "$release_dir" config user.name "CODED Release Builder"
    git -C "$release_dir" add "$artifact" "$latest_alias" SHA256SUMS release_manifest.json
    git -C "$release_dir" commit -m "Release $version" || echo "[M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL] no release repo changes to commit"

    local_commit="$(git -C "$release_dir" rev-parse HEAD)"
    echo "[M10.99Z59E_RELEASE_PUSH_RETRY_NONBLOCKING] pushing release repo local_commit=$local_commit"

    push_ok=0
    if git -C "$release_dir" push; then
      push_ok=1
    else
      echo "[M10.99Z59E_RELEASE_PUSH_RETRY_NONBLOCKING] initial push failed; retrying with fetch/rebase"
      git -C "$release_dir" fetch origin main || true
      git -C "$release_dir" pull --rebase origin main || true
      if git -C "$release_dir" push; then
        push_ok=1
      fi
    fi

    git -C "$release_dir" fetch origin main || true
    remote_commit="$(git -C "$release_dir" rev-parse origin/main 2>/dev/null || echo unknown)"
    local_commit="$(git -C "$release_dir" rev-parse HEAD 2>/dev/null || echo unknown)"
    echo "[M10.99Z59E_RELEASE_PUSH_RETRY_NONBLOCKING] remote_commit=$remote_commit local_commit=$local_commit push_ok=$push_ok"

    if [ "$push_ok" != "1" ]; then
      echo "[M10.99Z59E_RELEASE_PUSH_RETRY_NONBLOCKING] WARNING release repo branch push failed; continuing to GitHub Releases/latest publish because Hive pulls release assets"
    fi

    # M10.99Z58_BUILDER_PUBLISH_GITHUB_LATEST_RELEASE
    # Repo branch push is not enough for HiveOS. Hive pulls releases/latest/download/coded-miner-latest.tar.gz.
    m1099z58_publish_github_latest_release "$version" "$artifact" "$latest_alias" "$out_dir" "$release_repo"

    # M10.99Z59D_CLEAN_HIVE_PACKAGING_BLOCK
    echo "[M10.99Z59D_CLEAN_HIVE_PACKAGING_BLOCK] verify latest tar contains h-run.sh"
    tar -tzf "$out_dir/$latest_alias" | grep -qE '(^|/)h-run\.sh$' || {
      echo "[M10.99Z59D_CLEAN_HIVE_PACKAGING_BLOCK] ERROR h-run.sh missing from $latest_alias"
      tar -tzf "$out_dir/$latest_alias" | sed -n '1,120p'
      exit 595
    }

    echo "[M10.99Z53_RELEASE_BUILDER_HTTPS_HARDFAIL] completed version=$version artifact=$artifact latest_alias=$latest_alias"
  ) >> "$build_log" 2>&1

  local rc=$?
  if [ "$rc" -eq 0 ]; then
    local payload
        # M1091O_RELEASE_SUCCESS_PAYLOAD_NODELESS - HiveOS has no node; build success payload with python3 helper
    payload="$(m1091n_json_payload_release_success "$version" "$artifact" "$latest_alias" "$build_log" "$cid" "${RIG_ID:-unknown}" "$type")"
    m1099w4_mark_complete "$cid" "$payload"
    return 0
  else
    echo "[M10.99W4_RELEASE_COMMAND_FIRST] failed rc=$rc command=$cid" >> "$build_log"
    m1099w4_mark_fail "$cid" "release build failed rc=$rc; see $build_log"
    return "$rc"
  fi
}


# - build_hive_release
# - build_release  (alias, generic future-proof name)

coded_check_interrupt_command() {
  # M10.99W4D_REBUILD_NEXT_INTERRUPT_RELEASE_PATH
  # This function was rebuilt after W4B/W4C left an orphan env-forwarding
  # loop and broke bash syntax near `done`.
  #
  # Release commands must be executed immediately inside the interrupt path.
  # They must not be requeued for a later top-level pass because HiveOS can
  # start default mining in between and leave build_hive_release stuck in
  # picked_up with an empty /tmp/coded_hive_release_*.log.

  local api="${API:-${POOL_API_URL:-${CODED_POOL_API_URL:-http://127.0.0.1:4000}}}"
  local token="${TOKEN:-${CODED_ANALYTICS_TOKEN:-${ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}}}"
  local rig="${RIG_ID:-${WORKER_RIG_ID:-${HOSTNAME:-unknown}}}"
  local resp type cmd_json command_id lifecycle_id next_type

  api="${api%/}"

  resp="$(curl -fsS -m 20 "$api/commands/next-interrupt/$rig" \
    -H "Authorization: Bearer $token" 2>/dev/null || true)"

  type="$(echo "$resp" | jq -r '.command.command_type // .command.type // .command_type // .type // empty' 2>/dev/null || true)"

  if [ -z "$type" ] || [ "$type" = "null" ]; then
    return 1
  fi

  cmd_json="$(echo "$resp" | jq -c '.command // .' 2>/dev/null || echo "$resp")"
  command_id="$(echo "$cmd_json" | jq -r '.command_id // empty' 2>/dev/null || true)"
  lifecycle_id="$(echo "$cmd_json" | jq -r '.id // .lifecycle_id // empty' 2>/dev/null || true)"

  case "$type" in
    build_hive_release|build_release)
      # M10.99W4D_REBUILD_NEXT_INTERRUPT_RELEASE_PATH
      # Execute release immediately and exclusively.
      export COMMAND_TYPE="$type"
      export COMMAND_ID="$command_id"
      export CMD_TYPE="$type"
      export CMD_ID="$command_id"
      export COMMAND_JSON="$cmd_json"
      export CMD_JSON="$cmd_json"

      echo "[M10.99W4D_REBUILD_NEXT_INTERRUPT_RELEASE_PATH] command=$command_id type=$type executing release handler now" | tee -a "${RUN_LOG:-/tmp/coded_release_guard.log}" 2>/dev/null || true

      if command -v m1099w4_handle_release_command_first >/dev/null 2>&1; then
        m1099w4_handle_release_command_first
        exit $?
      fi

      echo "[M10.99W4D_REBUILD_NEXT_INTERRUPT_RELEASE_PATH] ERROR m1099w4_handle_release_command_first missing" | tee -a "${RUN_LOG:-/tmp/coded_release_guard.log}" 2>/dev/null || true
      exit 44
      ;;

    stop_run)
      next_type="$(echo "$cmd_json" | jq -r '.params.next_command_type // empty' 2>/dev/null || true)"
      echo "[M10.99W4D_REBUILD_NEXT_INTERRUPT_RELEASE_PATH] stop_run command=$command_id next=$next_type" | tee -a "${RUN_LOG:-/tmp/coded_release_guard.log}" 2>/dev/null || true

      if [ -n "${MINER_PID:-}" ] && kill -0 "$MINER_PID" 2>/dev/null; then
        kill "$MINER_PID" 2>/dev/null || true
        sleep 2
      fi

      if command -v coded_complete_command >/dev/null 2>&1; then
        coded_complete_command "$lifecycle_id" "{\"status\":\"stopped\",\"marker\":\"M10.99W4D_REBUILD_NEXT_INTERRUPT_RELEASE_PATH\",\"next_type\":\"$next_type\"}" || true
      elif command -v coded_finish_command >/dev/null 2>&1; then
        coded_finish_command "$lifecycle_id" "{\"status\":\"stopped\",\"marker\":\"M10.99W4D_REBUILD_NEXT_INTERRUPT_RELEASE_PATH\",\"next_type\":\"$next_type\"}" || true
      fi

      exit 0
      ;;

    *)
      echo "[M10.99W4D_REBUILD_NEXT_INTERRUPT_RELEASE_PATH] unsupported interrupt type=$type command=$command_id" | tee -a "${RUN_LOG:-/tmp/coded_release_guard.log}" 2>/dev/null || true
      return 1
      ;;
  esac
}



# ============================================================
# M10.99O_CODED_ENV_DEBUG
# ------------------------------------------------------------
# Print final CODED_* environment directly before coded-miner starts.
# This must run in the same shell context as the miner launch.
# ============================================================
coded_m1099o_debug_env_before_launch() {
  local worker="${1:-unknown}"
  local run_log="${2:-/tmp/coded_m1099o_env_debug.log}"

  echo "[M10.99O_CODED_ENV_DEBUG] before_launch worker=$worker" | tee -a "$run_log"
  echo "[CODED_ENV_DEBUG] CODED_PRIORITY_BUDGET_ROUTER=${CODED_PRIORITY_BUDGET_ROUTER:-unset}" | tee -a "$run_log"

  env | grep -E '^CODED_' | sort | sed 's/^/[CODED_ENV_DEBUG] /' | tee -a "$run_log" || true
}



# ============================================================


# M10.99Z22_PRIORITY_ROUTER_INTENT_FINALIZER
# Final safety layer: explicit command intent must win over old shell defaults.
# If worker/experiment says M1098E, final runtime env must be M1098E.
coded_m1099z22_finalize_priority_router_intent() {
  local params_json="${1:-}"
  local run_log="${2:-/tmp/coded_m1099z22_router_finalizer.log}"

  local worker=""
  local exp_id=""
  local env_router=""
  local direct_router=""
  local lower_router=""
  local resolved=""

  if [ -n "$params_json" ]; then
    worker="$(echo "$params_json" | jq -r '.worker_name // .worker // empty' 2>/dev/null || true)"
    exp_id="$(echo "$params_json" | jq -r '.experiment_id // empty' 2>/dev/null || true)"
    env_router="$(echo "$params_json" | jq -r '.env.CODED_PRIORITY_BUDGET_ROUTER // empty' 2>/dev/null || true)"
    direct_router="$(echo "$params_json" | jq -r '.CODED_PRIORITY_BUDGET_ROUTER // empty' 2>/dev/null || true)"
    lower_router="$(echo "$params_json" | jq -r '.priority_budget_router // empty' 2>/dev/null || true)"
  fi

  if [ -n "$env_router" ] && [ "$env_router" != "null" ]; then
    resolved="$env_router"
  elif [ -n "$direct_router" ] && [ "$direct_router" != "null" ]; then
    resolved="$direct_router"
  elif [ -n "$lower_router" ] && [ "$lower_router" != "null" ]; then
    resolved="$lower_router"
  else
    resolved="${CODED_PRIORITY_BUDGET_ROUTER:-}"
  fi

  case "${worker} ${exp_id}" in
    *M1098E*|*m1098e*)
      resolved="M1098E"
      ;;
    *M1098D*|*m1098d*)
      resolved="M1098D"
      ;;
    *M1098C*|*m1098c*)
      if [ "$resolved" != "M1098E" ] && [ "$resolved" != "M1098D" ]; then
        resolved="M1098C"
      fi
      ;;
  esac

  if [ -z "$resolved" ] || [ "$resolved" = "null" ]; then
    resolved="M1098C"
  fi

  export CODED_PRIORITY_BUDGET_ROUTER="$resolved"

  echo "[M10.99Z22_PRIORITY_ROUTER_INTENT_FINALIZER] worker=${worker:-unknown} experiment_id=${exp_id:-} env_router=${env_router:-} direct_router=${direct_router:-} lower_router=${lower_router:-} final=${CODED_PRIORITY_BUDGET_ROUTER}" | tee -a "$run_log" 2>/dev/null || true
}

# M10.99Q_PRIORITY_ROUTER_RESOLVER
# ------------------------------------------------------------
# Final priority budget router resolver.
# M10.99P proved final launch hook is correct, but PARAMS.env can be
# missing by the time start_run is picked. Therefore resolve from:
# - params.env.CODED_PRIORITY_BUDGET_ROUTER
# - params.CODED_PRIORITY_BUDGET_ROUTER / params.priority_budget_router
# - worker_name / experiment_id containing M1098D
# - otherwise existing env/default M1098C
# ============================================================
coded_m1099q_resolve_priority_budget_router() {
  local params_json="${1:-}"
  local worker="${2:-}"
  local run_log="${3:-/tmp/coded_m1099q_priority_router.log}"

  local env_router=""
  local direct_router=""
  local lower_router=""
  local exp_id=""
  local resolved=""

  if [ -n "$params_json" ]; then
    env_router="$(echo "$params_json" | jq -r '.env.CODED_PRIORITY_BUDGET_ROUTER // empty' 2>/dev/null || true)"
    direct_router="$(echo "$params_json" | jq -r '.CODED_PRIORITY_BUDGET_ROUTER // empty' 2>/dev/null || true)"
    lower_router="$(echo "$params_json" | jq -r '.priority_budget_router // .router // empty' 2>/dev/null || true)"
    exp_id="$(echo "$params_json" | jq -r '.experiment_id // empty' 2>/dev/null || true)"
  fi

  if [ -n "$env_router" ] && [ "$env_router" != "null" ]; then
    resolved="$env_router"
  elif [ -n "$direct_router" ] && [ "$direct_router" != "null" ]; then
    resolved="$direct_router"
  elif [ -n "$lower_router" ] && [ "$lower_router" != "null" ]; then
    resolved="$lower_router"
  elif echo "${worker:-} ${exp_id:-}" | grep -q "M1098D"; then
    resolved="M1098D"
  elif echo "${worker:-} ${exp_id:-}" | grep -q "M1098C"; then
    resolved="M1098C"
  else
    resolved="${CODED_PRIORITY_BUDGET_ROUTER:-M1098C}"
  fi

  export CODED_PRIORITY_BUDGET_ROUTER="$resolved"

  echo "[M10.99Q_PRIORITY_ROUTER_RESOLVER] worker=${worker:-unknown} experiment_id=${exp_id:-} env_router=${env_router:-} direct_router=${direct_router:-} lower_router=${lower_router:-} resolved=$CODED_PRIORITY_BUDGET_ROUTER" | tee -a "$run_log"
}


# M10.97B5_2_1_RUNTIME_HELPERS
# ------------------------------------------------------------
# Safety helpers used by newer start_run paths. These must exist
# before any default/experiment launch branch calls them.
# ============================================================
coded_apply_start_run_params_override() {
  return 0
}

coded_enforce_expected_worker_before_launch() {
  local expected_worker="${EXPECTED_WORKER_NAME:-${DESIRED_WORKER_NAME:-}}"
  local actual_worker="${WORKER_NAME:-${WORKER:-}}"

  if [ -n "$expected_worker" ] && [ -n "$actual_worker" ] && [ "$expected_worker" != "$actual_worker" ]; then
    echo "[M10.97B5.2.1_WORKER_GUARD] mismatch expected=$expected_worker actual=$actual_worker"
    return 1
  fi

  return 0
}


coded_complete_command_id() {
  local CID="$1"
  local RESULT="${2:-{}}"
  [ -z "$CID" ] && return 0
  curl -s -X POST "$CODED_API_ROOT/commands/$CID/complete" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"result\":$RESULT}" >/dev/null || true
}



# ============================================================
# M10.90B Robust Release Builder
# ============================================================


# M10.99Z12_DURATION_PRODUCTIVE_RUNTIME_GUARD
# Normalize runtime duration. duration_sec is authoritative, then
# duration_minutes, then hours. This prevents hours=0 from ending
# experiment runs that correctly carry duration_sec=7200.
coded_m1099z12_normalize_duration_from_params() {
  local params="$1"
  local duration_sec duration_minutes hours

  duration_sec="$(echo "$params" | jq -r '.duration_sec // .durationSec // empty' 2>/dev/null || true)"
  duration_minutes="$(echo "$params" | jq -r '.duration_minutes // .durationMinutes // empty' 2>/dev/null || true)"
  hours="$(echo "$params" | jq -r '.hours // empty' 2>/dev/null || true)"

  if [ -n "$duration_sec" ] && [ "$duration_sec" != "null" ] && [ "$duration_sec" != "0" ]; then
    RUN_DURATION_SEC="$(printf '%.0f' "$duration_sec" 2>/dev/null || echo "$RUN_DURATION_SEC")"
  elif [ -n "$duration_minutes" ] && [ "$duration_minutes" != "null" ] && [ "$duration_minutes" != "0" ]; then
    RUN_DURATION_SEC="$(awk "BEGIN { printf \\"%.0f\\", $duration_minutes * 60 }" 2>/dev/null || echo "$RUN_DURATION_SEC")"
  elif [ -n "$hours" ] && [ "$hours" != "null" ] && [ "$hours" != "0" ]; then
    RUN_DURATION_SEC="$(awk "BEGIN { printf \\"%.0f\\", $hours * 3600 }" 2>/dev/null || echo "$RUN_DURATION_SEC")"
  fi

  if [ -z "${RUN_DURATION_SEC:-}" ] || [ "$RUN_DURATION_SEC" = "0" ]; then
    RUN_DURATION_SEC=1800
  fi

  echo "[M10.99Z12_DURATION_PRODUCTIVE_RUNTIME_GUARD] normalized_duration_sec=$RUN_DURATION_SEC params_duration_sec=${duration_sec:-} params_duration_minutes=${duration_minutes:-} params_hours=${hours:-}" | tee -a "${RUN_LOG:-/tmp/coded_fleet_duration.log}" >/dev/null 2>&1 || true
}



# M10.99Z17C_RELEASE_RESUME_AGENT
# Enqueue a start_run after release build finishes, using params.resume_start_run_params.
coded_m1099z17c_enqueue_resume_after_release() {
  local build_cmd_json="$1"
  local resume_params
  resume_params="$(echo "$build_cmd_json" | jq -c '.command.params.resume_start_run_params // empty' 2>/dev/null || true)"

  if [ -z "$resume_params" ] || [ "$resume_params" = "null" ]; then
    echo "[M10.99Z17C_RELEASE_RESUME_AGENT] no resume_start_run_params present; fallback default analytics may run" >> "${RUN_LOG:-/tmp/coded_release_resume.log}" 2>/dev/null || true
    return 1
  fi

  local worker
  worker="$(echo "$resume_params" | jq -r '.worker_name // empty' 2>/dev/null || true)"

  local payload
  payload="$(cat <<JSON
{"rig_id":"$RIG_ID","command_type":"start_run","requested_by":"release_resume_agent","params":$resume_params}
JSON
)"

  echo "[M10.99Z17C_RELEASE_RESUME_AGENT] enqueue resume start_run worker=$worker rig=$RIG_ID" | tee -a "${RUN_LOG:-/tmp/coded_release_resume.log}" 2>/dev/null || true

  curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "$payload" >> "${RUN_LOG:-/tmp/coded_release_resume.log}" 2>&1 || true
}

coded_fail_command() {
  local CID="$1"
  local ERR="$2"
  local RESULT="${3:-{}}"

  [ -z "$CID" ] && return 0

  curl -s -X POST "$CODED_API_ROOT/commands/$CID/fail" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"error\":\"$ERR\",\"result\":$RESULT}" >/dev/null || true
}

coded_complete_command() {
  local CID="$1"
  local RESULT="${2:-{}}"

  [ -z "$CID" ] && return 0

  curl -s -X POST "$CODED_API_ROOT/commands/$CID/complete" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"result\":$RESULT}" >/dev/null || true
}

# ============================================================
# M10.94A Strict Release Command Completion
# ============================================================
# Release builds are operator-critical. A successful public release must
# always finalize the command as completed/success, otherwise the admin
# dashboard shows a false picked_up/stale release.
coded_complete_release_command_strict() {
  local command_id="$1"
  local version="$2"
  local build_log="$3"
  local command_type="$4"
  local payload resp ok status attempt

  payload="{\"command_id\":\"$command_id\",\"result\":{\"status\":\"success\",\"release\":\"$version\",\"version\":\"$version\",\"log\":\"$build_log\",\"repo\":\"CodedOnQubic/coded-miner-release\",\"github_release\":\"https://github.com/CodedOnQubic/coded-miner-release/releases/tag/$version\",\"artifacts\":[\"coded-miner-latest.tar.gz\",\"coded-miner-docker-linux-amd64.tar.gz\"],\"validation\":\"ok\",\"builder\":\"$RIG_ID\",\"command_type\":\"$command_type\",\"auto_finalized\":\"M10.94A\"}}"

  for attempt in 1 2 3 4 5; do
    resp="$(curl -s -X POST "$CODED_API_ROOT/commands/$command_id/complete" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "$payload" || true)"

    ok="$(echo "$resp" | jq -r '.ok // false' 2>/dev/null || echo false)"
    status="$(echo "$resp" | jq -r '.data.status // .command.status // empty' 2>/dev/null || true)"

    echo "[M10.94A_RELEASE_COMPLETE] attempt=$attempt command=$command_id version=$version ok=$ok status=$status resp=$resp" | tee -a "$build_log"

    if [ "$ok" = "true" ] || [ "$status" = "completed" ]; then
      return 0
    fi

    sleep 2
  done

  return 1
}


coded_release_guard() {
  local VERSION="$1"
  local BUILD_LOG="$2"
  local RELEASE_REPO_DIR="/hive/coded-miner-release"

  echo "[M10.90B_RELEASE] validating release version=$VERSION" >> "$BUILD_LOG"

  if [ ! -f "$RELEASE_REPO_DIR/coded-miner-latest.tar.gz" ]; then
    echo "[M10.90B_RELEASE][ERROR] missing coded-miner-latest.tar.gz" >> "$BUILD_LOG"
    return 11
  fi

  if [ ! -s "$RELEASE_REPO_DIR/coded-miner-latest.tar.gz" ]; then
    echo "[M10.90B_RELEASE][ERROR] empty coded-miner-latest.tar.gz" >> "$BUILD_LOG"
    return 12
  fi

  if [ -f "$RELEASE_REPO_DIR/coded-miner-docker-linux-amd64.tar.gz" ] && [ ! -s "$RELEASE_REPO_DIR/coded-miner-docker-linux-amd64.tar.gz" ]; then
    echo "[M10.90B_RELEASE][ERROR] empty docker tarball" >> "$BUILD_LOG"
    return 13
  fi

  (
    cd "$RELEASE_REPO_DIR" || exit 14
    echo "[M10.90B_RELEASE] git status before final check:" >> "$BUILD_LOG"
    git status --short >> "$BUILD_LOG" 2>&1 || exit 15
    echo "[M10.90B_RELEASE] latest commits:" >> "$BUILD_LOG"
    git log --oneline -5 >> "$BUILD_LOG" 2>&1 || exit 16
  )

  echo "[M10.90B_RELEASE] validation ok version=$VERSION" >> "$BUILD_LOG"
  return 0
}


# ============================================================
# M10.93A Local Runtime State
# ============================================================
# Purpose:
# - make CODED_ANALYTICS=YES rigs self-healing
# - remember default profile / active profile locally
# - allow restart/reboot recovery without entering the rig
# - prepare experiment/build pause/resume semantics

CODED_STATE_FILE="${CODED_STATE_FILE:-/hive/codedonqubic/.coded-fleet-state.json}"

coded_json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

coded_state_write() {
  local state="$1"
  mkdir -p "$(dirname "$CODED_STATE_FILE")" 2>/dev/null || true
  printf '%s\n' "$state" > "$CODED_STATE_FILE" 2>/dev/null || true
}

coded_state_show() {
  if [ -f "$CODED_STATE_FILE" ]; then
    cat "$CODED_STATE_FILE" 2>/dev/null || true
  else
    echo "{}"
  fi
}

coded_state_set_active_profile() {
  local run_id="$1"
  local command_id="$2"
  local worker_name="$3"
  local mode="$4"
  local threshold="$5"
  local hours="$6"
  local threads="$7"
  local batch_size="$8"
  local audit_rate="$9"

  local now
  now="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

  coded_state_write "{\"rig_id\":\"$(coded_json_escape "$RIG_ID")\",\"state\":\"active\",\"active_run_id\":\"$(coded_json_escape "$run_id")\",\"active_command_id\":\"$(coded_json_escape "$command_id")\",\"active_worker\":\"$(coded_json_escape "$worker_name")\",\"active_profile\":{\"mode\":\"$(coded_json_escape "$mode")\",\"threshold\":${threshold:-510},\"hours\":${hours:-8760},\"threads\":${threads:-0},\"batch_size\":${batch_size:-4000},\"audit_rate\":${audit_rate:-500},\"worker_name\":\"$(coded_json_escape "$worker_name")\"},\"updated_at\":\"$now\"}"
}

coded_state_set_idle() {
  local reason="$1"
  local now
  now="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

  coded_state_write "{\"rig_id\":\"$(coded_json_escape "$RIG_ID")\",\"state\":\"idle\",\"reason\":\"$(coded_json_escape "$reason")\",\"updated_at\":\"$now\"}"
}

coded_default_threshold() {
  case "$RIG_ID" in
    Rig1X3D) echo "${CODED_DEFAULT_THRESHOLD:-508}" ;;
    Rig2X3D) echo "${CODED_DEFAULT_THRESHOLD:-509}" ;;
    Rig3X)   echo "${CODED_DEFAULT_THRESHOLD:-509}" ;;
    Rig4X)   echo "${CODED_DEFAULT_THRESHOLD:-510}" ;;
    Rig5X3D) echo "${CODED_DEFAULT_THRESHOLD:-509}" ;;
    Rig6X3D) echo "${CODED_DEFAULT_THRESHOLD:-510}" ;;
    *)       echo "${CODED_DEFAULT_THRESHOLD:-510}" ;;
  esac
}

coded_default_worker_name() {
  local t="$1"
  if [ -n "${CODED_DEFAULT_WORKER:-}" ]; then
    echo "$CODED_DEFAULT_WORKER"
  else
    echo "${RIG_ID}_DEFAULT_ANALYTICS_T${t}"
  fi
}

coded_has_miner_process() {
  pgrep -f "coded-miner.*--worker" >/dev/null 2>&1
}

coded_fetch_backend_default_profile() {
  curl -s "$API/fleet/default-profile/$RIG_ID" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" || true
}

coded_enqueue_default_analytics() {


  # M1091L_CANONICAL_DEFAULT_PROFILE
  # Temporary research workaround:
  # make the always-on default/fallback profile itself run M1091L canonical.
  # This avoids critical-command takeover gaps while M10.99Z25 takeover is still pending.

  local mode="z25_m1098e_321_hunt_default"
  local priority="normal"
  local source="M1091L_CANONICAL_DEFAULT_PROFILE"
  local t="510"
  local worker="$(m1091l_default_worker_for_rig "$RIG_ID")"
  local hours="${CODED_DEFAULT_HOURS:-12}"
  local threads="${CODED_DEFAULT_THREADS:-31}"
  local batch="${CODED_DEFAULT_BATCH_SIZE:-4000}"
  local audit="${CODED_DEFAULT_AUDIT_RATE:-500}"
  local router="$(m1091l_default_router_for_threshold "$t")"
  local matrix="$(m1091l_default_matrix_for_threshold "$t")"

  case "$RIG_ID" in
    Rig1X3D)
      t="509"
      worker="Rig1X3D_M1091B_REAL321_T508_DENSITY"
      ;;
    Rig2X3D)
      t="510"
      worker="Rig2X3D_M1091B_REAL321_T509_BIAS_BREAK"
      ;;
    Rig3X)
      t="509"
      worker="Rig3X_M1091B_REAL321_T509_BROAD"
      ;;
    Rig4X)
      t="510"
      worker="Rig4X_M1091B_REAL321_T510_BALANCED"
      ;;
    Rig5X3D)
      t="511"
      worker="Rig5X3D_M1091B_REAL321_T509_X3D"
      ;;
    Rig6X3D)
      t="511"
      worker="Rig6X3D_M1091B_REAL321_T510_BALANCED"
      ;;
  esac

  local payload
  payload="{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":{\"mode\":\"$mode\",\"experiment_id\":\"M1091L_CANONICAL_DEFAULT_ANALYTICS\",\"fallback\":true,\"resume_after\":true,\"priority\":\"$priority\",\"profile_source\":\"$source\",\"threshold\":$t,\"hours\":$hours,\"duration_hours\":$hours,\"threads\":$threads,\"batch_size\":$batch,\"audit_rate\":$audit,\"worker_name\":\"$worker\",\"worker\":\"$worker\",\"CODED_PRIORITY_BUDGET_ROUTER\":\"$router\",\"priority_budget_router\":\"$router\",\"env\":{\"CODED_PRIORITY_BUDGET_ROUTER\":\"$router\",\"CODED_PRIORITY_BUDGET_MATRIX\":\"$matrix\",\"CODED_ROUTER_MATRIX\":\"$matrix\",\"CODED_ANALYTICS\":\"YES\",\"CODED_PREFILTER_DIFFICULTY\":\"0\",\"CODED_FAST_SHADOW_GATE\":\"1\",\"CODED_FAST_SHADOW_THRESHOLD\":\"$t\",\"CODED_FAST_SHADOW_AUDIT_RATE\":\"500\",\"CODED_FAST_SHADOW_SUMMARY_SEC\":\"60\",\"CODED_KERNEL_BACKEND\":\"avx512\",\"CODED_KERNEL_ACTIVATION\":\"prefer_requested\",\"CODED_KERNEL_ALLOW_FALLBACK\":\"1\",\"CODED_SHADOW_AVX512_LIVE\":\"1\",\"CODED_SCORE_ALGO_MODE\":\"hyperidentity_only\"}}}"

  local resp
  resp="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "$payload" 2>/dev/null || true)"

  echo "[M1091L_CANONICAL_DEFAULT_PROFILE] enqueued canonical default rig=$RIG_ID worker=$worker threshold=$t router=$router matrix=$matrix resp=$resp"
}

coded_ensure_default_when_idle() {


  # If a miner process exists, do nothing. Runtime is source of truth.
  if coded_has_miner_process; then
    # M10.99Z49B_ENQUEUE_THEN_LAUNCH_LOCAL_FLEX
  # Enqueue alone leaves Hive screen idle. Immediately launch the same local
  # runtime after creating the fallback/default job.
  export RUN_WORKER="$worker"
  export WORKER_NAME="$worker"
  export THRESHOLD="$t"
  export THREADS="$threads"
  export CODED_THREADS="$threads"
  export CODED_FAST_SHADOW_THRESHOLD="$t"
  export CODED_FAST_SHADOW_AUDIT_RATE="$audit"
  export CODED_FAST_SHADOW_SUMMARY_SEC="60"
  export CODED_PRIORITY_BUDGET_ROUTER="$(m1091l_default_router_for_threshold "${CODED_FAST_SHADOW_THRESHOLD:-${THRESHOLD:-510}}")"
  export CODED_ANALYTICS="YES"
  echo "[M10.99Z49B_ENQUEUE_THEN_LAUNCH_LOCAL_FLEX] launching local fallback after enqueue worker=$RUN_WORKER threshold=$THRESHOLD threads=$THREADS"
  if coded_z54_release_builder_only_enabled; then echo "[M10.99Z55_FORCE_RELEASE_BUILDER_EXECUTE] suppress Z45 call in release-builder-only"; else coded_z45_never_idle_default_runtime || true; fi
  return 0
  fi

  # If a pending/running command exists, let the backend queue handle it.
  # This function is called only after a no-command poll.
  coded_enqueue_default_analytics
  return 0
}


echo "[CODED_FLEET] agent mode enabled"

  API="${CODED_ANALYTICS_API:-https://api.codedonqubic.com/analytics}"
  TOKEN="${CODED_ANALYTICS_TOKEN:-coded_analytics_ingest_2026_secure_token}"
  RIG_ID="${CODED_RIG_ID:-$(hostname)}"

  CPU_MODEL="$(lscpu | grep "Model name" | sed "s/.*: *//" | head -1)"
  CPU_THREADS="$(nproc)"
  RAM_MB="$(free -m | awk '/Mem:/ {print $2}')"
  AVX2=false
  AVX512=false
  grep -m1 flags /proc/cpuinfo | grep -qw avx2 && AVX2=true
  grep -m1 flags /proc/cpuinfo | grep -qw avx512f && AVX512=true
  HPT="$(grep HugePages_Total /proc/meminfo | awk "{print \$2}")"
  HPF="$(grep HugePages_Free /proc/meminfo | awk "{print \$2}")"

  curl -s -X POST "$API/rigs/register" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"rig_id\":\"$RIG_ID\",\"rig_name\":\"$RIG_ID\",\"hostname\":\"$(hostname)\",\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2_supported\":$AVX2,\"avx512_supported\":$AVX512,\"hugepages_total\":${HPT:-0},\"hugepages_free\":${HPF:-0},\"threads\":$THREADS}" || true

  echo "[CODED_FLEET] registered RIG_ID=$RIG_ID"
  
# M10.99Z55_FORCE_RELEASE_BUILDER_EXECUTE
# In release-builder-only mode, do not enter idle command wait after claiming a build_hive_release.
# Execute the active release handler immediately. This fixes picked_up-without-running.
if coded_z54_release_builder_only_enabled; then
  echo "[M10.99Z55_FORCE_RELEASE_BUILDER_EXECUTE] release-builder-only before fleet wait: executing release handler now"

  # M10.99Z56C_PREFETCH_COMMAND_BEFORE_RELEASE_HANDLER
  # The W4/Z53 release handler expects COMMAND_TYPE/COMMAND_ID/COMMAND_RAW to
  # already be populated by the normal command loop. In release-builder-only mode
  # we bypass that loop, so fetch the pending command here and export the context.
  echo "[M10.99Z56C_PREFETCH_COMMAND_BEFORE_RELEASE_HANDLER] fetching command before release handler rig=${RIG_ID:-}"
  Z56C_RAW="$(curl -sS -m 15 "${API:-https://api.codedonqubic.com}/commands/next/${RIG_ID:-}" -H "Authorization: Bearer ${TOKEN:-coded_analytics_ingest_2026_secure_token}" 2>/tmp/coded_z56c_fetch_error.log || true)"
  echo "[M10.99Z56C_PREFETCH_COMMAND_BEFORE_RELEASE_HANDLER] raw=$(echo "$Z56C_RAW" | head -c 900)"

  if [ -n "$Z56C_RAW" ]; then
    Z56C_TYPE="$(printf '%s' "$Z56C_RAW" | python3 -c 'import sys,json; j=json.load(sys.stdin); d=j.get("data") or j.get("command") or j; print(d.get("command_type") or d.get("type") or "")' 2>/dev/null || true)"
    Z56C_ID="$(printf '%s' "$Z56C_RAW" | python3 -c 'import sys,json; j=json.load(sys.stdin); d=j.get("data") or j.get("command") or j; print(d.get("command_id") or d.get("id") or "")' 2>/dev/null || true)"
    export COMMAND_TYPE="$Z56C_TYPE"
    export CMD_TYPE="$Z56C_TYPE"
    export COMMAND_ID="$Z56C_ID"
    export CMD_ID="$Z56C_ID"
    export COMMAND_RAW="$Z56C_RAW"
    export CMD_RAW="$Z56C_RAW"
    echo "[M10.99Z56C_PREFETCH_COMMAND_BEFORE_RELEASE_HANDLER] resolved type=$Z56C_TYPE id=$Z56C_ID"
  fi

  if command -v m1099w4_handle_release_command_first >/dev/null 2>&1; then
    if m1099w4_handle_release_command_first; then
      echo "[M10.99Z55_FORCE_RELEASE_BUILDER_EXECUTE] release handler completed/handled command"
      exit 0
    else
      RC=$?
      echo "[M10.99Z55_FORCE_RELEASE_BUILDER_EXECUTE] release handler returned rc=$RC; exiting to avoid idle mining/wait"
      exit "$RC"
    fi
  else
    echo "[M10.99Z55_FORCE_RELEASE_BUILDER_EXECUTE] ERROR m1099w4_handle_release_command_first missing"
    exit 55
  fi
fi

echo "[CODED_FLEET] waiting for backend commands"

  while true; do
    CMD="$(curl -s "$API/commands/next/$RIG_ID" -H "Authorization: Bearer $TOKEN" || true)"
    COMMAND_ID="$(echo "$CMD" | jq -r ".command.command_id // empty")"

    if [ -z "$COMMAND_ID" ]; then
      # M10.93A: If fleet mode is idle and no backend command exists,
      # ensure this rig always returns to a default analytics run.
      coded_ensure_default_when_idle
      sleep 30
      continue
    fi

    COMMAND_TYPE="$(echo "$CMD" | jq -r ".command.command_type // empty")"

      # M10.99Z156_GIT_EXPERIMENT_DIRECT_HANDOFF
      if [ "${COMMAND_TYPE:-}" = "git_experiment_run" ]; then
        PARAMS="$(echo "$CMD" | jq -c ".command.params // {}" 2>/dev/null || echo "{}")"
        COMMAND_LIFECYCLE_ID="${COMMAND_LIFECYCLE_ID:-$COMMAND_ID}"
        coded_m1099z156_handle_git_experiment_run "$COMMAND_LIFECYCLE_ID" "$PARAMS" || true
        continue
      fi

# M10.99W4_FORCE_RELEASE_COMMAND_FIRST
# Release commands must execute before any default/start_run path.
if m1099w4_handle_release_command_first; then
  exit 0
fi


    # M10.91B Fleet Idle Fallback Hook
    # If backend has no command and no miner is running, enqueue fallback.
    if [ -z "$COMMAND_TYPE" ] || [ "$COMMAND_TYPE" = "null" ]; then
      coded_ensure_fleet_idle_fallback
      sleep 5
      continue
    fi

    if [ "$COMMAND_TYPE" = "git_experiment_run" ]; then
      COMMAND_DB_ID="$(echo "$CMD" | jq -r ".command.id // .id // empty")"
      COMMAND_LIFECYCLE_ID="${COMMAND_DB_ID:-$COMMAND_ID}"
      echo "[M10.96G8C_GITEXP_DB_ID] command_id=$COMMAND_ID db_id=$COMMAND_DB_ID lifecycle_id=$COMMAND_LIFECYCLE_ID"


      # ============================================================
      # M10.97B5_TOP_LEVEL_DIRECT_ENQUEUE
      # ------------------------------------------------------------
      # git_experiment_run is a launcher/control command only.
      # For normal experiment runs (build_before_run != true), enqueue
      # a start_run immediately here, before legacy build/heartbeat flow.
      # ============================================================

      B5_BUILD_BEFORE_RUN="$(echo "$CMD" | jq -r '.command.params.build_before_run // .params.build_before_run // "false"' 2>/dev/null || echo "false")"

      if [ "$B5_BUILD_BEFORE_RUN" != "true" ]; then
        B5_WORKER_NAME="$(echo "$CMD" | jq -r '.command.params.worker_name // .params.worker_name // empty' 2>/dev/null || true)"
        B5_EXPERIMENT_ID="$(echo "$CMD" | jq -r '.command.params.experiment_id // .params.experiment_id // "M1097B5_EXPERIMENT"' 2>/dev/null || echo "M1097B5_EXPERIMENT")"
        B5_BACKEND="$(echo "$CMD" | jq -r '.command.params.backend // .params.backend // "avx512"' 2>/dev/null || echo "avx512")"
        B5_THRESHOLD="$(echo "$CMD" | jq -r '.command.params.threshold // .params.threshold // 510' 2>/dev/null || echo "510")"
        B5_THREADS="$(echo "$CMD" | jq -r '.command.params.threads // .params.threads // 31' 2>/dev/null || echo "31")"
        B5_BATCH_SIZE="$(echo "$CMD" | jq -r '.command.params.batch_size // .params.batch_size // 4000' 2>/dev/null || echo "4000")"
        B5_AUDIT_RATE="$(echo "$CMD" | jq -r '.command.params.audit_rate // .params.audit_rate // 500' 2>/dev/null || echo "500")"
        B5_DURATION_MINUTES_RAW="$(echo "$CMD" | jq -r '.command.params.duration_minutes // .params.duration_minutes // 10' 2>/dev/null || echo "10")"

        [ -z "$B5_WORKER_NAME" ] && B5_WORKER_NAME="${RIG_ID}_M1097B5_DIRECT_T${B5_THRESHOLD}"

        B5_DURATION_MINUTES_INT="${B5_DURATION_MINUTES_RAW%.*}"
        case "$B5_DURATION_MINUTES_INT" in ''|*[!0-9]*) B5_DURATION_MINUTES_INT=10 ;; esac
        case "$B5_THRESHOLD" in ''|*[!0-9]*) B5_THRESHOLD=510 ;; esac
        case "$B5_THREADS" in ''|*[!0-9]*) B5_THREADS=31 ;; esac
        case "$B5_BATCH_SIZE" in ''|*[!0-9]*) B5_BATCH_SIZE=4000 ;; esac
        case "$B5_AUDIT_RATE" in ''|*[!0-9]*) B5_AUDIT_RATE=500 ;; esac

        # M10.97B5_2_EXPERIMENT_LIFECYCLE:
        # duration_minutes/duration_sec are authoritative for experiment lifecycle.
        # hours remains only a coarse fallback for older launch paths.
        B5_HOURS=$(( (B5_DURATION_MINUTES_INT + 59) / 60 ))
        [ "$B5_HOURS" -lt 1 ] && B5_HOURS=1
        B5_DURATION_SEC=$(( B5_DURATION_MINUTES_INT * 60 ))
        [ "$B5_DURATION_SEC" -lt 60 ] && B5_DURATION_SEC=60

        echo "[M10.97B5.2_GIT_EXPERIMENT] top_level_direct_enqueue begin command_id=$COMMAND_ID lifecycle_id=$COMMAND_LIFECYCLE_ID worker=$B5_WORKER_NAME threshold=$B5_THRESHOLD duration_minutes=$B5_DURATION_MINUTES_INT duration_sec=$B5_DURATION_SEC"

        # M10.97B5_ENV_FORWARD: preserve research env/expected_logs into generated start_run.
        B5_ENV_JSON="$(echo "$CMD" | jq -c '.command.params.env // .params.env // {}' 2>/dev/null || echo '{}')"
        B5_EXPECTED_LOGS_JSON="$(echo "$CMD" | jq -c '.command.params.expected_logs // .params.expected_logs // []' 2>/dev/null || echo '[]')"
        B5_RESEARCH_GOAL="$(echo "$CMD" | jq -r '.command.params.research_goal // .params.research_goal // empty' 2>/dev/null || true)"

        B5_START_PARAMS="$(jq -n \
          --arg mode "experiment" \
          --arg experiment_id "$B5_EXPERIMENT_ID" \
          --arg worker_name "$B5_WORKER_NAME" \
          --arg backend "$B5_BACKEND" \
          --arg profile_source "git_experiment_run_top_level_direct_enqueue_M10.97B5" \
          --arg source_command_type "git_experiment_run" \
          --arg launcher "M10.97B5" \
          --arg research_goal "$B5_RESEARCH_GOAL" \
          --argjson threshold "$B5_THRESHOLD" \
          --argjson hours "$B5_HOURS" \
          --argjson duration_minutes "$B5_DURATION_MINUTES_INT" \
          --argjson duration_sec "$B5_DURATION_SEC" \
          --argjson threads "$B5_THREADS" \
          --argjson batch_size "$B5_BATCH_SIZE" \
          --argjson audit_rate "$B5_AUDIT_RATE" \
          --argjson env "$B5_ENV_JSON" \
          --argjson expected_logs "$B5_EXPECTED_LOGS_JSON" \
          '{mode:$mode, experiment_id:$experiment_id, worker_name:$worker_name, backend:$backend, threshold:$threshold, hours:0, duration_minutes:$duration_minutes, duration_sec:$duration_sec, threads:$threads, batch_size:$batch_size, audit_rate:$audit_rate, env:$env, expected_logs:$expected_logs, research_goal:$research_goal, resume_after:true, fallback:true, fallback_profile:"analytics_baseline", priority:"experiment", profile_source:$profile_source, source_command_type:$source_command_type, launcher:$launcher, lifecycle:"M10.97B5.2"}')"

        B5_CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":$B5_START_PARAMS}" || true)"

        echo "[M10.97B5_GIT_EXPERIMENT] start_run_create_resp=$B5_CREATE_RESP"
        echo "[M10.99M_ENV_FORWARDING] b5_start_run_env=$B5_ENV_JSON worker=$B5_WORKER_NAME experiment=$B5_EXPERIMENT_ID" | tee -a "${BUILD_LOG:-/tmp/coded_m1099m_env_forwarding.log}"

        echo "[M10.97B5.2_GIT_EXPERIMENT] start_run_create_resp=$B5_CREATE_RESP"

        B5_START_RUN_COMMAND_ID="$(echo "$B5_CREATE_RESP" | jq -r '.data.command_id // .command.command_id // empty' 2>/dev/null || true)"
        B5_START_RUN_DB_ID="$(echo "$B5_CREATE_RESP" | jq -r '.data.id // .command.id // empty' 2>/dev/null || true)"
        B5_CREATE_RESP_SAFE="$(printf '%s' "$B5_CREATE_RESP" | jq -Rs . 2>/dev/null || echo "\"unparseable_create_response\"")"

        if [ -z "$B5_START_RUN_COMMAND_ID" ]; then
          coded_fail_command "$COMMAND_LIFECYCLE_ID" "M10.97B5 failed to enqueue experiment start_run" "{\"status\":\"failed\",\"stage\":\"m1097b5_top_level_direct_enqueue\",\"worker_name\":\"$B5_WORKER_NAME\",\"experiment_id\":\"$B5_EXPERIMENT_ID\",\"create_response\":$B5_CREATE_RESP_SAFE}" || true
          coded_resume_default_after_gitexp "m1097b5_top_level_direct_enqueue_failed" || true
          sleep 5
          continue
        fi

        coded_complete_command_id "$COMMAND_LIFECYCLE_ID" "{\"status\":\"start_run_enqueued\",\"stage\":\"m1097b5_2_top_level_direct_experiment_start_run_enqueued\",\"start_run_command_id\":\"$B5_START_RUN_COMMAND_ID\",\"start_run_db_id\":\"$B5_START_RUN_DB_ID\",\"worker_name\":\"$B5_WORKER_NAME\",\"experiment_id\":\"$B5_EXPERIMENT_ID\",\"backend\":\"$B5_BACKEND\",\"threshold\":$B5_THRESHOLD,\"duration_minutes\":$B5_DURATION_MINUTES_INT,\"duration_sec\":$B5_DURATION_SEC,\"resume_after\":true,\"build_before_run\":false,\"lifecycle\":\"M10.97B5.2\"}" || true

        echo "[M10.97B5_GIT_EXPERIMENT] completed command_id=$COMMAND_ID start_run_command_id=$B5_START_RUN_COMMAND_ID worker=$B5_WORKER_NAME"
        # M10.99K: ensure git_experiment_run launcher does not remain running.
        coded_complete_command_id "$COMMAND_LIFECYCLE_ID" "{\"status\":\"start_run_enqueued\",\"stage\":\"m1099k_git_experiment_launcher_completed\",\"start_run_command_id\":\"$B5_START_RUN_COMMAND_ID\",\"worker_name\":\"$B5_WORKER_NAME\",\"experiment_id\":\"$B5_EXPERIMENT_ID\",\"duration_sec\":$B5_DURATION_SEC,\"lifecycle\":\"M10.99K\"}" || true

        if [ -n "${COMMAND_ID:-}" ] && [ "${COMMAND_ID:-}" != "${COMMAND_LIFECYCLE_ID:-}" ]; then
          coded_complete_command_id "$COMMAND_ID" "{\"status\":\"start_run_enqueued\",\"stage\":\"m1099k_git_experiment_launcher_completed_command_id_fallback\",\"start_run_command_id\":\"$B5_START_RUN_COMMAND_ID\",\"worker_name\":\"$B5_WORKER_NAME\",\"experiment_id\":\"$B5_EXPERIMENT_ID\",\"duration_sec\":$B5_DURATION_SEC,\"lifecycle\":\"M10.99K\"}" || true
        fi


        echo "[M10.99L_LAUNCHER_CLEANUP] git_experiment_run should be completed command_id=$COMMAND_ID lifecycle_id=$COMMAND_LIFECYCLE_ID start_run=$B5_START_RUN_COMMAND_ID worker=$B5_WORKER_NAME duration_sec=$B5_DURATION_SEC" | tee -a "${BUILD_LOG:-/tmp/coded_m1099l_launcher_cleanup.log}"

        echo "[M10.97B5.2_GIT_EXPERIMENT] completed command_id=$COMMAND_ID stage=m1097b5_2_top_level_direct_experiment_start_run_enqueued start_run_command_id=$B5_START_RUN_COMMAND_ID duration_sec=$B5_DURATION_SEC worker=$B5_WORKER_NAME"
        sleep 5
        continue
      fi

      echo "[M10.97B5_GIT_EXPERIMENT] build_before_run=true; allowing legacy build path command_id=$COMMAND_ID"

      echo "[M10.96G6_GIT_EXPERIMENT_TOP_LEVEL] picked command_id=$COMMAND_ID"
      echo "[M10.96G_GIT_EXPERIMENT] picked command_id=$COMMAND_ID"

      PARAMS="$(echo "$CMD" | jq -c ".command.params // {}")"

      coded_m1099z12_normalize_duration_from_params "$PARAMS"
      BRANCH="$(echo "$PARAMS" | jq -r ".branch // \"dev\"")"
      WORKER_NAME="$(echo "$PARAMS" | jq -r ".worker_name // (env.RIG_ID + \"_GIT_EXPERIMENT\")")"
      EXPERIMENT_ID="$(echo "$PARAMS" | jq -r ".experiment_id // \"GIT_EXPERIMENT\"")"
      BACKEND="$(echo "$PARAMS" | jq -r ".backend // \"avx512\"")"
      THRESHOLD="$(echo "$PARAMS" | jq -r ".threshold // 510")"
      THREADS="$(echo "$PARAMS" | jq -r ".threads // 31")"
      BATCH_SIZE="$(echo "$PARAMS" | jq -r ".batch_size // 4000")"
      AUDIT_RATE="$(echo "$PARAMS" | jq -r ".audit_rate // 500")"
      DURATION_MINUTES="$(echo "$PARAMS" | jq -r ".duration_minutes // 120")"
      CMAKE_FLAGS="$(echo "$PARAMS" | jq -r ".cmake_flags // \"-DCMAKE_BUILD_TYPE=Release -DCODED_ENABLE_AVX2=ON -DCODED_ENABLE_AVX512=ON\"")"

      BUILD_LOG="/tmp/coded_git_experiment_${RIG_ID}_${EXPERIMENT_ID}_$(date -u +%Y%m%d_%H%M%S).log"
      MINER_DIR="/hive/codedonqubic"
      [ -d "$MINER_DIR/.git" ] || MINER_DIR="/hive/miners/custom/coded-miner"

      coded_mark_command_running "$COMMAND_LIFECYCLE_ID" || true
      HEARTBEAT_PID="$(coded_command_heartbeat_bg "$COMMAND_LIFECYCLE_ID" "$BUILD_LOG")"

      echo "[M10.97B4_GIT_EXPERIMENT] running command_id=$COMMAND_ID lifecycle_id=$COMMAND_LIFECYCLE_ID heartbeat_pid=$HEARTBEAT_PID" | tee -a "$BUILD_LOG"

      # ============================================================
      # M10.97B4: Direct fast enqueue for git_experiment_run
      # ------------------------------------------------------------
      # Critical rule:
      # git_experiment_run is a launcher/control command only.
      # Runtime begins only after a real start_run is created.
      #
      # Normal experiment path:
      #   1) extract params directly from CMD JSON
      #   2) POST start_run
      #   3) complete git_experiment_run with start_run_command_id
      #   4) continue fleet loop
      #
      # Legacy build path is only allowed when build_before_run=true.
      # ============================================================

      B4_BUILD_BEFORE_RUN="$(echo "$CMD" | jq -r '.command.params.build_before_run // .params.build_before_run // "false"' 2>/dev/null || echo "false")"

      if [ "$B4_BUILD_BEFORE_RUN" != "true" ]; then
        B4_WORKER_NAME="$(echo "$CMD" | jq -r '.command.params.worker_name // .params.worker_name // empty' 2>/dev/null || true)"
        B4_EXPERIMENT_ID="$(echo "$CMD" | jq -r '.command.params.experiment_id // .params.experiment_id // "M1097B4_EXPERIMENT"' 2>/dev/null || echo "M1097B4_EXPERIMENT")"
        B4_BACKEND="$(echo "$CMD" | jq -r '.command.params.backend // .params.backend // "avx512"' 2>/dev/null || echo "avx512")"
        B4_THRESHOLD="$(echo "$CMD" | jq -r '.command.params.threshold // .params.threshold // 510' 2>/dev/null || echo "510")"
        B4_THREADS="$(echo "$CMD" | jq -r '.command.params.threads // .params.threads // 31' 2>/dev/null || echo "31")"
        B4_BATCH_SIZE="$(echo "$CMD" | jq -r '.command.params.batch_size // .params.batch_size // 4000' 2>/dev/null || echo "4000")"
        B4_AUDIT_RATE="$(echo "$CMD" | jq -r '.command.params.audit_rate // .params.audit_rate // 500' 2>/dev/null || echo "500")"
        B4_DURATION_MINUTES_RAW="$(echo "$CMD" | jq -r '.command.params.duration_minutes // .params.duration_minutes // 10' 2>/dev/null || echo "10")"

        [ -z "$B4_WORKER_NAME" ] && B4_WORKER_NAME="${RIG_ID}_M1097B4_FAST_T${B4_THRESHOLD}"

        B4_DURATION_MINUTES_INT="${B4_DURATION_MINUTES_RAW%.*}"
        case "$B4_DURATION_MINUTES_INT" in ''|*[!0-9]*) B4_DURATION_MINUTES_INT=10 ;; esac
        case "$B4_THRESHOLD" in ''|*[!0-9]*) B4_THRESHOLD=510 ;; esac
        case "$B4_THREADS" in ''|*[!0-9]*) B4_THREADS=31 ;; esac
        case "$B4_BATCH_SIZE" in ''|*[!0-9]*) B4_BATCH_SIZE=4000 ;; esac
        case "$B4_AUDIT_RATE" in ''|*[!0-9]*) B4_AUDIT_RATE=500 ;; esac

        B4_HOURS=$(( (B4_DURATION_MINUTES_INT + 59) / 60 ))
        [ "$B4_HOURS" -lt 1 ] && B4_HOURS=1

        echo "[M10.97B4_GIT_EXPERIMENT] direct_enqueue begin command_id=$COMMAND_ID worker=$B4_WORKER_NAME threshold=$B4_THRESHOLD duration_minutes=$B4_DURATION_MINUTES_INT" | tee -a "$BUILD_LOG"

        B4_START_PARAMS="$(jq -n \
          --arg mode "experiment" \
          --arg experiment_id "$B4_EXPERIMENT_ID" \
          --arg worker_name "$B4_WORKER_NAME" \
          --arg backend "$B4_BACKEND" \
          --arg profile_source "git_experiment_run_direct_enqueue_M10.97B4" \
          --arg source_command_type "git_experiment_run" \
          --arg launcher "M10.97B4" \
          --argjson threshold "$B4_THRESHOLD" \
          --argjson hours "$B4_HOURS" \
          --argjson threads "$B4_THREADS" \
          --argjson batch_size "$B4_BATCH_SIZE" \
          --argjson audit_rate "$B4_AUDIT_RATE" \
          '{mode:$mode, experiment_id:$experiment_id, worker_name:$worker_name, backend:$backend, threshold:$threshold, hours:$hours, threads:$threads, batch_size:$batch_size, audit_rate:$audit_rate, resume_after:true, fallback:true, fallback_profile:"analytics_baseline", priority:"experiment", profile_source:$profile_source, source_command_type:$source_command_type, launcher:$launcher}')"

        B4_CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":$B4_START_PARAMS}" || true)"

        echo "[M10.97B4_GIT_EXPERIMENT] start_run_create_resp=$B4_CREATE_RESP" | tee -a "$BUILD_LOG"

        B4_START_RUN_COMMAND_ID="$(echo "$B4_CREATE_RESP" | jq -r '.data.command_id // .command.command_id // empty' 2>/dev/null || true)"
        B4_START_RUN_DB_ID="$(echo "$B4_CREATE_RESP" | jq -r '.data.id // .command.id // empty' 2>/dev/null || true)"
        B4_CREATE_RESP_SAFE="$(printf '%s' "$B4_CREATE_RESP" | jq -Rs . 2>/dev/null || echo "\"unparseable_create_response\"")"

        [ -n "${HEARTBEAT_PID:-}" ] && kill "$HEARTBEAT_PID" >/dev/null 2>&1 || true

        if [ -z "$B4_START_RUN_COMMAND_ID" ]; then
          coded_fail_command "$COMMAND_LIFECYCLE_ID" "M10.97B4 failed to enqueue experiment start_run" "{\"status\":\"failed\",\"stage\":\"m1097b4_direct_enqueue_start_run\",\"worker_name\":\"$B4_WORKER_NAME\",\"experiment_id\":\"$B4_EXPERIMENT_ID\",\"create_response\":$B4_CREATE_RESP_SAFE}" || true
          coded_resume_default_after_gitexp "m1097b4_direct_enqueue_failed" || true
          sleep 5
          continue
        fi

        coded_complete_command_id "$COMMAND_LIFECYCLE_ID" "{\"status\":\"start_run_enqueued\",\"stage\":\"m1097b4_direct_experiment_start_run_enqueued\",\"start_run_command_id\":\"$B4_START_RUN_COMMAND_ID\",\"start_run_db_id\":\"$B4_START_RUN_DB_ID\",\"worker_name\":\"$B4_WORKER_NAME\",\"experiment_id\":\"$B4_EXPERIMENT_ID\",\"backend\":\"$B4_BACKEND\",\"threshold\":$B4_THRESHOLD,\"log\":\"$BUILD_LOG\",\"resume_after\":true,\"build_before_run\":false}" || true

        echo "[M10.97B4_GIT_EXPERIMENT] completed command_id=$COMMAND_ID start_run_command_id=$B4_START_RUN_COMMAND_ID worker=$B4_WORKER_NAME" | tee -a "$BUILD_LOG"
        sleep 5
        continue
      fi

      echo "[M10.97B4_GIT_EXPERIMENT] build_before_run=true; entering legacy build path" | tee -a "$BUILD_LOG"


      echo "[M10.96G_GIT_EXPERIMENT] dir=$MINER_DIR branch=$BRANCH worker=$WORKER_NAME backend=$BACKEND threshold=$THRESHOLD" | tee -a "$BUILD_LOG"

      BACKUP="/hive/miners/custom/coded-miner/coded-miner.backup.$(date -u +%Y%m%d_%H%M%S)"
      if [ -x "/hive/miners/custom/coded-miner/coded-miner" ]; then
        cp "/hive/miners/custom/coded-miner/coded-miner" "$BACKUP" || true
      fi

      (
        set -e
        cd "$MINER_DIR"
        git fetch origin
        git checkout "$BRANCH"
        git pull --ff-only origin "$BRANCH"
        rm -rf build
        cmake -S . -B build $CMAKE_FLAGS
        cmake --build build -j
        cp build/coded-miner /hive/miners/custom/coded-miner/coded-miner
        chmod +x /hive/miners/custom/coded-miner/coded-miner
      ) >>"$BUILD_LOG" 2>&1
      EC=$?

      if [ "$EC" != "0" ]; then
        echo "[M10.96G_GIT_EXPERIMENT] build failed ec=$EC backup=$BACKUP log=$BUILD_LOG" | tee -a "$BUILD_LOG"
        [ -f "$BACKUP" ] && cp "$BACKUP" /hive/miners/custom/coded-miner/coded-miner || true
        coded_fail_command "$COMMAND_LIFECYCLE_ID" "git_experiment_run build failed" "{\"status\":\"failed\",\"stage\":\"build\",\"exit_code\":$EC,\"log\":\"$BUILD_LOG\",\"backup\":\"$BACKUP\"}" || true
        coded_resume_default_after_gitexp "git_experiment_build_failed"
        sleep 5
        continue
      fi

      START_PARAMS="$(jq -n \
        --arg mode "experiment" \
        --arg experiment_id "$EXPERIMENT_ID" \
        --arg worker_name "$WORKER_NAME" \
        --arg backend "$BACKEND" \
        --argjson threshold "$THRESHOLD" \
        --argjson hours "$(python3 - <<PY2
import math, os
print(max(1, math.ceil(float(os.environ.get("DURATION_MINUTES","120"))/60)))
PY2
)" \
        --argjson threads "$THREADS" \
        --argjson batch_size "$BATCH_SIZE" \
        --argjson audit_rate "$AUDIT_RATE" \
        '{mode:$mode, experiment_id:$experiment_id, worker_name:$worker_name, backend:$backend, threshold:$threshold, hours:$hours, threads:$threads, batch_size:$batch_size, audit_rate:$audit_rate, resume_after:true, fallback_profile:"analytics_baseline", profile_source:"git_experiment_run"}')"

      CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":$START_PARAMS}" || true)"

      echo "[M10.97B4_GIT_EXPERIMENT] start_run_create_resp=$CREATE_RESP" | tee -a "$BUILD_LOG"

      START_RUN_COMMAND_ID="$(echo "$CREATE_RESP" | jq -r '.data.command_id // .command.command_id // empty' 2>/dev/null || true)"
      START_RUN_DB_ID="$(echo "$CREATE_RESP" | jq -r '.data.id // .command.id // empty' 2>/dev/null || true)"

      [ -n "${HEARTBEAT_PID:-}" ] && kill "$HEARTBEAT_PID" >/dev/null 2>&1 || true

      if [ -z "$START_RUN_COMMAND_ID" ]; then
        coded_fail_command "$COMMAND_LIFECYCLE_ID" "git_experiment_run failed to enqueue start_run" "{\"status\":\"failed\",\"stage\":\"enqueue_start_run\",\"worker_name\":\"$WORKER_NAME\",\"experiment_id\":\"$EXPERIMENT_ID\",\"create_response\":$CREATE_RESP}" || true
        coded_resume_default_after_gitexp "git_experiment_start_run_enqueue_failed" || true
        sleep 5
        continue
      fi

      coded_complete_command_id "$COMMAND_LIFECYCLE_ID" "{\"status\":\"start_run_enqueued\",\"stage\":\"git_build_completed_start_run_enqueued\",\"start_run_command_id\":\"$START_RUN_COMMAND_ID\",\"start_run_db_id\":\"$START_RUN_DB_ID\",\"worker_name\":\"$WORKER_NAME\",\"experiment_id\":\"$EXPERIMENT_ID\",\"backend\":\"$BACKEND\",\"threshold\":$THRESHOLD,\"log\":\"$BUILD_LOG\",\"backup\":\"$BACKUP\",\"resume_after\":true}" || true

      echo "[M10.97B4_GIT_EXPERIMENT] completed command_id=$COMMAND_ID enqueued start_run worker=$WORKER_NAME resume_after=true" | tee -a "$BUILD_LOG"
      sleep 5
      continue
    fi

    if [ "$COMMAND_TYPE" = "build_hive_release" ] || [ "$COMMAND_TYPE" = "build_release" ]; then
    # M10.99W4E_TOP_LEVEL_RELEASE_PICKUP
    # Direct /commands/next build_hive_release must enter the release handler here.
    # W4D fixed next-interrupt, but direct top-level pickup still created empty
    # build logs and then default mining resumed. This branch is now authoritative.
    export COMMAND_TYPE="${COMMAND_TYPE:-${CMD_TYPE:-build_hive_release}}"
    export CMD_TYPE="${COMMAND_TYPE}"
    export COMMAND_JSON="${COMMAND_JSON:-${CMD_JSON:-${COMMAND:-${CMD:-${RESP:-${RESPONSE:-{}}}}}}}"

    # Normalize wrapped API response shape: { command: {...} } -> {...}
    COMMAND_JSON="$(echo "$COMMAND_JSON" | jq -c '.command // .' 2>/dev/null || echo "$COMMAND_JSON")"
    export COMMAND_JSON
    export CMD_JSON="$COMMAND_JSON"

    if [ -z "${COMMAND_ID:-}" ] || [ "${COMMAND_ID:-}" = "null" ]; then
      COMMAND_ID="$(echo "$COMMAND_JSON" | jq -r '.command_id // .id // empty' 2>/dev/null || true)"
      export COMMAND_ID
    fi
    export CMD_ID="${COMMAND_ID:-}"

    echo "[M10.99W4E_TOP_LEVEL_RELEASE_PICKUP] command=${COMMAND_ID:-unknown} type=${COMMAND_TYPE:-unknown} entering release handler before default fallback" | tee -a "${RUN_LOG:-/tmp/coded_release_guard.log}" 2>/dev/null || true

    m1099w4_handle_release_command_first
    exit $?


      VERSION="$(echo "$CMD" | jq -r ".command.params.version // empty")"
      [ -z "$VERSION" ] || [ "$VERSION" = "null" ] && VERSION="v0.0.0-dev"

      RESUME_AFTER_BUILD="$(echo "$CMD" | jq -r ".command.params.resume_after // true" 2>/dev/null || echo true)"

      BUILD_LOG="/tmp/coded_hive_release_${VERSION}.log"
      echo "[M10.99Z9_RELEASE_BUILD_RUNTIME_GUARD] begin command=$COMMAND_ID lifecycle_id=$COMMAND_LIFECYCLE_ID type=$COMMAND_TYPE version=$VERSION rig=$RIG_ID resume_after=$RESUME_AFTER_BUILD" | tee "$BUILD_LOG"

      # Mark long-running release build as running with a long lease.
      curl -s -X POST "$CODED_API_ROOT/commands/$COMMAND_ID/running" \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"lease_minutes\":30,\"result\":{\"status\":\"release_build_running\",\"version\":\"$VERSION\",\"builder\":\"$RIG_ID\",\"marker\":\"M10.99Z9_RELEASE_BUILD_RUNTIME_GUARD\"}}" >> "$BUILD_LOG" 2>&1 || true

      # Keep command lease fresh while build/release upload runs.
      (
        while true; do
          curl -s -X POST "$CODED_API_ROOT/commands/$COMMAND_ID/heartbeat" \
            -H "Authorization: Bearer $TOKEN" \
            -H "Content-Type: application/json" \
            -d "{\"lease_minutes\":30}" >/dev/null 2>&1 || true
          echo "[M10.99Z9_RELEASE_BUILD_RUNTIME_GUARD] heartbeat command=$COMMAND_ID version=$VERSION ts=$(date -u +%FT%TZ)" >> "$BUILD_LOG" 2>/dev/null || true
          sleep 30
        done
      ) &
      RELEASE_HEARTBEAT_PID=$!

      (
        set -e
        cd /hive/codedonqubic

        echo "[M10.99Z9_RELEASE] repo=$(pwd)"
        echo "[M10.99Z9_RELEASE] git fetch/reset main"
        git fetch origin main
        git reset --hard origin/main

        export GH_CONFIG_DIR="${GH_CONFIG_DIR:-/root/.config/gh}"
        export HOME="${HOME:-/root}"

        echo "[M10.99Z9_RELEASE] gh auth check"
        gh auth status >/dev/null 2>&1 || {
          echo "[M10.99Z9_RELEASE] ERROR: gh auth status failed"
          exit 10
        }

        RELEASE_SCRIPT=""
        if [ -x ./scripts/release.sh ]; then
          RELEASE_SCRIPT="./scripts/release.sh"
        elif [ -f ./scripts/release.sh ]; then
          chmod +x ./scripts/release.sh
          RELEASE_SCRIPT="./scripts/release.sh"
        elif [ -x ./scripts/release_hiveos.sh ]; then
          RELEASE_SCRIPT="./scripts/release_hiveos.sh"
        elif [ -f ./scripts/release_hiveos.sh ]; then
          chmod +x ./scripts/release_hiveos.sh
          RELEASE_SCRIPT="./scripts/release_hiveos.sh"
        else
          echo "[M10.99Z9_RELEASE] ERROR: no release script found in ./scripts"
          ls -la ./scripts || true
          exit 11
        fi

        echo "[M10.99Z9_RELEASE] using release script $RELEASE_SCRIPT"
        "$RELEASE_SCRIPT" "$VERSION" linux/amd64

        RELEASE_DIR="/hive/coded-miner-release"
        if [ ! -d "$RELEASE_DIR" ]; then
          echo "[M10.99Z9_RELEASE] ERROR: release dir missing $RELEASE_DIR"
          exit 12
        fi

        ASSETS="$(find "$RELEASE_DIR" -maxdepth 1 -type f \( -name "coded-miner-latest.tar.gz" -o -name "coded-miner-docker-linux-amd64.tar.gz" \) | sort -u | tr "\n" " ")"
        if [ -z "$ASSETS" ]; then
          echo "[M10.99Z9_RELEASE] ERROR: no release assets found in $RELEASE_DIR"
          find "$RELEASE_DIR" -maxdepth 2 -type f || true
          exit 13
        fi

        echo "[M10.99Z9_RELEASE] assets: $ASSETS"

        if gh release view "$VERSION" --repo CodedOnQubic/coded-miner-release >/dev/null 2>&1; then
          echo "[M10.99Z9_RELEASE] updating existing GitHub release $VERSION"
          gh release upload "$VERSION" $ASSETS --repo CodedOnQubic/coded-miner-release --clobber
          gh release edit "$VERSION" --repo CodedOnQubic/coded-miner-release --draft=false
        else
          echo "[M10.99Z9_RELEASE] creating GitHub release $VERSION"
          gh release create "$VERSION" $ASSETS \
            --repo CodedOnQubic/coded-miner-release \
            --title "$VERSION" \
            --notes "HiveOS fleet analytics release $VERSION" \
            --target main
        fi
      ) >> "$BUILD_LOG" 2>&1

      EC=$?

      kill "$RELEASE_HEARTBEAT_PID" >/dev/null 2>&1 || true
      wait "$RELEASE_HEARTBEAT_PID" >/dev/null 2>&1 || true

      if [ "$EC" = "0" ]; then
        coded_release_guard "$VERSION" "$BUILD_LOG"
        GUARD_EC=$?
        if [ "$GUARD_EC" != "0" ]; then
          EC="$GUARD_EC"
          echo "[M10.99Z9_RELEASE] guard failed VERSION=$VERSION guard_exit=$GUARD_EC" >> "$BUILD_LOG"
        fi
      fi

      if [ "$EC" = "0" ]; then
        if coded_complete_release_command_strict "$COMMAND_ID" "$VERSION" "$BUILD_LOG" "$COMMAND_TYPE"; then
          echo "[M10.99Z9_RELEASE] completed command=$COMMAND_ID version=$VERSION" | tee -a "$BUILD_LOG"
        else
          coded_fail_command "$COMMAND_ID" "release succeeded but command completion failed" "{\"status\":\"release_success_command_completion_failed\",\"release\":\"$VERSION\",\"log\":\"$BUILD_LOG\",\"repo\":\"CodedOnQubic/coded-miner-release\",\"builder\":\"$RIG_ID\",\"command_type\":\"$COMMAND_TYPE\",\"marker\":\"M10.99Z9_RELEASE_BUILD_RUNTIME_GUARD\"}"
        fi
      else
        coded_fail_command "$COMMAND_ID" "release build failed or validation failed" "{\"version\":\"$VERSION\",\"log\":\"$BUILD_LOG\",\"exit_code\":$EC,\"builder\":\"$RIG_ID\",\"command_type\":\"$COMMAND_TYPE\",\"marker\":\"M10.99Z9_RELEASE_BUILD_RUNTIME_GUARD\"}"
        echo "[M10.99Z9_RELEASE] failed VERSION=$VERSION exit=$EC log=$BUILD_LOG" | tee -a "$BUILD_LOG"
      fi

      if [ "$RESUME_AFTER_BUILD" = "true" ] || [ "$RESUME_AFTER_BUILD" = "1" ]; then
        # M10.99Z17C_RELEASE_RESUME_AGENT
        # Prefer exact previous-runtime resume from release command params.
        if coded_m1099z17c_enqueue_resume_after_release "$CMD"; then
          echo "[M10.99Z17C_RELEASE_RESUME_AGENT] resumed previous runtime after release VERSION=$VERSION" | tee -a "$BUILD_LOG"
        else
          echo "[M10.99Z17C_RELEASE_RESUME_AGENT] no explicit resume params; enqueue default analytics VERSION=$VERSION" | tee -a "$BUILD_LOG"
          coded_enqueue_default_analytics || true
        fi
      fi

      continue
    fi

    THRESHOLD="$(echo "$CMD" | jq -r ".command.params.threshold // 510")"
    HOURS="$(echo "$CMD" | jq -r ".command.params.hours // 8")"
JOB_THREADS="$(echo "$CMD" | jq -r ".command.params.threads // empty")"
if [ -n "$JOB_THREADS" ] && echo "$JOB_THREADS" | grep -Eq "^[0-9]+$"; then
  THREADS="$JOB_THREADS"
fi
    BATCH="$(echo "$CMD" | jq -r ".command.params.batch_size // 4000")"
    AUDIT="$(echo "$CMD" | jq -r ".command.params.audit_rate // 500")"
    RUN_WORKER="$(echo "$CMD" | jq -r ".command.params.worker_name // empty")"
    [ -z "$RUN_WORKER" ] && RUN_WORKER="${WORKER}_T${THRESHOLD}"
    RUN_MODE="$(echo "$CMD" | jq -r ".command.params.mode // \"experiment\"")"

    RUN_ID="M1084_${RIG_ID}_T${THRESHOLD}_$(date +%Y%m%d_%H%M%S)"
    RUN_LOG="$LOG_DIR/${RUN_ID}.log"
    # ============================================================
    # M10.96G8AB float-safe HOURS duration
    # ============================================================
    # Experiment runs may use fractional hours, e.g. 0.3333333333.
    # Bash arithmetic is integer-only, so convert via awk before END.
    RUN_DURATION_SEC="$(awk -v h="${HOURS:-24}" 'BEGIN { if (h <= 0) h = 24; printf "%d", h * 3600 }' 2>/dev/null || echo 86400)"
    [ -z "$RUN_DURATION_SEC" ] && RUN_DURATION_SEC=86400
    [ "$RUN_DURATION_SEC" -lt 60 ] 2>/dev/null && RUN_DURATION_SEC=60
    END=$((SECONDS + RUN_DURATION_SEC))
    echo "[M10.96G8AB_DURATION] command=$COMMAND_ID hours=${HOURS:-} duration_sec=$RUN_DURATION_SEC" | tee -a "$RUN_LOG"
  if [ -n "${PARAMS:-}" ]; then coded_m1099k_apply_duration_override "$PARAMS" || true; fi
  if [ -n "${PARAMS:-}" ]; then coded_m1099m_export_params_env "$PARAMS" "${RUN_LOG:-/tmp/coded_m1099m_env_forwarding.log}" || true; fi
  if [ -n "${PARAMS:-}" ]; then coded_m1099l_start_duration_watchdog "$PARAMS" "${COMMAND_LIFECYCLE_ID:-$COMMAND_ID}" "${COMMAND_ID:-}" "${WORKER_NAME:-$WORKER}" "${RUN_LOG:-/tmp/coded_m1099l_duration_watchdog.log}" || true; fi

    # ============================================================
    # M10.96G8Y command-branch worker override
    # ============================================================
    # This is the active /commands/next start_run branch.
    # Apply command params after RUN_WORKER/THRESHOLD/BACKEND parsing
    # and before the M10.91C launch loop.
    coded_apply_start_run_params_override || true
    # M10.99Z191_POST_OVERRIDE_START_RUN_RUNTIME_HANDOFF_CALL
    coded_z191_start_run_post_override_handoff "after_coded_apply_start_run_params_override" || true
    coded_enforce_expected_worker_before_launch || true
    echo "[M10.96G8Y_COMMAND_BRANCH_OVERRIDE] command=$COMMAND_ID worker=$RUN_WORKER threads=$THREADS threshold=$THRESHOLD backend=${BACKEND:-}" | tee -a "$RUN_LOG"

    export CODED_FAST_SHADOW_THRESHOLD="$THRESHOLD"
    export CODED_FAST_SHADOW_AUDIT_RATE="$AUDIT"
    export CODED_BATCH_SIZE="$BATCH"
    export CODED_FAST_SHADOW_SUMMARY_SEC="${CODED_FAST_SHADOW_SUMMARY_SEC:-60}"
    export CODED_RANDOM2_HUGEPAGE="${CODED_RANDOM2_HUGEPAGE:-1}"
    export CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}"
    export CODED_SCORE_ALGO_MODE="${CODED_SCORE_ALGO_MODE:-hyperidentity_only}"
    export CODED_SCORE_SAMPLE_BATCH_RATE="${CODED_SCORE_SAMPLE_BATCH_RATE:-0}"
    export CODED_SHADOW_AVX512_LIVE="${CODED_SHADOW_AVX512_LIVE:-1}"
    export CODED_LOG_MODE="${CODED_LOG_MODE:-dev}"

    curl -s -X POST "$API/runs/start" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"miner_version\":\"m10.84b-fleet-agent\",\"backend\":\"$CODED_KERNEL_BACKEND\",\"threshold\":$THRESHOLD,\"threads\":$THREADS,\"batch_size\":$BATCH,\"audit_rate\":$AUDIT,\"gate_mode\":\"single\",\"hostname\":\"$(hostname)\",\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2_supported\":$AVX2,\"avx512_supported\":$AVX512,\"hugepages_total\":${HPT:-0},\"hugepages_free\":${HPF:-0},\"hardware\":{\"cpu_model\":\"$CPU_MODEL\",\"cpu_threads\":$CPU_THREADS,\"ram_mb\":$RAM_MB,\"avx2\":$AVX2,\"avx512\":$AVX512}}" >/dev/null || true

    coded_state_set_active_profile "$RUN_ID" "$COMMAND_ID" "$RUN_WORKER" "$RUN_MODE" "$THRESHOLD" "$HOURS" "$THREADS" "$BATCH" "$AUDIT"

    echo "[CODED_FLEET] starting command=$COMMAND_ID run=$RUN_ID mode=$RUN_MODE threshold=$THRESHOLD hours=$HOURS"

    (
      set +e

      while true; do

        [ ! -f "$RUN_LOG" ] && sleep 5 && continue
        sleep 60

        # Uploader is intentionally independent from miner PID.
        # The miner may restart inside the command window.
        SUMMARY="$(grep "FAST_SHADOW_SUMMARY" "$RUN_LOG" | tail -n 1 || true)"
        MULTI="$(grep "FAST_SHADOW_MULTILEVEL" "$RUN_LOG" | tail -n 1 || true)"
        HIST="$(grep "FAST_SHADOW_HISTOGRAM" "$RUN_LOG" | tail -n 1 || true)"
        POLICY="$(grep "FAST_SHADOW_POLICY" "$RUN_LOG" | tail -n 1 || true)"
        BUDGET="$(grep '^\[PRIORITY_BUDGET_ROUTER\]' "$RUN_LOG" | tail -n 1 || true)"
        if [ -z "${BUDGET:-}" ]; then
          echo "[PRIORITY_BUDGET_UPLOAD_SKIP] reason=no_router_summary_line_yet worker=${RUN_WORKER:-${WORKER_NAME:-unknown}} run_id=${RUN_ID:-unknown}" >> "$RUN_LOG" 2>/dev/null || true
        fi
        SOLS="$(grep "SOLS:" "$RUN_LOG" | tail -n 1 || true)"
        HI="$(grep "HI_TIMING_SUMMARY" "$RUN_LOG" | tail -n 1 || true)"

        # ============================================================
        # M10.99Z1 Runtime Heartbeat Recovery
        # ============================================================
        # Critical fix:
        # Runtime heartbeat must NOT depend on FAST_SHADOW_SUMMARY.
        #
        # In recent releases, summary lines can be delayed/missing/renamed
        # while the miner is still running and printing it/s lines.
        # The old code did:
        #   [ -z "$SUMMARY" ] && continue
        # before /runs/heartbeat, which stopped last_seen/avg_its updates.
        #
        # This block sends a lightweight heartbeat every uploader tick using
        # the latest SOLS/perf line. Summary-based analytics still continue
        # below only when SUMMARY exists.
        # ============================================================

        PERF_LINE="$SOLS"
        if [ -z "${PERF_LINE:-}" ]; then
          PERF_LINE="$(grep -E "SOLS:|avg it/s|avg_its=|last_its=|\[[A-Za-z0-9_ -]+\][[:space:]]+[0-9]+[[:space:]]+it/s" "$RUN_LOG" | tail -n 1 || true)"
        fi

        RUNTIME_AVG_ITS="$(echo "$PERF_LINE" | grep -oP "\|[[:space:]]*\K[0-9]+(?:\.[0-9]+)?(?=[[:space:]]+avg it/s)" | tail -n 1 || true)"
        [ -z "${RUNTIME_AVG_ITS:-}" ] && RUNTIME_AVG_ITS="$(echo "$PERF_LINE" | grep -oP "avg_its=\K[0-9]+(?:\.[0-9]+)?" | tail -n 1 || true)"
        [ -z "${RUNTIME_AVG_ITS:-}" ] && RUNTIME_AVG_ITS="$(echo "$PERF_LINE" | grep -oP "avg[ _-]?it/s[=:][[:space:]]*\K[0-9]+(?:\.[0-9]+)?" | tail -n 1 || true)"

        RUNTIME_LAST_ITS="$(echo "$PERF_LINE" | grep -oP "\][[:space:]]*\K[0-9]+(?:\.[0-9]+)?(?=[[:space:]]+it/s)" | tail -n 1 || true)"
        [ -z "${RUNTIME_LAST_ITS:-}" ] && RUNTIME_LAST_ITS="$(echo "$PERF_LINE" | grep -oP "last_its=\K[0-9]+(?:\.[0-9]+)?" | tail -n 1 || true)"

        # Final numeric safety. Never emit empty JSON numbers.
        if [ -z "${RUNTIME_AVG_ITS:-}" ]; then RUNTIME_AVG_ITS=0; fi
        if [ -z "${RUNTIME_LAST_ITS:-}" ]; then RUNTIME_LAST_ITS=0; fi

        SUMMARY_PRESENT=false
        if [ -n "${SUMMARY:-}" ]; then SUMMARY_PRESENT=true; fi

        # M10.99Z2: do not mask pool/job wait as healthy mining.
        # last_seen remains fresh, but runtime status now tells the truth.
        RUNTIME_STATUS="running"
        if echo "${PERF_LINE:-}" | grep -q "WAITING FOR FIRST JOB"; then
          RUNTIME_STATUS="waiting_for_first_job"
        elif echo "${PERF_LINE:-}" | grep -q "WAITING FOR NEW SEED"; then
          RUNTIME_STATUS="waiting_for_new_seed"
        fi

        # M10.99Z3_SAFE_HEARTBEAT_JSON
        # Every string inserted into JSON must be escaped. PERF_LINE is raw log text.
        RUN_ID_JSON="$(printf '%s' "${RUN_ID:-}" | coded_json_escape)"
        RIG_ID_JSON="$(printf '%s' "${RIG_ID:-}" | coded_json_escape)"
        RUN_WORKER_JSON="$(printf '%s' "${RUN_WORKER:-}" | coded_json_escape)"
        BACKEND_JSON="$(printf '%s' "${CODED_KERNEL_BACKEND:-}" | coded_json_escape)"
        RUNTIME_STATUS_JSON="$(printf '%s' "${RUNTIME_STATUS:-running}" | coded_json_escape)"
        PERF_LINE_JSON="$(printf '%s' "${PERF_LINE:-}" | coded_json_escape)"

        RUNTIME_HEARTBEAT_PAYLOAD="$(cat <<JSON
{"run_id":"$RUN_ID_JSON","rig_id":"$RIG_ID_JSON","worker_name":"$RUN_WORKER_JSON","threshold":${THRESHOLD:-0},"threads":${THREADS:-0},"status":"$RUNTIME_STATUS_JSON","avg_its":${RUNTIME_AVG_ITS:-0},"last_its":${RUNTIME_LAST_ITS:-0},"active_backend":"$BACKEND_JSON","backend":"$BACKEND_JSON","meta":{"source":"fleet_wrapper","patch":"M10.99Z3_SAFE_HEARTBEAT_JSON","summary_present":$SUMMARY_PRESENT,"runtime_status":"$RUNTIME_STATUS_JSON","perf_line":"$PERF_LINE_JSON"}}
JSON
)"

        RUNTIME_HEARTBEAT_RESP="$(curl -s -X POST "$API/runs/heartbeat" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "$RUNTIME_HEARTBEAT_PAYLOAD" || true)"

        echo "[M10.99Z3_SAFE_HEARTBEAT_JSON] run=$RUN_ID worker=$RUN_WORKER status=${RUNTIME_STATUS:-unknown} avg_its=${RUNTIME_AVG_ITS:-0} last_its=${RUNTIME_LAST_ITS:-0} summary_present=$SUMMARY_PRESENT resp=$RUNTIME_HEARTBEAT_RESP" >> "$RUN_LOG" 2>/dev/null || true

        # Summary-dependent analytics continue below only if a real summary exists.
        # Runtime liveness/last_seen has already been sent above.
        [ -z "$SUMMARY" ] && continue

        extract(){ echo "$SUMMARY" | grep -oP "$1=\K[0-9.]+" | tail -n 1 || true; }

        TOTAL_SEEN="$(extract total_seen)"
        TOTAL_PASS="$(extract total_pass)"
        TOTAL_SKIP="$(extract total_skip)"
        TOTAL_AUDITED="$(extract total_audited)"
        FALSE_NEG="$(extract false_negative)"
        MAX_PASS="$(extract max_real_score_passed)"
        MAX_SKIP="$(extract max_real_score_audited_skip)"
        PASSRATE="$(extract pass_rate)"
        SKIPRATE="$(extract skip_rate)"
        AUDITRATE_OBS="$(extract audit_rate)"
        S280="$(extract pass_280_289)"
        S290="$(extract pass_290_299)"
        S300="$(extract pass_300_309)"
        S310="$(extract pass_310_320)"
        S321="$(extract pass_321_plus)"

        AVG_ITS="$(echo "$SOLS" | grep -oP "\| [0-9]+ avg it/s" | grep -oP "[0-9]+" | tail -n 1 || true)"
        LAST_ITS="$(echo "$SOLS" | grep -oP "\] [0-9]+ it/s" | grep -oP "[0-9]+" | tail -n 1 || true)"

        # M10.99Z1 fallback: summary payload should reuse heartbeat parser values.
        [ -z "${AVG_ITS:-}" ] && AVG_ITS="${RUNTIME_AVG_ITS:-0}"
        [ -z "${LAST_ITS:-}" ] && LAST_ITS="${RUNTIME_LAST_ITS:-0}"

        ALGO0_COUNT="$(echo "$HI" | grep -oP "algo0_count=\K[0-9.]+" | tail -n 1 || true)"
        ALGO0_AVG="$(echo "$HI" | grep -oP "algo0_avg_ms=\K[0-9.]+" | tail -n 1 || true)"
        ALGO0_MAX="$(echo "$HI" | grep -oP "algo0_max_ms=\K[0-9.]+" | tail -n 1 || true)"
        ALGO1_COUNT="$(echo "$HI" | grep -oP "algo1_count=\K[0-9.]+" | tail -n 1 || true)"
        ALGO1_AVG="$(echo "$HI" | grep -oP "algo1_avg_ms=\K[0-9.]+" | tail -n 1 || true)"
        ALGO1_MAX="$(echo "$HI" | grep -oP "algo1_max_ms=\K[0-9.]+" | tail -n 1 || true)"

        DIRECT_COUNT="$(echo "$DIRECT" | grep -oP "checked=\K[0-9.]+" | tail -n 1 || true)"
        DIRECT_NS="$(echo "$DIRECT" | grep -oP "total_ns=\K[0-9.]+" | tail -n 1 || true)"
        DIRECT_AVG="$(echo "$DIRECT" | grep -oP "avg_ms=\K[0-9.]+" | tail -n 1 || true)"
        DIRECT_ALGO0="$(echo "$DIRECT" | grep -oP "algo0=\K[0-9.]+" | tail -n 1 || true)"
        DIRECT_ALGO1="$(echo "$DIRECT" | grep -oP "algo1=\K[0-9.]+" | tail -n 1 || true)"
        DIRECT_TOTAL_MS="$(awk -v ns="${DIRECT_NS:-0}" 'BEGIN{ printf "%.6f", ns / 1000000.0 }' 2>/dev/null || echo 0)"

        curl -s -X POST "$API/runs/heartbeat" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"status\":\"running\",\"avg_its\":${AVG_ITS:-0},\"last_its\":${LAST_ITS:-0},\"active_backend\":\"$CODED_KERNEL_BACKEND\"}" >/dev/null || true

        curl -s -X POST "$API/runs/summary" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"run_id\":\"$RUN_ID\",\"total_seen\":${TOTAL_SEEN:-0},\"total_pass\":${TOTAL_PASS:-0},\"total_skip\":${TOTAL_SKIP:-0},\"total_audited\":${TOTAL_AUDITED:-0},\"false_negative\":${FALSE_NEG:-0},\"max_real_score_passed\":${MAX_PASS:-0},\"max_real_score_audited_skip\":${MAX_SKIP:-0},\"pass_rate\":${PASSRATE:-0},\"skip_rate\":${SKIPRATE:-0},\"audit_rate\":${AUDITRATE_OBS:-0},\"avg_its\":${AVG_ITS:-0},\"last_its\":${LAST_ITS:-0},\"algo0_avg_ms\":${ALGO0_AVG:-0}}" >/dev/null || true

        # M10.88J3 Performance Snapshot uploader
        # File payload + HTTP code/body debug. Best-effort only.
        PERF_PAYLOAD_FILE="/tmp/coded_perf_payload_${RUN_ID:-unknown}_${RIG_ID:-unknown}.json"
        PERF_BODY_FILE="/tmp/coded_perf_resp_${RUN_ID:-unknown}_${RIG_ID:-unknown}.txt"

        RUN_ID="${RUN_ID:-}" \
        RUN_MODE="${RUN_MODE:-fleet}" \
        RIG_ID="${RIG_ID:-}" \
        RUN_WORKER="${RUN_WORKER:-}" \
        EPOCH="${EPOCH:-0}" \
        CODED_GIT_COMMIT="${CODED_GIT_COMMIT:-unknown}" \
        CODED_RELEASE_CHANNEL="${CODED_RELEASE_CHANNEL:-hiveos}" \
        CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-unknown}" \
        THRESHOLD="${THRESHOLD:-0}" \
        THREADS="${THREADS:-0}" \
        BATCH="${BATCH:-0}" \
        AUDIT="${AUDIT:-0}" \
        CPU_MODEL="${CPU_MODEL:-}" \
        CPU_CORES="${CPU_CORES:-0}" \
        CPU_THREADS="${CPU_THREADS:-0}" \
        RAM_MB="${RAM_MB:-0}" \
        AVX2="${AVX2:-false}" \
        AVX512="${AVX512:-false}" \
        HPT="${HPT:-0}" \
        HPF="${HPF:-0}" \
        AVG_ITS="${AVG_ITS:-0}" \
        LAST_ITS="${LAST_ITS:-0}" \
        TOTAL_SEEN="${TOTAL_SEEN:-0}" \
        TOTAL_PASS="${TOTAL_PASS:-0}" \
        TOTAL_SKIP="${TOTAL_SKIP:-0}" \
        TOTAL_AUDITED="${TOTAL_AUDITED:-0}" \
        DIRECT_COUNT="${DIRECT_COUNT:-0}" \
        DIRECT_TOTAL_MS="${DIRECT_TOTAL_MS:-0}" \
        DIRECT_AVG="${DIRECT_AVG:-0}" \
        ALGO0_COUNT="${ALGO0_COUNT:-0}" \
        ALGO0_AVG="${ALGO0_AVG:-0}" \
        ALGO0_MAX="${ALGO0_MAX:-0}" \
        ALGO1_COUNT="${ALGO1_COUNT:-0}" \
        ALGO1_AVG="${ALGO1_AVG:-0}" \
        ALGO1_MAX="${ALGO1_MAX:-0}" \
        S280="${S280:-0}" \
        S290="${S290:-0}" \
        S300="${S300:-0}" \
        S310="${S310:-0}" \
        S321="${S321:-0}" \
        FALSE_NEG="${FALSE_NEG:-0}" \
        DIRECT_PRESENT="$([ -n "$DIRECT" ] && echo true || echo false)" \
        HI_PRESENT="$([ -n "$HI" ] && echo true || echo false)" \
        python3 - "$PERF_PAYLOAD_FILE" <<'PYJSON' || true
import json, os, sys

out = sys.argv[1]

def s(key, default=None):
    value = os.environ.get(key)
    if value is None or value == "":
        return default
    return str(value)

def n(key, default=0):
    value = os.environ.get(key)
    if value is None or value == "":
        return default
    try:
        if "." in str(value):
            return float(value)
        return int(value)
    except Exception:
        return default

def b(key):
    value = str(os.environ.get(key, "")).strip().lower()
    if value in ("1", "true", "yes", "y", "on"):
        return True
    if value in ("0", "false", "no", "n", "off"):
        return False
    return None

payload = {
    "run_id": s("RUN_ID"),
    "experiment_id": s("RUN_MODE", "fleet"),
    "rig_id": s("RIG_ID"),
    "worker_name": s("RUN_WORKER"),
    "epoch": n("EPOCH"),
    "miner_version": "m10.88j3-performance-uploader",
    "git_commit": s("CODED_GIT_COMMIT", "unknown"),
    "release_channel": s("CODED_RELEASE_CHANNEL", "hiveos"),

    "backend": s("CODED_KERNEL_BACKEND", "unknown"),
    "active_backend": s("CODED_KERNEL_BACKEND", "unknown"),
    "threshold": n("THRESHOLD"),
    "threads": n("THREADS"),
    "batch_size": n("BATCH"),
    "audit_rate": n("AUDIT"),

    "cpu_model": s("CPU_MODEL"),
    "cpu_cores": n("CPU_CORES"),
    "cpu_threads": n("CPU_THREADS"),
    "ram_mb": n("RAM_MB"),
    "avx2_supported": b("AVX2"),
    "avx512_supported": b("AVX512"),
    "hugepages_total": n("HPT"),
    "hugepages_free": n("HPF"),

    "avg_its": n("AVG_ITS"),
    "last_its": n("LAST_ITS"),
    "total_seen": n("TOTAL_SEEN"),
    "total_pass": n("TOTAL_PASS"),
    "total_skip": n("TOTAL_SKIP"),
    "total_audited": n("TOTAL_AUDITED"),

    "fullscore_count": n("DIRECT_COUNT"),
    "fullscore_total_ms": n("DIRECT_TOTAL_MS"),
    "fullscore_avg_ms": n("DIRECT_AVG"),
    "fullscore_max_ms": n("DIRECT_AVG"),

    "algo0_count": n("ALGO0_COUNT"),
    "algo0_avg_ms": n("ALGO0_AVG"),
    "algo0_max_ms": n("ALGO0_MAX"),
    "algo1_count": n("ALGO1_COUNT"),
    "algo1_avg_ms": n("ALGO1_AVG"),
    "algo1_max_ms": n("ALGO1_MAX"),

    "real280": n("S280"),
    "real290": n("S290"),
    "real300": n("S300"),
    "real310": n("S310"),
    "real321": n("S321"),
    "false_negative": n("FALSE_NEG"),

    "raw": {
        "source": "fleet_uploader",
        "m10_88j3": True,
        "direct_score_present": b("DIRECT_PRESENT"),
        "hi_timing_present": b("HI_PRESENT"),
    },
}

with open(out, "w", encoding="utf-8") as f:
    json.dump(payload, f, separators=(",", ":"))
PYJSON

        # M10.88K_PERFORMANCE_URL_FIX
        # Build performance endpoint from the same API root family as analytics.
        # Old M10.88J used "$PERF_URL", which can hit a frontend/HTML route.
        PERF_API_BASE="${CODED_API_ROOT:-${API:-http://127.0.0.1:4000}}"
        PERF_API_BASE="${PERF_API_BASE%/}"
        if echo "$PERF_API_BASE" | grep -q '/analytics$'; then
          PERF_URL="${PERF_API_BASE}/performance-snapshot"
        else
          PERF_URL="${PERF_API_BASE}/analytics/performance-snapshot"
        fi
        echo "[M10.88K_PERFORMANCE_ATTEMPT] run=$RUN_ID rig=$RIG_ID worker=$RUN_WORKER url=$PERF_URL payload=$PERF_PAYLOAD_FILE" | tee -a "$RUN_LOG" 2>/dev/null || true

        PERF_HTTP_CODE="payload_missing"
        if [ -s "$PERF_PAYLOAD_FILE" ]; then
          PERF_HTTP_CODE="$(curl -sS --connect-timeout 3 --max-time 8 \
            -o "$PERF_BODY_FILE" \
            -w "%{http_code}" \
            -X POST "$PERF_URL" \
            -H "Authorization: Bearer $TOKEN" \
            -H "Content-Type: application/json" \
            --data-binary "@$PERF_PAYLOAD_FILE" || echo "curl_failed")"
        fi

        PERF_BODY_HEAD="$(head -c 240 "$PERF_BODY_FILE" 2>/dev/null || true)"
        if [ "$PERF_HTTP_CODE" = "200" ] && echo "$PERF_BODY_HEAD" | grep -q '"ok":true'; then
          echo "[M10.88K_PERFORMANCE_SENT] run=$RUN_ID rig=$RIG_ID worker=$RUN_WORKER http=$PERF_HTTP_CODE" | tee -a "$RUN_LOG" 2>/dev/null || true
        else
          echo "[M10.88K_PERFORMANCE_ERROR] run=$RUN_ID rig=$RIG_ID worker=$RUN_WORKER url=$PERF_URL http=$PERF_HTTP_CODE body=$PERF_BODY_HEAD" | tee -a "$RUN_LOG" 2>/dev/null || true
        fi
        echo "[M10.88K_PERFORMANCE_HTTP] run=$RUN_ID rig=$RIG_ID worker=$RUN_WORKER url=$PERF_URL http=$PERF_HTTP_CODE payload=$PERF_PAYLOAD_FILE fullscore_count=${DIRECT_COUNT:-0} algo0_avg_ms=${ALGO0_AVG:-0} algo1_avg_ms=${ALGO1_AVG:-0} body=$PERF_BODY_HEAD"


        # M10.86 Statistical Fleet Analysis Engine
        # Same analytics pipeline as runs/summary: miner stdout -> wrapper parser -> pool-api -> Supabase.
        MAX_SCORE="$MAX_PASS"
        if [ "${MAX_SKIP:-0}" -gt "${MAX_SCORE:-0}" ] 2>/dev/null; then
          MAX_SCORE="$MAX_SKIP"
        fi

        SCORE_DIST_PAYLOAD="{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"epoch\":${EPOCH:-0},\"backend\":\"$CODED_KERNEL_BACKEND\",\"cpu_model\":\"$CPU_MODEL\",\"threshold\":${THRESHOLD:-0},\"threads\":${THREADS:-0},\"batch_size\":${BATCH:-0},\"audit_rate\":${AUDIT:-0},\"total_seen\":${TOTAL_SEEN:-0},\"total_pass\":${TOTAL_PASS:-0},\"total_skip\":${TOTAL_SKIP:-0},\"total_audited\":${TOTAL_AUDITED:-0},\"false_negative\":${FALSE_NEG:-0},\"max_score\":${MAX_SCORE:-0},\"max_pass_score\":${MAX_PASS:-0},\"max_audited_skip_score\":${MAX_SKIP:-0},\"score_260_269\":0,\"score_270_279\":0,\"score_280_289\":${S280:-0},\"score_290_299\":${S290:-0},\"score_300_309\":${S300:-0},\"score_310_320\":${S310:-0},\"score_321_plus\":${S321:-0},\"raw\":{\"source\":\"fleet_uploader\"}}"
        SCORE_DIST_RESP="$(curl -s -X POST "$API/score-distribution" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "$SCORE_DIST_PAYLOAD" || true)"
        echo "[M10.86_SCORE_DIST] run=$RUN_ID resp=$SCORE_DIST_RESP"

        # M10.89B Shadow Policy uploader
        # Miner stdout -> fleet wrapper -> pool-api -> Supabase.
        if [ -n "$POLICY" ]; then
          for PNAME in baseline elite509 hard511 dual510511; do
            P_PASS="$(echo "$POLICY" | grep -oP "${PNAME}_pass=\\K[0-9]+" | tail -n 1 || true)"

            # M10.92A extended shadow policy uploader metrics
            P_280="$(echo "$POLICY" | grep -oP "${PNAME}_real280=\\K[0-9]+" | tail -n 1 || true)"
            P_290="$(echo "$POLICY" | grep -oP "${PNAME}_real290=\\K[0-9]+" | tail -n 1 || true)"
            P_300="$(echo "$POLICY" | grep -oP "${PNAME}_real300=\\K[0-9]+" | tail -n 1 || true)"
            P_310="$(echo "$POLICY" | grep -oP "${PNAME}_real310=\\K[0-9]+" | tail -n 1 || true)"
            P_321="$(echo "$POLICY" | grep -oP "${PNAME}_real321=\\K[0-9]+" | tail -n 1 || true)"

            P_PASS_PER_SEEN="null"
            P_300_PER_PASS="null"
            P_310_PER_PASS="null"
            if [ "${TOTAL_SEEN:-0}" -gt 0 ] 2>/dev/null; then
              P_PASS_PER_SEEN="$(awk -v p="${P_PASS:-0}" -v s="${TOTAL_SEEN:-0}" 'BEGIN{ if(s>0) printf "%.12f", p/s; else print "null" }')"
            fi
            if [ "${P_PASS:-0}" -gt 0 ] 2>/dev/null; then
              P_300_PER_PASS="$(awk -v r="${P_300:-0}" -v p="${P_PASS:-0}" 'BEGIN{ if(p>0) printf "%.12f", r/p; else print "null" }')"
              P_310_PER_PASS="$(awk -v r="${P_310:-0}" -v p="${P_PASS:-0}" 'BEGIN{ if(p>0) printf "%.12f", r/p; else print "null" }')"
            fi

            POLICY_RESP="$(curl -s -X POST "$API/shadow-policy" \
              -H "Authorization: Bearer $TOKEN" \
              -H "Content-Type: application/json" \
              -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"threshold\":${THRESHOLD:-0},\"policy_name\":\"$PNAME\",\"pass\":${P_PASS:-0},\"real280\":${P_280:-0},\"real290\":${P_290:-0},\"real300\":${P_300:-0},\"real310\":${P_310:-0},\"real321\":${P_321:-0},\"pass_per_seen\":${P_PASS_PER_SEEN:-null},\"real300_per_pass\":${P_300_PER_PASS:-null},\"real310_per_pass\":${P_310_PER_PASS:-null},\"raw\":{\"source\":\"fleet_uploader\",\"line\":\"FAST_SHADOW_POLICY\",\"m10_92a\":true}}" || true)"

            echo "[M10.89_POLICY] run=$RUN_ID policy=$PNAME resp=$POLICY_RESP"
          done
        fi

        # M10.88B Shadow Histogram uploader
        # Same pipeline as runs/summary, score-distribution and multilevel-shadow.
        if [ -n "$HIST" ]; then
          for SS in $(seq 480 520); do
            H_TOTAL="$(echo "$HIST" | grep -oP "s${SS}=\\K[0-9]+" | tail -n 1 || true)"
            H_300="$(echo "$HIST" | grep -oP "s300_${SS}=\\K[0-9]+" | tail -n 1 || true)"
            H_310="$(echo "$HIST" | grep -oP "s310_${SS}=\\K[0-9]+" | tail -n 1 || true)"
            H_321="$(echo "$HIST" | grep -oP "s321_${SS}=\\K[0-9]+" | tail -n 1 || true)"

            HIST_RESP="$(curl -s -X POST "$API/shadow-histogram" \
              -H "Authorization: Bearer $TOKEN" \
              -H "Content-Type: application/json" \
              -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"threshold\":${THRESHOLD:-0},\"shadow_score\":${SS},\"total\":${H_TOTAL:-0},\"real300\":${H_300:-0},\"real310\":${H_310:-0},\"real321\":${H_321:-0},\"raw\":{\"source\":\"fleet_uploader\",\"line\":\"FAST_SHADOW_HISTOGRAM\"}}" || true)"

            echo "[M10.88_HISTOGRAM] run=$RUN_ID shadow=$SS resp=$HIST_RESP"
          done
        fi

        # M10.88A Priority Budget Router uploader
        # Miner stdout -> fleet wrapper -> pool-api -> Supabase.
        # Captures full [PRIORITY_BUDGET_ROUTER] lines once per uploader loop.
        if [ -n "$BUDGET" ]; then
          bval(){
            local v
            v="$(echo "$BUDGET" | grep -oP "$1=\K[0-9.]+" | tail -n 1 || true)"
            [ -n "$v" ] && echo "$v" || echo 0
          }

          bstr(){
            local v
            v="$(echo "$BUDGET" | grep -oP "$1=\K[^[:space:]]+" | tail -n 1 || true)"
            [ -n "$v" ] && echo "$v" || echo unknown
          }

          json_escape(){
            python3 -c 'import json,sys; print(json.dumps(sys.stdin.read())[1:-1])'
          }

          PB_VERSION="$(bstr version)"
          PB_MATRIX="$(bstr matrix)"
          PB_RAW_ESCAPED="$(printf '%s' "$BUDGET" | json_escape)"

          PB_PAYLOAD="{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"threshold\":${THRESHOLD:-0},\"version\":\"${PB_VERSION:-unknown}\",\"matrix\":\"${PB_MATRIX:-unknown}\""

          for PC in 0 1 2 3; do
            PB_PAYLOAD="$PB_PAYLOAD,\"p${PC}_seen\":$(bval p${PC}_seen),\"p${PC}_scored\":$(bval p${PC}_scored),\"p${PC}_skipped\":$(bval p${PC}_skipped),\"p${PC}_score_rate\":$(bval p${PC}_score_rate),\"p${PC}_real280\":$(bval p${PC}_real280),\"p${PC}_real290\":$(bval p${PC}_real290),\"p${PC}_real300\":$(bval p${PC}_real300),\"p${PC}_real310\":$(bval p${PC}_real310),\"p${PC}_real321\":$(bval p${PC}_real321),\"p${PC}_d300\":$(bval p${PC}_d300),\"p${PC}_d321\":$(bval p${PC}_d321)"
          done

          PB_PAYLOAD="$PB_PAYLOAD,\"audited_skip\":$(bval audited_skip),\"false_negative\":$(bval false_negative),\"raw\":{\"source\":\"fleet_uploader\",\"line\":\"$PB_RAW_ESCAPED\",\"m10_88a\":true}}"

          PB_RESP="$(curl -sS --connect-timeout 3 --max-time 8 -X POST "$API/priority-budget" \
            -H "Authorization: Bearer $TOKEN" \
            -H "Content-Type: application/json" \
            -d "$PB_PAYLOAD" || true)"

          echo "[M10.88J6B_PERFORMANCE_ATTEMPT] run=$RUN_ID rig=$RIG_ID worker=$RUN_WORKER before_priority_echo=1 pb_version=${PB_VERSION:-unknown} matrix=${PB_MATRIX:-unknown}"
          echo "[M10.88A_PRIORITY_BUDGET] run=$RUN_ID version=${PB_VERSION:-unknown} matrix=${PB_MATRIX:-unknown} resp=$PB_RESP"

          # M10.88J6B Performance Snapshot attached to the exact live priority-budget echo path.
          PERF_PAYLOAD_FILE="/tmp/coded_perf_payload_${RUN_ID:-unknown}_${RIG_ID:-unknown}.json"
          PERF_BODY_FILE="/tmp/coded_perf_resp_${RUN_ID:-unknown}_${RIG_ID:-unknown}.txt"

          if [ -z "${RUN_ID:-}" ] || [ -z "${RIG_ID:-}" ]; then
            echo "[M10.88J6B_PERFORMANCE_SKIP reason=missing_run_or_rig run=${RUN_ID:-unset} rig=${RIG_ID:-unset}]"
          elif [ -z "${API:-}" ] || [ -z "${TOKEN:-}" ]; then
            echo "[M10.88J6B_PERFORMANCE_SKIP reason=missing_api_or_token api=${API:-unset} token_present=$([ -n "${TOKEN:-}" ] && echo yes || echo no)]"
          else
            RUN_ID="${RUN_ID:-}" \
            RUN_MODE="${RUN_MODE:-fleet}" \
            RIG_ID="${RIG_ID:-}" \
            RUN_WORKER="${RUN_WORKER:-}" \
            THRESHOLD="${THRESHOLD:-0}" \
            CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-unknown}" \
            THREADS="${THREADS:-0}" \
            BATCH="${BATCH:-0}" \
            AUDIT="${AUDIT:-0}" \
            AVG_ITS="${AVG_ITS:-0}" \
            LAST_ITS="${LAST_ITS:-0}" \
            TOTAL_SEEN="${TOTAL_SEEN:-0}" \
            TOTAL_PASS="${TOTAL_PASS:-0}" \
            TOTAL_SKIP="${TOTAL_SKIP:-0}" \
            TOTAL_AUDITED="${TOTAL_AUDITED:-0}" \
            ALGO0_AVG="${ALGO0_AVG:-0}" \
            ALGO1_AVG="${ALGO1_AVG:-0}" \
            S280="${S280:-0}" \
            S290="${S290:-0}" \
            S300="${S300:-0}" \
            S310="${S310:-0}" \
            S321="${S321:-0}" \
            FALSE_NEG="${FALSE_NEG:-0}" \
            PB_VERSION="${PB_VERSION:-unknown}" \
            PB_MATRIX="${PB_MATRIX:-unknown}" \
            python3 - "$PERF_PAYLOAD_FILE" <<'PYJSON' || true
import json, os, sys

out = sys.argv[1]

def s(k, d=None):
    v = os.environ.get(k)
    return d if v is None or v == "" else str(v)

def n(k, d=0):
    v = os.environ.get(k)
    if v is None or v == "":
        return d
    try:
        return float(v) if "." in str(v) else int(v)
    except Exception:
        return d

payload = {
    "run_id": s("RUN_ID"),
    "experiment_id": s("RUN_MODE", "fleet"),
    "rig_id": s("RIG_ID"),
    "worker_name": s("RUN_WORKER"),
    "miner_version": "m10.88j6b-live-priority-echo",
    "release_channel": "hiveos",
    "backend": s("CODED_KERNEL_BACKEND", "unknown"),
    "active_backend": s("CODED_KERNEL_BACKEND", "unknown"),
    "threshold": n("THRESHOLD"),
    "threads": n("THREADS"),
    "batch_size": n("BATCH"),
    "audit_rate": n("AUDIT"),
    "avg_its": n("AVG_ITS"),
    "last_its": n("LAST_ITS"),
    "total_seen": n("TOTAL_SEEN"),
    "total_pass": n("TOTAL_PASS"),
    "total_skip": n("TOTAL_SKIP"),
    "total_audited": n("TOTAL_AUDITED"),
    "fullscore_count": n("TOTAL_PASS"),
    "fullscore_total_ms": 0,
    "fullscore_avg_ms": n("ALGO0_AVG"),
    "fullscore_max_ms": n("ALGO0_AVG"),
    "algo0_count": n("TOTAL_PASS"),
    "algo0_avg_ms": n("ALGO0_AVG"),
    "algo0_max_ms": n("ALGO0_AVG"),
    "algo1_count": 0,
    "algo1_avg_ms": n("ALGO1_AVG"),
    "algo1_max_ms": n("ALGO1_AVG"),
    "real280": n("S280"),
    "real290": n("S290"),
    "real300": n("S300"),
    "real310": n("S310"),
    "real321": n("S321"),
    "false_negative": n("FALSE_NEG"),
    "raw": {
        "source": "fleet_uploader",
        "m10_88j6b": True,
        "attached_to": "exact_M10.88A_PRIORITY_BUDGET_echo",
        "priority_budget_version": s("PB_VERSION"),
        "priority_budget_matrix": s("PB_MATRIX")
    }
}

with open(out, "w", encoding="utf-8") as f:
    json.dump(payload, f, separators=(",", ":"))
PYJSON

            if [ ! -s "$PERF_PAYLOAD_FILE" ]; then
              echo "[M10.88J6B_PERFORMANCE_SKIP reason=payload_missing payload=$PERF_PAYLOAD_FILE]"
            else
              PERF_HTTP_CODE="$(curl -sS --connect-timeout 3 --max-time 8 \
                -o "$PERF_BODY_FILE" \
                -w "%{http_code}" \
                -X POST "$PERF_URL" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                --data-binary "@$PERF_PAYLOAD_FILE" || echo "curl_failed")"

              PERF_BODY_HEAD="$(head -c 220 "$PERF_BODY_FILE" 2>/dev/null || true)"

              if [ "$PERF_HTTP_CODE" = "200" ] && echo "$PERF_BODY_HEAD" | grep -q '"ok":true'; then
                echo "[M10.88J6B_PERFORMANCE_SENT] run=$RUN_ID rig=$RIG_ID worker=$RUN_WORKER http=$PERF_HTTP_CODE payload=$PERF_PAYLOAD_FILE body=$PERF_BODY_HEAD"
              else
                echo "[M10.88J6B_PERFORMANCE_ERROR http=$PERF_HTTP_CODE run=$RUN_ID rig=$RIG_ID worker=$RUN_WORKER payload=$PERF_PAYLOAD_FILE body=$PERF_BODY_HEAD]"
              fi
            fi
          fi

          # M10.88J5 Performance Snapshot uploader after active priority-budget path
          # Guarded so duplicate priority blocks do not send duplicate performance rows in one loop.
          if [ "${M1088J5_PERF_SENT:-0}" != "1" ]; then
            M1088J5_PERF_SENT=1

            PERF_PAYLOAD_FILE="/tmp/coded_perf_payload_${RUN_ID:-unknown}_${RIG_ID:-unknown}.json"
            PERF_BODY_FILE="/tmp/coded_perf_resp_${RUN_ID:-unknown}_${RIG_ID:-unknown}.txt"

            RUN_ID="${RUN_ID:-}" \
            RUN_MODE="${RUN_MODE:-fleet}" \
            RIG_ID="${RIG_ID:-}" \
            RUN_WORKER="${RUN_WORKER:-}" \
            THRESHOLD="${THRESHOLD:-0}" \
            CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-unknown}" \
            THREADS="${THREADS:-0}" \
            BATCH="${BATCH:-0}" \
            AUDIT="${AUDIT:-0}" \
            AVG_ITS="${AVG_ITS:-0}" \
            LAST_ITS="${LAST_ITS:-0}" \
            TOTAL_SEEN="${TOTAL_SEEN:-0}" \
            TOTAL_PASS="${TOTAL_PASS:-0}" \
            TOTAL_SKIP="${TOTAL_SKIP:-0}" \
            TOTAL_AUDITED="${TOTAL_AUDITED:-0}" \
            ALGO0_AVG="${ALGO0_AVG:-0}" \
            ALGO1_AVG="${ALGO1_AVG:-0}" \
            S280="${S280:-0}" \
            S290="${S290:-0}" \
            S300="${S300:-0}" \
            S310="${S310:-0}" \
            S321="${S321:-0}" \
            FALSE_NEG="${FALSE_NEG:-0}" \
            PB_VERSION="${PB_VERSION:-unknown}" \
            PB_MATRIX="${PB_MATRIX:-unknown}" \
            python3 - "$PERF_PAYLOAD_FILE" <<'PYJSON' || true
import json, os, sys

out = sys.argv[1]

def s(k, d=None):
    v = os.environ.get(k)
    return d if v is None or v == "" else str(v)

def n(k, d=0):
    v = os.environ.get(k)
    if v is None or v == "":
        return d
    try:
        return float(v) if "." in str(v) else int(v)
    except Exception:
        return d

payload = {
    "run_id": s("RUN_ID"),
    "experiment_id": s("RUN_MODE", "fleet"),
    "rig_id": s("RIG_ID"),
    "worker_name": s("RUN_WORKER"),
    "miner_version": "m10.88j5-after-active-priority-budget",
    "release_channel": "hiveos",
    "backend": s("CODED_KERNEL_BACKEND", "unknown"),
    "active_backend": s("CODED_KERNEL_BACKEND", "unknown"),
    "threshold": n("THRESHOLD"),
    "threads": n("THREADS"),
    "batch_size": n("BATCH"),
    "audit_rate": n("AUDIT"),
    "avg_its": n("AVG_ITS"),
    "last_its": n("LAST_ITS"),
    "total_seen": n("TOTAL_SEEN"),
    "total_pass": n("TOTAL_PASS"),
    "total_skip": n("TOTAL_SKIP"),
    "total_audited": n("TOTAL_AUDITED"),
    "fullscore_count": n("TOTAL_PASS"),
    "fullscore_total_ms": 0,
    "fullscore_avg_ms": n("ALGO0_AVG"),
    "fullscore_max_ms": n("ALGO0_AVG"),
    "algo0_count": n("TOTAL_PASS"),
    "algo0_avg_ms": n("ALGO0_AVG"),
    "algo0_max_ms": n("ALGO0_AVG"),
    "algo1_count": 0,
    "algo1_avg_ms": n("ALGO1_AVG"),
    "algo1_max_ms": n("ALGO1_AVG"),
    "real280": n("S280"),
    "real290": n("S290"),
    "real300": n("S300"),
    "real310": n("S310"),
    "real321": n("S321"),
    "false_negative": n("FALSE_NEG"),
    "raw": {
        "source": "fleet_uploader",
        "m10_88j5": True,
        "attached_after": "M10.88A_PRIORITY_BUDGET",
        "priority_budget_version": s("PB_VERSION"),
        "priority_budget_matrix": s("PB_MATRIX")
    }
}

with open(out, "w", encoding="utf-8") as f:
    json.dump(payload, f, separators=(",", ":"))
PYJSON

            PERF_HTTP_CODE="payload_missing"
            if [ -s "$PERF_PAYLOAD_FILE" ]; then
              PERF_HTTP_CODE="$(curl -sS --connect-timeout 3 --max-time 8 \
                -o "$PERF_BODY_FILE" \
                -w "%{http_code}" \
                -X POST "$PERF_URL" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                --data-binary "@$PERF_PAYLOAD_FILE" || echo "curl_failed")"
            fi

            PERF_BODY_HEAD="$(head -c 200 "$PERF_BODY_FILE" 2>/dev/null || true)"
            echo "[M10.88J5_PERFORMANCE] run=$RUN_ID rig=$RIG_ID worker=$RUN_WORKER http=$PERF_HTTP_CODE payload=$PERF_PAYLOAD_FILE avg_its=${AVG_ITS:-0} algo0_avg_ms=${ALGO0_AVG:-0} body=$PERF_BODY_HEAD"
          fi

          # M10.88J4 Performance Snapshot uploader after priority-budget
          # Attached to the known-good priority-budget uploader path.
          # Purpose: performance/cost layer beside priority-budget quality layer.
          PERF_PAYLOAD_FILE="/tmp/coded_perf_payload_${RUN_ID:-unknown}_${RIG_ID:-unknown}.json"
          PERF_BODY_FILE="/tmp/coded_perf_resp_${RUN_ID:-unknown}_${RIG_ID:-unknown}.txt"

          RUN_ID="${RUN_ID:-}" \
          RUN_MODE="${RUN_MODE:-fleet}" \
          RIG_ID="${RIG_ID:-}" \
          RUN_WORKER="${RUN_WORKER:-}" \
          THRESHOLD="${THRESHOLD:-0}" \
          CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-unknown}" \
          THREADS="${THREADS:-0}" \
          BATCH="${BATCH:-0}" \
          AUDIT="${AUDIT:-0}" \
          AVG_ITS="${AVG_ITS:-0}" \
          LAST_ITS="${LAST_ITS:-0}" \
          TOTAL_SEEN="${TOTAL_SEEN:-0}" \
          TOTAL_PASS="${TOTAL_PASS:-0}" \
          TOTAL_SKIP="${TOTAL_SKIP:-0}" \
          TOTAL_AUDITED="${TOTAL_AUDITED:-0}" \
          ALGO0_AVG="${ALGO0_AVG:-0}" \
          ALGO1_AVG="${ALGO1_AVG:-0}" \
          S280="${S280:-0}" \
          S290="${S290:-0}" \
          S300="${S300:-0}" \
          S310="${S310:-0}" \
          S321="${S321:-0}" \
          FALSE_NEG="${FALSE_NEG:-0}" \
          PB_VERSION="${PB_VERSION:-unknown}" \
          PB_MATRIX="${PB_MATRIX:-unknown}" \
          python3 - "$PERF_PAYLOAD_FILE" <<'PYJSON' || true
import json, os, sys

out = sys.argv[1]

def s(k, d=None):
    v = os.environ.get(k)
    return d if v is None or v == "" else str(v)

def n(k, d=0):
    v = os.environ.get(k)
    if v is None or v == "":
        return d
    try:
        return float(v) if "." in str(v) else int(v)
    except Exception:
        return d

payload = {
    "run_id": s("RUN_ID"),
    "experiment_id": s("RUN_MODE", "fleet"),
    "rig_id": s("RIG_ID"),
    "worker_name": s("RUN_WORKER"),

    "miner_version": "m10.88j4-after-priority-budget",
    "release_channel": "hiveos",

    "backend": s("CODED_KERNEL_BACKEND", "unknown"),
    "active_backend": s("CODED_KERNEL_BACKEND", "unknown"),
    "threshold": n("THRESHOLD"),
    "threads": n("THREADS"),
    "batch_size": n("BATCH"),
    "audit_rate": n("AUDIT"),

    "avg_its": n("AVG_ITS"),
    "last_its": n("LAST_ITS"),
    "total_seen": n("TOTAL_SEEN"),
    "total_pass": n("TOTAL_PASS"),
    "total_skip": n("TOTAL_SKIP"),
    "total_audited": n("TOTAL_AUDITED"),

    "fullscore_count": n("TOTAL_PASS"),
    "fullscore_total_ms": 0,
    "fullscore_avg_ms": n("ALGO0_AVG"),
    "fullscore_max_ms": n("ALGO0_AVG"),

    "algo0_count": n("TOTAL_PASS"),
    "algo0_avg_ms": n("ALGO0_AVG"),
    "algo0_max_ms": n("ALGO0_AVG"),
    "algo1_count": 0,
    "algo1_avg_ms": n("ALGO1_AVG"),
    "algo1_max_ms": n("ALGO1_AVG"),

    "real280": n("S280"),
    "real290": n("S290"),
    "real300": n("S300"),
    "real310": n("S310"),
    "real321": n("S321"),
    "false_negative": n("FALSE_NEG"),

    "raw": {
        "source": "fleet_uploader",
        "m10_88j4": True,
        "attached_after": "M10.88A_PRIORITY_BUDGET",
        "priority_budget_version": s("PB_VERSION"),
        "priority_budget_matrix": s("PB_MATRIX"),
    },
}

with open(out, "w", encoding="utf-8") as f:
    json.dump(payload, f, separators=(",", ":"))
PYJSON

          PERF_HTTP_CODE="payload_missing"
          if [ -s "$PERF_PAYLOAD_FILE" ]; then
            PERF_HTTP_CODE="$(curl -sS --connect-timeout 3 --max-time 8 \
              -o "$PERF_BODY_FILE" \
              -w "%{http_code}" \
              -X POST "$PERF_URL" \
              -H "Authorization: Bearer $TOKEN" \
              -H "Content-Type: application/json" \
              --data-binary "@$PERF_PAYLOAD_FILE" || echo "curl_failed")"
          fi

          PERF_BODY_HEAD="$(head -c 200 "$PERF_BODY_FILE" 2>/dev/null || true)"
          echo "[M10.88J4_PERFORMANCE] run=$RUN_ID rig=$RIG_ID worker=$RUN_WORKER http=$PERF_HTTP_CODE payload=$PERF_PAYLOAD_FILE avg_its=${AVG_ITS:-0} algo0_avg_ms=${ALGO0_AVG:-0} body=$PERF_BODY_HEAD"
        fi

        # M10.87E Multi-Level Shadow uploader
        # Same pipeline as runs/summary and score-distribution.
        if [ -n "$MULTI" ]; then
          for VT in 505 507 509 510 511 513 515 518 520; do
            ML_TOTAL="$(echo "$MULTI" | grep -oP "survive_${VT}=\\K[0-9]+" | tail -n 1 || true)"
            ML_300="$(echo "$MULTI" | grep -oP "survive_300_plus_${VT}=\\K[0-9]+" | tail -n 1 || true)"
            ML_310="$(echo "$MULTI" | grep -oP "survive_310_plus_${VT}=\\K[0-9]+" | tail -n 1 || true)"
            ML_321="$(echo "$MULTI" | grep -oP "survive_321_plus_${VT}=\\K[0-9]+" | tail -n 1 || true)"

            ML_RESP="$(curl -s -X POST "$API/multilevel-shadow" \
              -H "Authorization: Bearer $TOKEN" \
              -H "Content-Type: application/json" \
              -d "{\"run_id\":\"$RUN_ID\",\"rig_id\":\"$RIG_ID\",\"worker_name\":\"$RUN_WORKER\",\"threshold\":${THRESHOLD:-0},\"virtual_threshold\":${VT},\"survive_total\":${ML_TOTAL:-0},\"survive_300_plus\":${ML_300:-0},\"survive_310_plus\":${ML_310:-0},\"survive_321_plus\":${ML_321:-0},\"raw\":{\"source\":\"fleet_uploader\",\"line\":\"FAST_SHADOW_MULTILEVEL\"}}" || true)"

            echo "[M10.87_MULTILEVEL] run=$RUN_ID vt=$VT resp=$ML_RESP"
          done
        fi
      done
    ) >/tmp/coded_fleet_uploader_${RUN_ID}.log 2>&1 &
    UPLOADER_PID=$!

    echo "[CODED_FLEET] uploader pid=$UPLOADER_PID log=/tmp/coded_fleet_uploader_${RUN_ID}.log"

    # ============================================================
    # M10.90A Interruptible Fleet Agent
    # ============================================================
    # Run miner in restartable slices so high-priority commands
    # such as stop_run/build_release can interrupt a long run.
    INTERRUPT_CMD=""
    INTERRUPT_TYPE=""

    # M10.91C Launcher Command Completion
    # start_run is a launcher command, not the runtime source of truth.
    # Runtime truth is miner_run_dashboard / runs heartbeat.
    START_RUN_LAUNCH_COMPLETED=0

    while [ "$SECONDS" -lt "$END" ]; do
      coded_apply_start_run_params_override || true
    # M10.99Z191_POST_OVERRIDE_START_RUN_RUNTIME_HANDOFF_CALL
    coded_z191_start_run_post_override_handoff "after_coded_apply_start_run_params_override" || true
      coded_enforce_expected_worker_before_launch || true
      # ============================================================
      # M10.96G8U launch-loop worker override
      # ============================================================
      # This is the actual runtime launch path. Apply command params
      # immediately before miner execution so experiment start_run cannot
      # be overwritten by default analytics profile values.
      coded_apply_start_run_params_override || true
    # M10.99Z191_POST_OVERRIDE_START_RUN_RUNTIME_HANDOFF_CALL
    coded_z191_start_run_post_override_handoff "after_coded_apply_start_run_params_override" || true
      coded_enforce_expected_worker_before_launch || true
      echo "[M10.96G8U_LAUNCH_LOOP_OVERRIDE] command=$COMMAND_ID run=$RUN_ID worker=$RUN_WORKER threads=$THREADS threshold=$THRESHOLD backend=${BACKEND:-}" | tee -a "$RUN_LOG"

      # ============================================================
      # M10.99P_FINAL_MINER_LAUNCH_ENV
      # ------------------------------------------------------------
      # Last possible point before the actual coded-miner process.
      # params.env must be authoritative here.
      # ============================================================
      if [ -n "${PARAMS:-}" ]; then
        coded_m1099m_export_params_env "$PARAMS" "$RUN_LOG" || true
      fi

      coded_m1099n_assert_launch_env "${PARAMS:-}" "$RUN_WORKER" "$RUN_LOG" || true
      coded_m1099o_debug_env_before_launch "$RUN_WORKER" "$RUN_LOG" || true

      coded_m1099q_resolve_priority_budget_router "${PARAMS:-}" "$RUN_WORKER" "$RUN_LOG" || true
      # M10.99Z22_FINALIZER_BEFORE_MINER_LAUNCH
      # Final command intent wins directly before miner launch.
      if [ -n "${PARAMS:-}" ]; then
        coded_m1099z22_finalize_priority_router_intent "$PARAMS" "$RUN_LOG" || true
      else
        coded_m1099z22_finalize_priority_router_intent "{}" "$RUN_LOG" || true
      fi


      # M10.99Z23_FORCE_ROUTER_ENV_IN_BINARY_LAUNCH
# Final hard guard directly before miner binary launch.
# Reason: command params can carry M1098E correctly while older fallback/default logic
# can still leave CODED_PRIORITY_BUDGET_ROUTER=M1098C in the actual process env.
# Runtime worker/params/experiment containing M1098E must force the binary env to M1098E.
if echo "${RUN_WORKER:-} ${WORKER_NAME:-} ${CODED_WORKER_NAME:-} ${PARAMS:-} ${COMMAND_JSON:-} ${EXPERIMENT_ID:-}" | grep -q "M1098E"; then
  export CODED_PRIORITY_BUDGET_ROUTER="$(m1091l_default_router_for_threshold "${CODED_FAST_SHADOW_THRESHOLD:-${THRESHOLD:-510}}")"
coded_z108_apply_hive_flightsheet_default || true
  echo "[M10.99Z23_FORCE_ROUTER_ENV_IN_BINARY_LAUNCH] forced CODED_PRIORITY_BUDGET_ROUTER=M1098E worker=${RUN_WORKER:-${WORKER_NAME:-unknown}} experiment_id=${EXPERIMENT_ID:-unknown}" | tee -a "$RUN_LOG"
fi

# M1091L_FINAL_CANONICAL_ENV_GUARD
case "${RUN_WORKER:-${WORKER_NAME:-}}" in
  Rig1X3D_M1091B_REAL321_T508_DENSITY|Rig2X3D_M1091B_REAL321_T509_BIAS_BREAK|Rig3X_M1091B_REAL321_T509_BROAD|Rig4X_M1091B_REAL321_T510_BALANCED|Rig5X3D_M1091B_REAL321_T509_X3D|Rig6X3D_M1091B_REAL321_T510_BALANCED|*DEFAULT_ANALYTICS*)
    m1091l_apply_canonical_default_profile
    echo "[M1091L_FINAL_CANONICAL_ENV_GUARD] worker=${RUN_WORKER:-${WORKER_NAME:-unset}} threshold=${CODED_FAST_SHADOW_THRESHOLD:-${THRESHOLD:-unset}} router=${CODED_PRIORITY_BUDGET_ROUTER:-unset}" | tee -a "$RUN_LOG" 2>/dev/null || true
    ;;
esac
echo "[M10.99P_FINAL_MINER_LAUNCH_ENV] worker=$RUN_WORKER CODED_PRIORITY_BUDGET_ROUTER=${CODED_PRIORITY_BUDGET_ROUTER:-unset} CODED_ANALYTICS=${CODED_ANALYTICS:-unset}" | tee -a "$RUN_LOG"

      # M10.99Z24_REAL_MINER_PID_AND_ENV_GUARD
      # Do not assign MINER_PID from a shell pipeline. With:
      #   miner | tee &
      # $! can refer to the pipeline/tee job, not reliably the real miner binary.
      # Launch miner in background with stdout/stderr redirected to RUN_LOG so $! is the real miner PID.
      echo "[M10.99Z24_REAL_MINER_PID_AND_ENV_GUARD] launching miner bin=$MINER_BIN worker=$RUN_WORKER router=${CODED_PRIORITY_BUDGET_ROUTER:-unset}" | tee -a "$RUN_LOG"

      CODED_PRIORITY_BUDGET_ROUTER="${CODED_PRIORITY_BUDGET_ROUTER:-$(m1091l_default_router_for_threshold "${CODED_FAST_SHADOW_THRESHOLD:-${THRESHOLD:-510}}")}" \
      CODED_ANALYTICS="${CODED_ANALYTICS:-YES}" \
      CODED_FORCE_FULLSCORE="${CODED_FORCE_FULLSCORE:-1}" \
      CODED_FULLSCORE_ALL_BACKENDS="${CODED_FULLSCORE_ALL_BACKENDS:-1}" \
      CODED_PREFILTER_DIFFICULTY="${CODED_PREFILTER_DIFFICULTY:-0}" \
      COMMAND_THREADS="${COMMAND_THREADS:-$THREADS}" \
      CODED_FAST_SHADOW_THRESHOLD="${CODED_FAST_SHADOW_THRESHOLD:-$THRESHOLD}" \
      CODED_KERNEL_BACKEND="${CODED_KERNEL_BACKEND:-avx512}" \
      # M10.99Z44_RESTORE_REAL_LAUNCH_ENV
      # Restore real Hive runtime settings before miner launch.
      # Never allow silent fallback to TEST_WALLET/coded-worker.
      POOL="${POOL:-${CODED_POOL:-${POOL_URL:-178.104.150.57:7777}}}"
      RUN_WORKER="${RUN_WORKER:-${WORKER_NAME:-${CODED_WORKER:-${RIG_ID:-Rig2X3D}}}}"
      THREADS="${THREADS:-${COMMAND_THREADS:-${CODED_THREADS:-${CODED_SAFE_THREADS:-24}}}}"

      if [ -z "${WALLET:-}" ] || [ "$WALLET" = "TEST_WALLET" ] || [ "$WALLET" = "TEST" ]; then
        WALLET="${CODED_WALLET:-${QUBIC_WALLET:-${HIVE_WALLET:-}}}"
      fi

      if [ -z "${WALLET:-}" ] || [ "$WALLET" = "TEST_WALLET" ] || [ "$WALLET" = "TEST" ]; then
        # Try Hive/custom config sources, but reject TEST_WALLET.
        WALLET="$(env | grep -Ei 'wallet|qubic' | grep -Eo '[A-Z]{55,70}' | head -n1 || true)"
      fi

      echo "[M10.99Z44_RESTORE_REAL_LAUNCH_ENV] pool=$POOL wallet_len=${#WALLET} wallet_prefix=$(echo "${WALLET:-}" | cut -c1-10) worker=$RUN_WORKER threads=$THREADS bin=$MINER_BIN run_id=${RUN_ID:-unset}" | tee -a "$RUN_LOG"

      if [ -z "${WALLET:-}" ] || [ "$WALLET" = "TEST_WALLET" ] || [ "$WALLET" = "TEST" ]; then
        echo "[M10.99Z44_RESTORE_REAL_LAUNCH_ENV] ERROR missing real wallet; refusing TEST_WALLET launch" | tee -a "$RUN_LOG"
        exit 44
      fi

      nc -zvw3 "$(echo "$POOL" | cut -d: -f1)" "$(echo "$POOL" | cut -d: -f2)" >> "$RUN_LOG" 2>&1 || {
        echo "[M10.99Z44_RESTORE_REAL_LAUNCH_ENV] ERROR pool tcp unavailable pool=$POOL" | tee -a "$RUN_LOG"
        exit 45
      }


      "$MINER_BIN" --pool "$POOL" --wallet "$WALLET" --worker "$RUN_WORKER" --threads "$THREADS" >> "$RUN_LOG" 2>&1 &
      MINER_PID=$!

      sleep 1
      if kill -0 "$MINER_PID" 2>/dev/null; then
        echo "[M10.99Z24_REAL_MINER_PID_AND_ENV_GUARD] miner_pid=$MINER_PID alive=1 worker=$RUN_WORKER router=${CODED_PRIORITY_BUDGET_ROUTER:-unset}" | tee -a "$RUN_LOG"
        if [ -r "/proc/$MINER_PID/environ" ]; then
          tr '\\0' '\\n' < "/proc/$MINER_PID/environ" 2>/dev/null | grep -E 'CODED_PRIORITY_BUDGET_ROUTER|CODED_ANALYTICS|CODED_KERNEL_BACKEND|CODED_FAST_SHADOW_THRESHOLD' | sed 's/^/[M10.99Z24_ENV] /' | tee -a "$RUN_LOG" || true
        fi
        # M10.99Z27_LAUNCHER_COMMAND_COMPLETION
        # start_run is a launcher command, not runtime truth.
        # Once the real miner PID is alive, complete the launcher command.
        # The actual long-running runtime remains miner_run_dashboard.
        if [ -n "${COMMAND_ID:-}" ]; then
          z27_payload="$(cat <<EOF
{"status":"launched","marker":"M10.99Z27_LAUNCHER_COMMAND_COMPLETION","miner_pid":$MINER_PID,"worker_name":"${RUN_WORKER:-${WORKER_NAME:-unknown}}","threshold":"${THRESHOLD:-${CODED_FAST_SHADOW_THRESHOLD:-unknown}}","router":"${CODED_PRIORITY_BUDGET_ROUTER:-unset}","runtime_source":"miner_run_dashboard","touched_miners":false}
EOF
)"
          z27_resp="$(curl -s -X POST "$CODED_API_ROOT/commands/$COMMAND_ID/complete" \
            -H "Authorization: Bearer $TOKEN" \
            -H "Content-Type: application/json" \
            -d "$z27_payload" 2>/dev/null || true)"
          echo "[M10.99Z27_LAUNCHER_COMMAND_COMPLETION] command_id=$COMMAND_ID miner_pid=$MINER_PID worker=${RUN_WORKER:-${WORKER_NAME:-unknown}} router=${CODED_PRIORITY_BUDGET_ROUTER:-unset} resp=$z27_resp" | tee -a "$RUN_LOG"
        else
          echo "[M10.99Z27_LAUNCHER_COMMAND_COMPLETION] skip complete: COMMAND_ID unset miner_pid=$MINER_PID worker=${RUN_WORKER:-${WORKER_NAME:-unknown}}" | tee -a "$RUN_LOG"
        fi

      else
        echo "[M10.99Z24_REAL_MINER_PID_AND_ENV_GUARD] ERROR miner failed immediately worker=$RUN_WORKER bin=$MINER_BIN" | tee -a "$RUN_LOG"
        coded_fail_command "$COMMAND_ID" "M10.99Z24 miner failed immediately after launch" || true
      fi

      # M10.99Z2_FIRST_JOB_WATCHDOG
      # Track whether this launched miner ever reaches a real SOLS line.
      # If it remains in WAITING FOR FIRST JOB for too long, restart only
      # this miner process and let the outer launch loop reconnect cleanly.
      FIRST_JOB_START_TS="$(date +%s)"
      FIRST_JOB_RESOLVED=0

      # M10.99Z12_DURATION_PRODUCTIVE_RUNTIME_GUARD
      PRODUCTIVE_START_TS="$(date +%s)"
      PRODUCTIVE_RUNTIME_SEEN=0

      # M10.99Z27B_DISABLE_LEGACY_LAUNCHER_COMPLETION
      # Legacy M10.91C launcher completion disabled.
      # M10.99Z27 is now the single authoritative start_run completion path.
      # Keeping both caused duplicate /commands/$COMMAND_ID/complete calls.
      START_RUN_LAUNCH_COMPLETED=1
      echo "[M10.99Z27B_DISABLE_LEGACY_LAUNCHER_COMPLETION] legacy M10.91C completion skipped command=$COMMAND_ID run=$RUN_ID worker=$RUN_WORKER" | tee -a "$RUN_LOG"

      while kill -0 "$MINER_PID" 2>/dev/null; do
        sleep 30

        # ============================================================
        # M10.99Z2_FIRST_JOB_WATCHDOG
        # ============================================================
        # If the miner stays connected but never receives/promotes a job,
        # it prints WAITING FOR FIRST JOB forever and uploads 0 it/s.
        # Restarting only the miner process forces a fresh pool subscribe
        # without killing the fleet supervisor or command lifecycle.
        if [ "${FIRST_JOB_RESOLVED:-0}" != "1" ]; then
          if grep -q "SOLS:" "$RUN_LOG" 2>/dev/null; then
            FIRST_JOB_RESOLVED=1
            echo "[M10.99Z2_FIRST_JOB_WATCHDOG] first_job_resolved run=$RUN_ID worker=$RUN_WORKER" | tee -a "$RUN_LOG"
          else
            NOW_TS="$(date +%s)"
            WAIT_SEC=$((NOW_TS - ${FIRST_JOB_START_TS:-NOW_TS}))
            if [ "$WAIT_SEC" -ge "${CODED_FIRST_JOB_TIMEOUT_SEC:-180}" ] 2>/dev/null; then
              LAST_POOL_LINES="$(grep -E "\[POOL\]|WAITING FOR FIRST JOB|WAITING FOR NEW SEED" "$RUN_LOG" 2>/dev/null | tail -n 12 | tr '\n' ';' | sed 's/"/\"/g')"
              echo "[M10.99Z2_FIRST_JOB_WATCHDOG] restart_miner reason=first_job_timeout wait_sec=$WAIT_SEC timeout=${CODED_FIRST_JOB_TIMEOUT_SEC:-180} run=$RUN_ID worker=$RUN_WORKER last_pool_lines=$LAST_POOL_LINES" | tee -a "$RUN_LOG"
              kill "$MINER_PID" 2>/dev/null || true
              sleep 2
              kill -9 "$MINER_PID" 2>/dev/null || true
              break
            fi
          fi
        fi

        # ============================================================
        # M10.99Z12_DURATION_PRODUCTIVE_RUNTIME_GUARD
        # ============================================================
        # Heartbeat alone is not enough. A healthy run must produce
        # mining evidence shortly after launch.
        if [ "${PRODUCTIVE_RUNTIME_SEEN:-0}" != "1" ]; then
          if grep -Eq "SOLS:|FAST_SHADOW_SUMMARY|\[[A-Za-z0-9_ -]+\][[:space:]]+[1-9][0-9]*[[:space:]]+it/s|[1-9][0-9]*[[:space:]]+avg it/s" "$RUN_LOG" 2>/dev/null; then
            PRODUCTIVE_RUNTIME_SEEN=1
            echo "[M10.99Z12_DURATION_PRODUCTIVE_RUNTIME_GUARD] productive_runtime_seen run=$RUN_ID worker=$RUN_WORKER" | tee -a "$RUN_LOG"
          else
            NOW_TS="$(date +%s)"
            WAIT_SEC=$((NOW_TS - ${PRODUCTIVE_START_TS:-NOW_TS}))
            if [ "$WAIT_SEC" -ge "${CODED_PRODUCTIVE_RUNTIME_TIMEOUT_SEC:-180}" ] 2>/dev/null; then
              LAST_LINES="$(grep -E "WAITING FOR FIRST JOB|WAITING FOR NEW SEED|SOLS:|avg it/s|FAST_SHADOW|POOL|ERROR|WARN" "$RUN_LOG" 2>/dev/null | tail -n 20 | tr '\n' ';' | sed 's/"/\"/g')"
              echo "[M10.99Z12_DURATION_PRODUCTIVE_RUNTIME_GUARD] restart_miner reason=no_productive_metrics wait_sec=$WAIT_SEC timeout=${CODED_PRODUCTIVE_RUNTIME_TIMEOUT_SEC:-180} run=$RUN_ID worker=$RUN_WORKER last_lines=$LAST_LINES" | tee -a "$RUN_LOG"
              kill "$MINER_PID" 2>/dev/null || true
              sleep 2
              kill -9 "$MINER_PID" 2>/dev/null || true
              break
            fi
          fi
        fi

        if coded_check_interrupt_command; then
          echo "[M10.90A_INTERRUPT] stopping miner pid=$MINER_PID for type=$INTERRUPT_TYPE" | tee -a "$RUN_LOG"
        # ============================================================
        # M10.96G8G all-stop-markers git_experiment_run handoff
        # ============================================================
        # Fleet-scale invariant:
        # - default analytics must always be resumable
        # - git_experiment_run must be insertable while default is mining
        # - stop_run with next_git_experiment_params must enqueue experiment
        #   from the same stop branch that actually runs on the rig
        if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
          NEXT_TYPE="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.next_command_type // empty" 2>/dev/null || true)"
          if [ "$NEXT_TYPE" = "git_experiment_run" ]; then
            NEXT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params.next_git_experiment_params // empty" 2>/dev/null || true)"
            STOP_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // .id // empty" 2>/dev/null || true)"
            STOP_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty" 2>/dev/null || true)"
            STOP_LIFECYCLE_ID="${STOP_DB_ID:-$STOP_COMMAND_ID}"

            echo "[M10.96G8G_ALL_STOP_MARKERS_HANDOFF] reached stop branch stop_db_id=$STOP_DB_ID stop_command_id=$STOP_COMMAND_ID lifecycle=$STOP_LIFECYCLE_ID next_type=$NEXT_TYPE params=$NEXT_PARAMS" | tee -a "$RUN_LOG"

            if [ -n "$NEXT_PARAMS" ] && [ "$NEXT_PARAMS" != "null" ]; then
              CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$NEXT_PARAMS}" || true)"

              echo "[M10.96G8G_ALL_STOP_MARKERS_HANDOFF] create_git_experiment_resp=$CREATE_RESP" | tee -a "$RUN_LOG"

              coded_complete_command_id "$STOP_LIFECYCLE_ID" "{\"status\":\"completed\",\"stage\":\"all_stop_markers_git_experiment_enqueued\",\"orchestration\":\"M10.96G8G\"}" || true

              echo "[M10.96G8G_ALL_STOP_MARKERS_HANDOFF] completed stop_run and enqueued git_experiment_run" | tee -a "$RUN_LOG"
            else
              echo "[M10.96G8G_ALL_STOP_MARKERS_HANDOFF] missing next_git_experiment_params" | tee -a "$RUN_LOG"
              coded_fail_command "$STOP_LIFECYCLE_ID" "stop_run missing next_git_experiment_params" "{\"status\":\"failed\",\"stage\":\"all_stop_markers_missing_params\",\"orchestration\":\"M10.96G8G\"}" || true
            fi
          fi
        fi


        # ============================================================
        # M10.96G8E pre-stop git_experiment_run handoff
        # ============================================================
        # Previous G8D ran after "interrupted current run", but some rigs
        # hang while stopping/waiting for coded-miner. Therefore the handoff
        # must happen before the stop wait path.
        if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
          NEXT_TYPE="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.next_command_type // empty" 2>/dev/null || true)"
          if [ "$NEXT_TYPE" = "git_experiment_run" ]; then
            NEXT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params.next_git_experiment_params // empty" 2>/dev/null || true)"
            STOP_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // .id // empty" 2>/dev/null || true)"
            STOP_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty" 2>/dev/null || true)"
            LIFECYCLE_STOP_ID="${STOP_DB_ID:-$STOP_COMMAND_ID}"

            echo "[M10.96G8E_PRESTOP_HANDOFF] stop_db_id=$STOP_DB_ID stop_command_id=$STOP_COMMAND_ID lifecycle_stop_id=$LIFECYCLE_STOP_ID next_type=$NEXT_TYPE params=$NEXT_PARAMS" | tee -a "$RUN_LOG"

            if [ -n "$NEXT_PARAMS" ] && [ "$NEXT_PARAMS" != "null" ]; then
              CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$NEXT_PARAMS}" || true)"

              echo "[M10.96G8E_PRESTOP_HANDOFF] create_git_experiment_resp=$CREATE_RESP" | tee -a "$RUN_LOG"

              coded_complete_command_id "$LIFECYCLE_STOP_ID" "{\"status\":\"completed\",\"stage\":\"prestop_git_experiment_enqueued\",\"orchestration\":\"M10.96G8E\"}" || true

              echo "[M10.96G8E_PRESTOP_HANDOFF] completed stop_run and enqueued git_experiment_run before miner stop wait" | tee -a "$RUN_LOG"
            else
              echo "[M10.96G8E_PRESTOP_HANDOFF] missing next_git_experiment_params" | tee -a "$RUN_LOG"
              coded_fail_command "$LIFECYCLE_STOP_ID" "stop_run prestop handoff missing next_git_experiment_params" "{\"status\":\"failed\",\"stage\":\"prestop_handoff_missing_params\",\"orchestration\":\"M10.96G8E\"}" || true
            fi
          fi
        fi
          kill "$MINER_PID" 2>/dev/null || true
          sleep 3
          kill -9 "$MINER_PID" 2>/dev/null || true
          break
        fi

        if [ "$SECONDS" -ge "$END" ]; then
          echo "[CODED_FLEET] run duration reached; stopping miner pid=$MINER_PID" | tee -a "$RUN_LOG"
          kill "$MINER_PID" 2>/dev/null || true
          break
        fi
      done

      wait "$MINER_PID" 2>/dev/null || true
      EC=$?

      if [ -n "$INTERRUPT_TYPE" ]; then
        
        # ============================================================
        # M10.96G8F true stop-branch git_experiment_run handoff
        # ============================================================
        # This is inserted between the two stable M10.90A stop markers.
        # The logs prove this exact code path is reached on Rig2.
        if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
          NEXT_TYPE="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.next_command_type // empty" 2>/dev/null || true)"
          if [ "$NEXT_TYPE" = "git_experiment_run" ]; then
            NEXT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params.next_git_experiment_params // empty" 2>/dev/null || true)"
            STOP_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // .id // empty" 2>/dev/null || true)"
            STOP_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty" 2>/dev/null || true)"
            STOP_LIFECYCLE_ID="${STOP_DB_ID:-$STOP_COMMAND_ID}"

            echo "[M10.96G8F_TRUE_STOP_BRANCH_HANDOFF] reached stop handoff stop_db_id=$STOP_DB_ID stop_command_id=$STOP_COMMAND_ID lifecycle=$STOP_LIFECYCLE_ID next_type=$NEXT_TYPE params=$NEXT_PARAMS" | tee -a "$RUN_LOG"

            if [ -n "$NEXT_PARAMS" ] && [ "$NEXT_PARAMS" != "null" ]; then
              CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$NEXT_PARAMS}" || true)"

              echo "[M10.96G8F_TRUE_STOP_BRANCH_HANDOFF] create_git_experiment_resp=$CREATE_RESP" | tee -a "$RUN_LOG"

              # Complete stop_run with DB UUID when available.
              coded_complete_command_id "$STOP_LIFECYCLE_ID" "{\"status\":\"completed\",\"stage\":\"true_stop_branch_git_experiment_enqueued\",\"orchestration\":\"M10.96G8F\"}" || true

              echo "[M10.96G8F_TRUE_STOP_BRANCH_HANDOFF] completed stop_run and enqueued git_experiment_run" | tee -a "$RUN_LOG"
            else
              echo "[M10.96G8F_TRUE_STOP_BRANCH_HANDOFF] missing next_git_experiment_params" | tee -a "$RUN_LOG"
              coded_fail_command "$STOP_LIFECYCLE_ID" "stop_run missing next_git_experiment_params" "{\"status\":\"failed\",\"stage\":\"true_stop_branch_missing_params\",\"orchestration\":\"M10.96G8F\"}" || true
            fi
          fi
        fi

echo "[M10.90A_INTERRUPT] interrupted current run type=$INTERRUPT_TYPE" | tee -a "$RUN_LOG"

        # ============================================================
        # M10.96G8D direct stop -> git_experiment_run handoff
        # ============================================================
        # This block must run immediately after a stop_run interrupt
        # was processed. It is intentionally placed next to the stable
        # M10.90A interrupt marker, because previous G8B placement was
        # not reached reliably.
        if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
          NEXT_TYPE="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.next_command_type // empty" 2>/dev/null || true)"
          if [ "$NEXT_TYPE" = "git_experiment_run" ]; then
            NEXT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params.next_git_experiment_params // empty" 2>/dev/null || true)"
            STOP_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // .id // empty" 2>/dev/null || true)"
            STOP_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty" 2>/dev/null || true)"
            LIFECYCLE_STOP_ID="${STOP_DB_ID:-$STOP_COMMAND_ID}"

            echo "[M10.96G8D_DIRECT_STOP_HANDOFF] stop_db_id=$STOP_DB_ID stop_command_id=$STOP_COMMAND_ID lifecycle_stop_id=$LIFECYCLE_STOP_ID next_type=$NEXT_TYPE params=$NEXT_PARAMS" | tee -a "$RUN_LOG"

            if [ -n "$NEXT_PARAMS" ] && [ "$NEXT_PARAMS" != "null" ]; then
              CREATE_RESP="$(curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$NEXT_PARAMS}" || true)"

              echo "[M10.96G8D_DIRECT_STOP_HANDOFF] create_git_experiment_resp=$CREATE_RESP" | tee -a "$RUN_LOG"

              if command -v coded_complete_command_id >/dev/null 2>&1; then
                coded_complete_command_id "$LIFECYCLE_STOP_ID" "{\"status\":\"completed\",\"stage\":\"stop_completed_git_experiment_enqueued\",\"orchestration\":\"M10.96G8D\",\"create_response\":$CREATE_RESP}" || true
              else
                coded_complete_command "$LIFECYCLE_STOP_ID" "{\"status\":\"completed\",\"stage\":\"stop_completed_git_experiment_enqueued\",\"orchestration\":\"M10.96G8D\"}" || true
              fi

              echo "[M10.96G8D_DIRECT_STOP_HANDOFF] completed stop_run and enqueued git_experiment_run" | tee -a "$RUN_LOG"
            else
              echo "[M10.96G8D_DIRECT_STOP_HANDOFF] missing next_git_experiment_params" | tee -a "$RUN_LOG"
              coded_fail_command "$LIFECYCLE_STOP_ID" "stop_run handoff missing next_git_experiment_params" "{\"status\":\"failed\",\"stage\":\"stop_handoff_missing_params\",\"orchestration\":\"M10.96G8D\"}" || true
            fi
          fi
        fi

        # M10.96G8B:
        # stop_run can carry a git_experiment_run handoff payload.
        # This keeps git_experiment_run out of the active miner interrupt picker.
        # After the miner exits, enqueue the real git_experiment_run for the top-level handler.
        if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
          NEXT_TYPE="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.next_command_type // empty" 2>/dev/null || true)"
          if [ "$NEXT_TYPE" = "git_experiment_run" ]; then
            NEXT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params.next_git_experiment_params // empty" 2>/dev/null || true)"
            STOP_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // empty" 2>/dev/null || true)"
            STOP_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty" 2>/dev/null || true)"

            if [ -n "$NEXT_PARAMS" ] && [ "$NEXT_PARAMS" != "null" ]; then
              echo "[M10.96G8B_STOP_HANDOFF] enqueue git_experiment_run after stop stop_db_id=$STOP_DB_ID stop_command_id=$STOP_COMMAND_ID params=$NEXT_PARAMS" | tee -a "$RUN_LOG"

              curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
                -H "Authorization: Bearer $TOKEN" \
                -H "Content-Type: application/json" \
                -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$NEXT_PARAMS}" >/dev/null || true

              coded_complete_command "$STOP_COMMAND_ID" "{\"status\":\"completed\",\"stage\":\"stop_completed_git_experiment_enqueued\",\"orchestration\":\"M10.96G8B\"}" || true
              echo "[M10.96G8B_STOP_HANDOFF] completed stop_run and enqueued git_experiment_run" | tee -a "$RUN_LOG"
            else
              echo "[M10.96G8B_STOP_HANDOFF] missing next_git_experiment_params" | tee -a "$RUN_LOG"
            fi
          fi
        fi

        # M10.96G4:
        # git_experiment_run can be picked as an interrupt while a long default miner is running.
        # That picked command must not be swallowed inside coded_run_profile.
        # Requeue the same payload as a fresh pending command so the top-level handler can execute:
        # picked_up -> running -> heartbeat -> build -> rollback/resume/default.
        if [ "$INTERRUPT_TYPE" = "__disabled_git_experiment_run_interrupt__" ]; then
          INTERRUPT_PARAMS_SAFE="$(echo "$INTERRUPT_CMD" | jq -c ".command.params // .params // {}")"
          INTERRUPT_DB_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.id // .id // empty")"
          INTERRUPT_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // .command_id // empty")"

          echo "[M10.96G4_INTERRUPT_REQUEUE] requeue git_experiment_run old_db_id=$INTERRUPT_DB_ID old_command_id=$INTERRUPT_COMMAND_ID params=$INTERRUPT_PARAMS_SAFE" | tee -a "$RUN_LOG"

          curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
            -H "Authorization: Bearer $TOKEN" \
            -H "Content-Type: application/json" \
            -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"git_experiment_run\",\"params\":$INTERRUPT_PARAMS_SAFE}" >/dev/null || true

          if [ -n "$INTERRUPT_DB_ID" ]; then
            coded_fail_command "$INTERRUPT_DB_ID" "git_experiment_run interrupt requeued for top-level handler" "{\"status\":\"requeued\",\"reason\":\"interrupt_requeued_for_top_level_handler\",\"old_command_id\":\"$INTERRUPT_COMMAND_ID\"}" || true
          fi

          echo "[M10.96G4_INTERRUPT_REQUEUE] done; top-level loop will pick fresh git_experiment_run" | tee -a "$RUN_LOG"
        fi
        break
      fi

      echo "[CODED_FLEET] miner exited code=$EC; restarting in 10s" | tee -a "$RUN_LOG"
      sleep 10
    done

    kill "$UPLOADER_PID" 2>/dev/null || true

    coded_state_set_idle "run_finished_or_interrupted"

    curl -s -X POST "$API/runs/end" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"run_id\":\"$RUN_ID\",\"status\":\"completed\",\"end_reason\":\"fleet_command_completed\"}" >/dev/null || true

    if [ "$START_RUN_LAUNCH_COMPLETED" != "1" ]; then
      curl -s -X POST "$CODED_API_ROOT/commands/$CID/complete" \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"command_id\":\"$COMMAND_ID\",\"result\":{\"status\":\"completed\",\"run_id\":\"$RUN_ID\",\"interrupted_by\":\"${INTERRUPT_TYPE:-}\"}}" >/dev/null || true

      echo "[CODED_FLEET] command completed command=$COMMAND_ID run=$RUN_ID interrupted_by=${INTERRUPT_TYPE:-none}"
    else
      echo "[CODED_FLEET] launcher command already completed command=$COMMAND_ID run=$RUN_ID runtime_tracking=miner_run_dashboard interrupted_by=${INTERRUPT_TYPE:-none}"
    fi

    # Complete stop_run interrupts immediately. For build_* interrupts,
    # re-create a pending command of same type and params so the normal
    # top-level handler processes it in the next polling cycle. This avoids
    # fragile shell jumps and keeps release build logic single-sourced.
    if [ -n "$INTERRUPT_TYPE" ]; then
      INTERRUPT_COMMAND_ID="$(echo "$INTERRUPT_CMD" | jq -r ".command.command_id // empty")"

      # ============================================================
      # M10.99Z92B_START_RUN_INTERRUPT_TO_TOP_LEVEL
      # ------------------------------------------------------------
      # /next-interrupt can now return experiment start_run commands.
      # Do NOT launch a second miner inline inside the interrupt block.
      # Instead:
      #   1. stop/yield current default runtime
      #   2. requeue identical start_run params
      #   3. complete the interrupt command as rescheduled
      #   4. let the normal top-level start_run branch launch it
      #
      # This preserves the known-good launch path:
      # - params/env override
      # - /runs/start upload
      # - uploader start
      # - real wallet/pool restore
      # - real miner PID guard
      # - launcher completion only after miner PID is alive
      # ============================================================
      if [ "$INTERRUPT_TYPE" = "start_run" ]; then
        INTERRUPT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params // .params // {}" 2>/dev/null || echo "{}")"
        INTERRUPT_WORKER="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.worker_name // .command.params.worker // empty" 2>/dev/null || true)"
        INTERRUPT_MARKER="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.marker // empty" 2>/dev/null || true)"
        INTERRUPT_PRIORITY="$(echo "$INTERRUPT_CMD" | jq -r ".command.params.priority // empty" 2>/dev/null || true)"

        echo "[M10.99Z92B_START_RUN_INTERRUPT_TO_TOP_LEVEL] command=$INTERRUPT_COMMAND_ID worker=$INTERRUPT_WORKER marker=$INTERRUPT_MARKER priority=$INTERRUPT_PRIORITY interrupted_run_id=$RUN_ID" | tee -a "$RUN_LOG"

        CREATE_RESP="$(curl -s -X POST "$API/commands/create" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"start_run\",\"params\":$INTERRUPT_PARAMS}" || true)"

        CREATE_SAFE="$(printf "%s" "$CREATE_RESP" | python3 -c 'import sys,json
raw=sys.stdin.read()
try:
    print(json.dumps(json.loads(raw)))
except Exception:
    print(json.dumps({"raw": raw[:500]}))
' 2>/dev/null || echo "{}")"

        coded_complete_command_id "$INTERRUPT_COMMAND_ID" "{\"status\":\"rescheduled_for_top_level_start_run\",\"marker\":\"M10.99Z92B_START_RUN_INTERRUPT_TO_TOP_LEVEL\",\"interrupted_run_id\":\"$RUN_ID\",\"worker_name\":\"$INTERRUPT_WORKER\",\"create_response\":$CREATE_SAFE}" || true

        echo "[M10.99Z92B_START_RUN_INTERRUPT_TO_TOP_LEVEL] requeued start_run for top-level worker=$INTERRUPT_WORKER create_resp=$CREATE_RESP" | tee -a "$RUN_LOG"

        # Do not let generic interrupt cleanup complete/fail this start_run again.
        INTERRUPT_TYPE=""
        INTERRUPT_CMD=""
        continue
      fi


      if [ "$INTERRUPT_TYPE" = "stop_run" ]; then
        coded_complete_command_id "$INTERRUPT_COMMAND_ID" "{\"status\":\"stopped\",\"interrupted_run_id\":\"$RUN_ID\"}"
      fi

      if [ "$INTERRUPT_TYPE" = "build_hive_release" ] || [ "$INTERRUPT_TYPE" = "build_release" ]; then
        INTERRUPT_PARAMS="$(echo "$INTERRUPT_CMD" | jq -c ".command.params // {}")"

        # Mark picked interrupt complete as rescheduled, then create fresh pending
        # build_hive_release so top-level loop handles it immediately.
        coded_complete_command_id "$INTERRUPT_COMMAND_ID" "{\"status\":\"rescheduled_for_release_build\",\"interrupted_run_id\":\"$RUN_ID\"}"

        curl -s -X POST "$CODED_API_ROOT/analytics/commands/create" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{\"rig_id\":\"$RIG_ID\",\"command_type\":\"$INTERRUPT_TYPE\",\"params\":$INTERRUPT_PARAMS}" >/dev/null || true

        echo "[M10.96G_INTERRUPT] rescheduled interrupt command type=$INTERRUPT_TYPE params=$INTERRUPT_PARAMS"
      fi
    fi
  done
else
  echo "[M10.91A_SUPERVISOR] no fleet command mode detected; entering always-on fallback supervisor"
  while true; do
    DEFAULT_PARAMS="$(coded_default_profile_json)"
    coded_run_profile "$DEFAULT_PARAMS" || true

    # If interrupted by a command, the top-level command loop should handle it on next iteration.
    # If the miner exits unexpectedly, resume fallback after a short cooldown.
    echo "[M10.91A_SUPERVISOR] fallback cycle ended; resuming after cooldown"
    sleep "${CODED_FALLBACK_RESUME_DELAY:-10}"
  done
fi

# M10.99Z45_NEVER_IDLE_DEFAULT_RUNTIME
if coded_z54_release_builder_only_enabled; then echo "[M10.99Z55_FORCE_RELEASE_BUILDER_EXECUTE] suppress Z45 call in release-builder-only"; else coded_z45_never_idle_default_runtime || true; fi
wait



# M10.99Z233_RESTORE_SCORE_DISTRIBUTION_UPLOADER_SCORE_ROUTE_DIAG
# This footer marker confirms this release contains canonical score-distribution upload routing.
